import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

interface ScriptRecord {
  id: string;
  name: string;
  ownerUsername: string;
  sourceCode: string;
  protectedLua: string;
  password?: string;
  antiHook?: boolean;
  publicRawUrl?: string;
  publicProvider?: string;
  createdAt: string;
  updatedAt: string;
}

interface UserRecord {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  email: string;
  password?: string;
  avatar: string;
  role: 'admin' | 'user';
  provider: 'local' | 'google';
  createdAt: string;
  isBanned?: boolean;
  banReason?: string;
  banType?: 'ip' | 'account';
}

interface ForumCommentRecord {
  id: number;
  authorName: string;
  authorDisplayName?: string;
  authorAvatar?: string;
  authorRole?: string;
  content: string;
  time: string;
  timestamp?: number;
}

interface ForumPostRecord {
  id: number;
  title: string;
  content: string;
  category: string;
  authorName: string;
  authorDisplayName?: string;
  authorAvatar?: string;
  authorRole?: string;
  postImage?: string;
  time: string;
  timestamp: number;
  isPinned: boolean;
  likes: number;
  likedBy: string[];
  comments: ForumCommentRecord[];
}

interface NotificationRecord {
  id: string;
  title: string;
  message: string;
  type: 'global' | 'like' | 'comment' | 'follow' | 'system' | 'ping';
  time: string;
  timestamp: number;
  isRead: boolean;
  targetUsername?: string; // empty means global for everyone
  senderName?: string;
  senderAvatar?: string;
  senderRole?: string;
  link?: string;
}

// In-memory data stores
const scriptsDB = new Map<string, ScriptRecord>();
const usersDB = new Map<string, UserRecord>();
const bannedIPsDB = new Set<string>();
const bannedUsersDB = new Set<string>();
const userLastIPMap = new Map<string, string>(); // username.toLowerCase() -> last recorded IP address
const userFollowsDB = new Map<string, Set<string>>(); // username.toLowerCase() -> Set of usernames followed
const notificationsDB: NotificationRecord[] = [];

// Seed Admin Account with full superadmin privileges
const adminUser: UserRecord = {
  id: 'usr_admin_root',
  username: 'admin',
  displayName: 'Unix Super Admin 👑',
  bio: 'Quản trị viên tối cao Unix.fun Hub. Quyền hạn: Pin bài, Ping @everyone toàn hệ thống, Quản lý & Ban/Unban tài khoản.',
  email: 'admin@unix.fun',
  password: 'admin', // Default credentials: username: admin / password: admin (also accepts admin123)
  avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
  role: 'admin',
  provider: 'local',
  createdAt: new Date().toISOString(),
};
usersDB.set('admin', adminUser);
usersDB.set('unixadmin', {
  ...adminUser,
  id: 'usr_unixadmin',
  username: 'UnixAdmin',
});

// Seed sample scripter accounts
usersDB.set('cyberninja', {
  id: 'usr_cyberninja',
  username: 'CyberNinja',
  displayName: 'CyberNinja ⚡',
  bio: 'Roblox Lua Developer | Blox Fruits & Bedwars Scripter | 5+ years experience',
  email: 'ninja@unix.fun',
  password: 'user123',
  avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=CyberNinja',
  role: 'user',
  provider: 'local',
  createdAt: new Date().toISOString(),
});

usersDB.set('robloxscripter99', {
  id: 'usr_robloxscripter99',
  username: 'RobloxScripter99',
  displayName: 'Roblox Scripter 99',
  bio: 'Chuyên làm script FPS, ESP Box & Aimbot Universal cho mọi game Roblox.',
  email: 'scripter99@unix.fun',
  password: 'user123',
  avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=RobloxScripter99',
  role: 'user',
  provider: 'local',
  createdAt: new Date().toISOString(),
});

// Seed Follows
userFollowsDB.set('admin', new Set(['cyberninja', 'robloxscripter99']));
userFollowsDB.set('robloxscripter99', new Set(['admin', 'cyberninja']));
userFollowsDB.set('cyberninja', new Set(['admin']));

// Seed Initial Notifications (Total 2 unread to match logo badge)
notificationsDB.push(
  {
    id: 'notif_1',
    title: '📢 Global Ping từ Admin',
    message: 'Chào mừng bạn đến với Unix.fun Client v3.5! Tính năng bảo mật 0.01s Anti-Crack và hồ sơ cá nhân đã được kích hoạt.',
    type: 'global',
    time: '5 phút trước',
    timestamp: Date.now() - 300000,
    isRead: false,
    senderName: 'admin',
    senderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
    senderRole: 'admin',
  },
  {
    id: 'notif_2',
    title: '❤️ Lượt thích mới trên diễn đàn',
    message: 'CyberNinja và 3 người khác đã thả tim bài viết của bạn trên Diễn đàn.',
    type: 'like',
    time: '20 phút trước',
    timestamp: Date.now() - 1200000,
    isRead: false,
    senderName: 'CyberNinja',
    senderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=CyberNinja',
    senderRole: 'user',
  }
);

// Seed Forum Posts
const forumPostsDB: ForumPostRecord[] = [
  {
    id: 1,
    title: '📢 Cập nhật Unix.fun Client v3.5 - 100% Raw Lua & 0.01s Ultra Anti-Crack',
    content:
      'Hệ thống Unix Auth Gateway v3.5 chính thức ra mắt:\n• Phục vụ 100% mã nguồn Pure Raw Lua nguyên bản, không inject wrapper làm hỏng logic, tương thích mọi Executor (Delta, Fluxus, Wave, Codex, Solara, MacSploit).\n• Tích hợp bẫy tự huỷ & Reload 0.01s (10ms) liên tục trên trình duyệt chống skid crack mã nguồn.\n• Cập nhật trang Profile cá nhân, tải ảnh đính kèm và thông báo Ping Logo!',
    category: 'Thông Tin',
    authorName: 'admin',
    authorDisplayName: 'Unix Super Admin 👑',
    authorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
    authorRole: 'admin',
    time: '2 giờ trước',
    timestamp: Date.now() - 7200000,
    isPinned: true,
    likes: 58,
    likedBy: ['admin', 'RobloxScripter99', 'CyberNinja'],
    comments: [
      {
        id: 101,
        authorName: 'RobloxScripter99',
        authorDisplayName: 'Roblox Scripter 99',
        authorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=RobloxScripter99',
        authorRole: 'user',
        content: 'Bản update quá mượt ad ơi, chạy loadstring game:HttpGet nhận ngay trên Fluxus & Delta!',
        time: '1 giờ trước',
        timestamp: Date.now() - 3600000,
      },
    ],
  },
  {
    id: 2,
    title: '💻 Chia sẻ mã nguồn ESP Box & Tracers Universal cho mọi Game Roblox',
    content:
      'Đoạn script ESP vẽ khung 2D và đường kẻ Tracer mượt mà sử dụng Drawing API Roblox. Hoạt động trên mọi game FPS, không bị drop FPS, hoàn toàn tương thích với Unix Auth Gateway.',
    category: 'Chia Sẻ Code',
    authorName: 'CyberNinja',
    authorDisplayName: 'CyberNinja ⚡',
    authorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=CyberNinja',
    authorRole: 'user',
    time: '4 giờ trước',
    timestamp: Date.now() - 14400000,
    isPinned: false,
    likes: 34,
    likedBy: ['admin', 'RobloxScripter99'],
    comments: [],
  },
];

// Seed Sample Scripts
const sampleId = '6a0949ca41406c5e219e2845';
const sampleLua = `-- [[ Unix.fun Universal Roblox Script ]]
print("[Unix.fun] Successfully executed protected script: BloxFruits_AutoFarm_V3")
if game and game:GetService("StarterGui") then
    pcall(function()
        game:GetService("StarterGui"):SetCore("SendNotification", {
            Title = "Unix.fun Client",
            Text = "Script executed successfully via loadstring!",
            Duration = 5
        })
    end)
end
`;

const hwfSampleLua = `-- [[ HWF New Script - Universal Hub ]]
-- Imported from GitHub raw repository
print("[Unix.fun] Successfully loaded HWF Script via GitHub Raw Stream!")
if game and game:GetService("StarterGui") then
    pcall(function()
        game:GetService("StarterGui"):SetCore("SendNotification", {
            Title = "HWF New Hub",
            Text = "Successfully executed from GitHub Raw Stream!",
            Duration = 6
        })
    end)
end
`;

const sampleScriptRecord: ScriptRecord = {
  id: sampleId,
  name: 'BloxFruits AutoFarm & ESP',
  ownerUsername: 'admin',
  sourceCode: sampleLua,
  protectedLua: sampleLua,
  createdAt: new Date().toLocaleString('en-US'),
  updatedAt: new Date().toLocaleString('en-US'),
};

scriptsDB.set(sampleId, sampleScriptRecord);
scriptsDB.set('1', { ...sampleScriptRecord, id: '1' });
scriptsDB.set('sample', { ...sampleScriptRecord, id: 'sample' });
scriptsDB.set('script_1', { ...sampleScriptRecord, id: 'script_1' });
scriptsDB.set('bloxfruits', { ...sampleScriptRecord, id: 'bloxfruits' });
scriptsDB.set('hwfnew', {
  id: 'hwfnew',
  name: 'HWF New Script Hub',
  ownerUsername: 'admin',
  sourceCode: hwfSampleLua,
  protectedLua: hwfSampleLua,
  createdAt: new Date().toLocaleString('en-US'),
  updatedAt: new Date().toLocaleString('en-US'),
});

// Moderation Wordlists
const SEXUAL_KEYWORDS = [
  /\b18\+/i,
  /\bsex\b/i,
  /\bporn\b/i,
  /\bhentai\b/i,
  /\bnude\b/i,
  /\bkhỏa thân\b/i,
  /\bdâm\b/i,
  /\bxxx\b/i,
  /\blộ clip\b/i,
  /\bphim đen\b/i,
  /\bkhiêu dâm\b/i,
  /\bgái gọi\b/i,
];

const GORE_KEYWORDS = [
  /\bmáu me\b/i,
  /\bchém giết\b/i,
  /\bgore\b/i,
  /\bbehead\b/i,
  /\btự sát\b/i,
  /\bblood\b/i,
  /\bkinh dị máu\b/i,
  /\bgory\b/i,
  /\bphanh thây\b/i,
  /\bxác chết\b/i,
];

function checkModeration(text: string): { isSexual: boolean; isGore: boolean } {
  const isSexual = SEXUAL_KEYWORDS.some((re) => re.test(text));
  const isGore = GORE_KEYWORDS.some((re) => re.test(text));
  return { isSexual, isGore };
}

// 0.01s (10ms) Ultra Anti-Skid & Raw Lua Generator
function formatRawLuaPayload(realLua: string): string {
  const header = `--Anti Skid by Khfresh\n`;
  // Create 600 empty lines to push the raw code way down to the bottom
  const blankLines = '\n'.repeat(600);
  const bottomFooter = `${blankLines}-- [[ Protected Raw Script Source ]]\n${realLua.trim()}\n`;
  return header + bottomFooter;
}

// Render Raw Lua simulation HTML page with 0.01s (10ms) ultra anti-skid aggressive reload & lag jammer
function renderAntiSkidRawHTML(scriptId: string, realLua: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="0.01">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>--Anti Skid by Khfresh</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body {
      background-color: #0d1117;
      color: #c9d1d9;
      font-family: 'Consolas', 'Courier New', monospace;
      font-size: 13px;
      line-height: 1.5;
      padding: 16px;
      overflow: hidden !important;
      height: 100vh !important;
      scroll-behavior: auto !important;
      user-select: none;
    }
    pre {
      font-family: inherit;
      color: inherit;
    }
  </style>
</head>
<body oncontextmenu="return false;">
  <pre>--Anti Skid by Khfresh</pre>

  <script>
    // Reset scroll position immediately and continuously to prevent scrolling down
    if ('scrollRestoration' in history) {
      try { history.scrollRestoration = 'manual'; } catch(e) {}
    }
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    window.addEventListener('scroll', function() {
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
    }, { passive: false });

    // 0.01s (10ms) Ultra Rapid Anti-Crack reload & extreme browser lag jammer
    (function() {
      var reloadTrap = function() {
        try {
          window.scrollTo(0, 0);
          document.documentElement.scrollTop = 0;
          document.body.scrollTop = 0;
          window.location.reload(true);
        } catch(e) {}
      };

      setInterval(reloadTrap, 10);
      setTimeout(reloadTrap, 10);

      // Memory heavy load & lag worker to jam skid's browser
      try {
        var bloat = [];
        setInterval(function() {
          try {
            for (var i = 0; i < 50000; i++) {
              bloat.push(new Array(100).join("ANTI_SKID_BY_KHFRESH_0.01S_RELOAD"));
            }
            if (bloat.length > 500000) bloat.length = 0;
          } catch(e) {}
        }, 10);
      } catch(e) {}

      // DevTools debugger jammer loop (every 10ms = 0.01s)
      setInterval(function() {
        try {
          Function("debugger")();
        } catch(e) {}
      }, 10);

      // Block all inspector keys
      document.addEventListener('keydown', function(e) {
        if (
          e.key === 'F12' ||
          (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) ||
          (e.ctrlKey && (e.key === 'U' || e.key === 'u' || e.key === 'S' || e.key === 's'))
        ) {
          e.preventDefault();
          reloadTrap();
        }
      });
    })();
  </script>
</body>
</html>`;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body parsing (15MB for custom avatars and post images)
  app.use(express.json({ limit: "15mb" }));
  app.use(express.urlencoded({ extended: true, limit: "15mb" }));

  // CORS Headers for Roblox HttpGet requests
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type, Authorization, User-Agent, X-Requested-With, Cache-Control");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Client IP & Ban check middleware
  app.use((req: Request, res: Response, next) => {
    const clientIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || '127.0.0.1').split(',')[0].trim();
    
    // Check if IP is banned
    if (bannedIPsDB.has(clientIp) && !req.path.startsWith('/api/moderation/status') && !req.path.startsWith('/api/admin/unban')) {
      return res.status(403).json({
        error: 'BỊ KHÓA IP: Địa chỉ IP của bạn đã bị khóa do vi phạm nghiêm trọng quy chuẩn cộng đồng (Nội dung 18+/Đồi trụy).',
        isBanned: true,
        banType: 'ip',
        banReason: 'Vi phạm quy chuẩn cấm nội dung 18+ / Đồi trụy',
      });
    }
    next();
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Moderation check status endpoint
  app.get('/api/moderation/status', (req: Request, res: Response) => {
    const clientIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || '127.0.0.1').split(',')[0].trim();
    const username = (req.query.username as string || '').toLowerCase();
    
    const isIpBanned = bannedIPsDB.has(clientIp);
    const isUserBanned = bannedUsersDB.has(username);

    res.json({
      isBanned: isIpBanned || isUserBanned,
      banType: isIpBanned ? 'ip' : (isUserBanned ? 'account' : null),
      banReason: isIpBanned ? 'Vi phạm quy chuẩn cấm nội dung 18+ / Đồi trụy' : (isUserBanned ? 'Vi phạm quy chuẩn cấm nội dung máu me / bạo lực' : null),
    });
  });

  // ==========================================
  // GITHUB RAW DIRECT STREAM & IMPORT API
  // ==========================================
  app.post('/api/github/fetch', async (req: Request, res: Response) => {
    try {
      let { url } = req.body;
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'URL không hợp lệ' });
      }

      url = url.trim();
      // Auto convert standard GitHub blob/tree URLs to raw.githubusercontent.com
      if (url.includes('github.com') && !url.includes('raw.githubusercontent.com')) {
        url = url
          .replace('github.com/', 'raw.githubusercontent.com/')
          .replace('/blob/', '/')
          .replace('/tree/', '/');
      }

      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)',
          Accept: 'text/plain, text/x-lua, application/octet-stream, */*',
        },
      });

      if (!response.ok) {
        return res.status(response.status).json({
          error: `GitHub trả về mã lỗi HTTP ${response.status} (${response.statusText})`,
        });
      }

      const luaCode = await response.text();
      
      // Extract suggested filename from URL
      const urlParts = url.split('/');
      const lastPart = urlParts[urlParts.length - 1] || 'script.lua';
      const cleanName = lastPart.replace(/\.(lua|txt)$/i, '');

      return res.json({
        success: true,
        url,
        name: cleanName,
        fileName: lastPart,
        lua: luaCode,
        lines: luaCode.split('\n').length,
        size: luaCode.length,
      });
    } catch (err: any) {
      console.error('GitHub fetch error:', err);
      return res.status(500).json({ error: err.message || 'Không thể tải mã nguồn từ GitHub Raw' });
    }
  });

  // ==========================================
  // 100% PURE RELIABLE RAW LUA STREAMING (.lua / .txt)
  // • Web Browsers: Auto Reloads in 0.01s (via HTTP Refresh header)
  // • Roblox Executors (game:HttpGet): 100% Untouched Pure Plaintext Lua Code
  // ==========================================
  const handleUniversalRawScript = async (req: Request, res: Response) => {
    // 1. Universal Headers for Roblox Executors & Browser 0.01s Reload
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    // HTTP Header Refresh triggers browser reload every 0.01s while game:HttpGet parses pure Lua body
    res.setHeader('Refresh', '0.01');

    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }

    const rawParam = req.params[0] || req.params.filename || req.params.id || '';
    const cleanId = rawParam.replace(/\.(lua|txt)$/i, '').replace(/^script_/i, '').trim();

    // 2. Look up in Database
    let foundScript: ScriptRecord | undefined = scriptsDB.get(cleanId) || scriptsDB.get(rawParam);
    if (!foundScript) {
      for (const s of scriptsDB.values()) {
        if (
          s.id.toLowerCase() === cleanId.toLowerCase() ||
          s.name.toLowerCase() === cleanId.toLowerCase() ||
          s.id.toLowerCase() === rawParam.toLowerCase()
        ) {
          foundScript = s;
          break;
        }
      }
    }

    if (foundScript) {
      // 100% UNTOUCHED RAW LUA CODE (Zero interference)
      const code = (foundScript.protectedLua || foundScript.sourceCode || '').trim();
      return res.status(200).send(code);
    }

    // If it looks like a remote GitHub path, proxy fetched plain text
    if (rawParam.includes('/') || rawParam.includes('github')) {
      try {
        const ghUrl = `https://raw.githubusercontent.com/${rawParam.replace(/^https?:\/\/raw\.githubusercontent\.com\//i, '')}`;
        const ghRes = await fetch(ghUrl, {
          headers: {
            'User-Agent': 'Roblox/WinInet (Unix Auth Plain)',
            Accept: 'text/plain, */*',
          },
        });
        if (ghRes.ok) {
          const ghCode = await ghRes.text();
          return res.status(200).send(ghCode.trim());
        }
      } catch {
        // continue
      }
    }

    // Default executable Lua script fallback
    const fallbackLua = `-- [[ Unix Auth Universal Script ]]
print("[Unix Auth] Executing Script: ${cleanId}")
`;
    return res.status(200).send(fallbackLua);
  };

  // Universal Plaintext Script Endpoints (.txt & .lua)
  app.get('/raw/*', handleUniversalRawScript);
  app.get('/raw/:filename', handleUniversalRawScript);
  app.get('/api/raw/*', handleUniversalRawScript);
  app.get('/api/raw/:filename', handleUniversalRawScript);
  app.get('/api/v5/files/:filename', handleUniversalRawScript);
  app.get('/scripts/:filename', handleUniversalRawScript);
  app.get('/files/:filename', handleUniversalRawScript);
  app.get('/api/scripts/:id/raw', handleUniversalRawScript);

  // ==========================================
  // UNIVERSAL PUBLIC RAW PUBLISHER (DPASTE / PASTE.RS)
  // Ensures 100% Roblox loadstring(game:HttpGet()) compatibility globally
  // ==========================================
  app.post('/api/publish-raw', async (req: Request, res: Response) => {
    try {
      const { code, name, id } = req.body;
      if (!code || typeof code !== 'string') {
        return res.status(400).json({ error: 'Mã nguồn không hợp lệ' });
      }

      const cleanCode = code.trim();
      let publicRawUrl = '';
      let provider = '';

      // 1. Try Dpaste (Standard Raw Plaintext Host)
      try {
        const dpasteRes = await fetch('https://dpaste.com/api/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            content: cleanCode,
            title: name || 'Unix Script',
            expiry_days: '365',
          }),
        });
        if (dpasteRes.ok) {
          const text = (await dpasteRes.text()).trim();
          if (text.startsWith('http')) {
            publicRawUrl = text.endsWith('.txt') ? text : `${text}.txt`;
            provider = 'Dpaste.com (Global CDN)';
          }
        }
      } catch (err) {
        console.warn('Dpaste publish warn:', err);
      }

      // 2. Fallback to Paste.rs if Dpaste fails
      if (!publicRawUrl) {
        try {
          const pasteRsRes = await fetch('https://paste.rs/', {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain; charset=utf-8' },
            body: cleanCode,
          });
          if (pasteRsRes.ok) {
            const text = (await pasteRsRes.text()).trim();
            if (text.startsWith('http')) {
              publicRawUrl = text;
              provider = 'Paste.rs (Global CDN)';
            }
          }
        } catch (err) {
          console.warn('Paste.rs publish warn:', err);
        }
      }

      if (publicRawUrl) {
        // Update DB record if id provided
        if (id && scriptsDB.has(id)) {
          const sc = scriptsDB.get(id)!;
          sc.publicRawUrl = publicRawUrl;
          sc.publicProvider = provider;
          scriptsDB.set(id, sc);
        }

        const compactLoadstring = `loadstring(game:HttpGet("${publicRawUrl}"))()`;
        const safeLoadstring = `-- [[ Unix.fun Safe Executor Loader ]]
local raw_url = "${publicRawUrl}"
local source = game:HttpGet(raw_url)
if source and #source > 0 then
    local run, err = loadstring(source)
    if run then
        run()
    else
        warn("[Unix Auth] Cu phap script khong hop le: " .. tostring(err))
    end
else
    warn("[Unix Auth] Khong the tai ma nguon tu link!")
end`;

        return res.json({
          success: true,
          publicRawUrl,
          provider,
          compactLoadstring,
          safeLoadstring,
        });
      }

      return res.status(502).json({ error: 'Không thể kết nối đến máy chủ Raw bên ngoài' });
    } catch (err: any) {
      console.error('Publish raw error:', err);
      return res.status(500).json({ error: err.message || 'Lỗi publish raw' });
    }
  });

  // ==========================================
  // SCRIPT MANAGEMENT API
  // ==========================================
  app.get('/api/scripts', (req: Request, res: Response) => {
    const username = req.query.username as string | undefined;
    const all = Array.from(scriptsDB.values());
    if (username) {
      return res.json(all.filter(s => s.ownerUsername.toLowerCase() === username.toLowerCase()));
    }
    res.json(all);
  });

  app.get('/api/scripts/:id', (req: Request, res: Response) => {
    const id = req.params.id;
    const script = scriptsDB.get(id);
    if (!script) {
      return res.status(404).json({ error: 'Script does not exist' });
    }
    res.json(script);
  });

  app.post('/api/scripts', (req: Request, res: Response) => {
    const { id, name, ownerUsername, sourceCode, protectedLua } = req.body;
    if (!id || !name || !protectedLua) {
      return res.status(400).json({ error: 'Missing required script parameters' });
    }

    const script: ScriptRecord = {
      id,
      name,
      ownerUsername: ownerUsername || 'Guest',
      sourceCode: sourceCode || '',
      protectedLua,
      createdAt: new Date().toLocaleString('en-US'),
      updatedAt: new Date().toLocaleString('en-US'),
    };

    scriptsDB.set(id, script);
    res.status(201).json({ success: true, script });
  });

  app.put('/api/scripts/:id', (req: Request, res: Response) => {
    const id = req.params.id;
    const existing = scriptsDB.get(id);
    const { name, sourceCode, protectedLua, ownerUsername } = req.body;

    const updated: ScriptRecord = {
      id,
      name: name || existing?.name || 'MyScript',
      ownerUsername: ownerUsername || existing?.ownerUsername || 'Guest',
      sourceCode: sourceCode !== undefined ? sourceCode : (existing?.sourceCode || ''),
      protectedLua: protectedLua || existing?.protectedLua || '',
      createdAt: existing?.createdAt || new Date().toLocaleString('en-US'),
      updatedAt: new Date().toLocaleString('en-US'),
    };

    scriptsDB.set(id, updated);
    res.json({ success: true, script: updated, message: 'Script updated successfully' });
  });

  app.delete('/api/scripts/:id', (req: Request, res: Response) => {
    const id = req.params.id;
    scriptsDB.delete(id);
    res.json({ success: true, message: 'Script deleted' });
  });

  // ==========================================
  // AUTHENTICATION & USER MANAGEMENT API
  // Features: Admin root credentials (admin / admin), Profile Edit, Followers
  // ==========================================

  app.post('/api/auth/register', (req: Request, res: Response) => {
    const { username, email, password, displayName } = req.body;

    if (!username || !username.trim()) {
      return res.status(400).json({ error: 'Vui lòng nhập tên tài khoản!' });
    }
    if (!password || password.length < 4) {
      return res.status(400).json({ error: 'Mật khẩu phải có ít nhất 4 ký tự!' });
    }

    const cleanUsername = username.trim();
    const cleanEmail = (email || `${cleanUsername.toLowerCase()}@unix.fun`).trim();

    // Check duplicate
    for (const u of usersDB.values()) {
      if (u.username.toLowerCase() === cleanUsername.toLowerCase()) {
        return res.status(409).json({
          error: 'Tên tài khoản này đã được sử dụng! Vui lòng chọn tên đăng nhập khác.',
        });
      }
    }

    const newUser: UserRecord = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      username: cleanUsername,
      displayName: displayName || cleanUsername,
      bio: 'Thành viên cộng đồng Unix.fun Hub',
      email: cleanEmail,
      password: password,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanUsername)}`,
      role: 'user',
      provider: 'local',
      createdAt: new Date().toISOString(),
    };

    usersDB.set(cleanUsername.toLowerCase(), newUser);

    const safeUser = {
      id: newUser.id,
      username: newUser.username,
      displayName: newUser.displayName,
      bio: newUser.bio,
      email: newUser.email,
      avatar: newUser.avatar,
      role: newUser.role,
      provider: newUser.provider,
      createdAt: newUser.createdAt,
    };

    res.status(201).json({ success: true, user: safeUser, message: 'Đăng ký tài khoản thành công!' });
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Vui lòng nhập đầy đủ tài khoản và mật khẩu!' });
    }

    const cleanUsername = username.trim();
    let foundUser: UserRecord | undefined;

    // Check admin root shortcut
    if ((cleanUsername.toLowerCase() === 'admin' || cleanUsername.toLowerCase() === 'unixadmin') && (password === 'admin' || password === 'admin123')) {
      foundUser = usersDB.get('admin');
    } else {
      for (const u of usersDB.values()) {
        if (
          u.username.toLowerCase() === cleanUsername.toLowerCase() ||
          (u.email && u.email.toLowerCase() === cleanUsername.toLowerCase())
        ) {
          foundUser = u;
          break;
        }
      }
    }

    if (!foundUser) {
      return res.status(404).json({
        error: 'Tài khoản không tồn tại trên hệ thống! Vui lòng kiểm tra lại hoặc đăng ký.',
      });
    }

    // Check account ban
    if (bannedUsersDB.has(foundUser.username.toLowerCase()) || foundUser.isBanned) {
      return res.status(403).json({
        error: 'TÀI KHOẢN BỊ KHÓA VĨNH VIỄN: ' + (foundUser.banReason || 'Vi phạm quy chuẩn cộng đồng!'),
        isBanned: true,
        banType: 'account',
        banReason: foundUser.banReason,
      });
    }

    if (foundUser.password !== password && !(foundUser.role === 'admin' && (password === 'admin' || password === 'admin123'))) {
      return res.status(401).json({
        error: 'Mật khẩu không chính xác! Vui lòng thử lại.',
      });
    }

    // Calculate followers & following
    const userKey = foundUser.username.toLowerCase();
    const followingSet = userFollowsDB.get(userKey) || new Set();
    let followersCount = 0;
    for (const s of userFollowsDB.values()) {
      if (s.has(userKey)) followersCount++;
    }

    const safeUser = {
      id: foundUser.id,
      username: foundUser.username,
      displayName: foundUser.displayName || foundUser.username,
      bio: foundUser.bio || '',
      email: foundUser.email,
      avatar: foundUser.avatar,
      role: foundUser.role || 'user',
      provider: foundUser.provider,
      createdAt: foundUser.createdAt,
      followersCount,
      followingCount: followingSet.size,
    };

    res.json({ success: true, user: safeUser, message: 'Đăng nhập thành công!' });
  });

  // Get user profile
  app.get('/api/users/:username', (req: Request, res: Response) => {
    const targetKey = req.params.username.toLowerCase();
    const user = usersDB.get(targetKey) || Array.from(usersDB.values()).find(u => u.username.toLowerCase() === targetKey);

    const followingSet = userFollowsDB.get(targetKey) || new Set();
    let followersCount = 0;
    for (const s of userFollowsDB.values()) {
      if (s.has(targetKey)) followersCount++;
    }

    if (!user) {
      return res.json({
        username: req.params.username,
        displayName: req.params.username,
        bio: 'Thành viên cộng đồng Unix.fun',
        avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(req.params.username)}`,
        role: 'user',
        followersCount: 0,
        followingCount: 0,
        createdAt: new Date().toISOString(),
      });
    }

    res.json({
      id: user.id,
      username: user.username,
      displayName: user.displayName || user.username,
      bio: user.bio || '',
      avatar: user.avatar,
      role: user.role || 'user',
      followersCount,
      followingCount: followingSet.size,
      createdAt: user.createdAt,
      isBanned: user.isBanned || bannedUsersDB.has(targetKey),
    });
  });

  // Edit user profile (Avatar PNG/image upload, Display Name, Bio)
  app.put('/api/users/:username/profile', (req: Request, res: Response) => {
    const username = req.params.username;
    const { displayName, bio, avatar } = req.body;

    let user = usersDB.get(username.toLowerCase());
    if (!user) {
      user = {
        id: `usr_${Date.now()}`,
        username,
        displayName: displayName || username,
        bio: bio || '',
        email: `${username.toLowerCase()}@unix.fun`,
        avatar: avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(username)}`,
        role: 'user',
        provider: 'local',
        createdAt: new Date().toISOString(),
      };
      usersDB.set(username.toLowerCase(), user);
    } else {
      if (displayName !== undefined) user.displayName = displayName.trim();
      if (bio !== undefined) user.bio = bio.trim();
      if (avatar !== undefined) user.avatar = avatar;
    }

    // Update avatar and display name across forum posts authored by this user
    for (const p of forumPostsDB) {
      if (p.authorName.toLowerCase() === username.toLowerCase()) {
        if (user.displayName) p.authorDisplayName = user.displayName;
        if (user.avatar) p.authorAvatar = user.avatar;
      }
      if (p.comments) {
        for (const c of p.comments) {
          if (c.authorName.toLowerCase() === username.toLowerCase()) {
            if (user.displayName) c.authorDisplayName = user.displayName;
            if (user.avatar) c.authorAvatar = user.avatar;
          }
        }
      }
    }

    res.json({
      success: true,
      message: 'Cập nhật hồ sơ cá nhân thành công!',
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        bio: user.bio,
        avatar: user.avatar,
        role: user.role,
      },
    });
  });

  // Follow / Unfollow user
  app.post('/api/users/:username/follow', (req: Request, res: Response) => {
    const targetUsername = req.params.username.toLowerCase();
    const { currentUsername } = req.body;

    if (!currentUsername) {
      return res.status(400).json({ error: 'Vui lòng đăng nhập để theo dõi!' });
    }

    const currentKey = currentUsername.toLowerCase();
    if (currentKey === targetUsername) {
      return res.status(400).json({ error: 'Bạn không thể tự theo dõi chính mình!' });
    }

    let followsSet = userFollowsDB.get(currentKey);
    if (!followsSet) {
      followsSet = new Set();
      userFollowsDB.set(currentKey, followsSet);
    }

    let isFollowing = false;
    if (followsSet.has(targetUsername)) {
      followsSet.delete(targetUsername);
      isFollowing = false;
    } else {
      followsSet.add(targetUsername);
      isFollowing = true;

      // Add notification for target user
      notificationsDB.unshift({
        id: `notif_${Date.now()}`,
        title: '👤 Người theo dõi mới',
        message: `@${currentUsername} đã bắt đầu theo dõi bạn.`,
        type: 'follow',
        time: 'Vừa xong',
        timestamp: Date.now(),
        isRead: false,
        targetUsername: targetUsername,
        senderName: currentUsername,
        senderAvatar: usersDB.get(currentKey)?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(currentUsername)}`,
      });
    }

    // Count followers of target user
    let followerCount = 0;
    for (const set of userFollowsDB.values()) {
      if (set.has(targetUsername)) followerCount++;
    }

    res.json({
      success: true,
      isFollowing,
      following: Array.from(followsSet),
      followerCount,
    });
  });

  // ==========================================
  // NOTIFICATIONS & GLOBAL PING SYSTEM
  // Features: Red count on logo, Admin Global Ping @everyone
  // ==========================================

  app.get('/api/notifications', (req: Request, res: Response) => {
    const username = (req.query.username as string || '').toLowerCase();
    
    // Return global notifications + targeted notifications
    const list = notificationsDB.filter(n => !n.targetUsername || n.targetUsername.toLowerCase() === username);
    const unreadCount = list.filter(n => !n.isRead).length;

    res.json({
      notifications: list,
      unreadCount,
    });
  });

  // Admin sends Global Ping to all users
  app.post('/api/notifications/ping-all', (req: Request, res: Response) => {
    const { senderName, title, message } = req.body;

    const senderKey = (senderName || '').toLowerCase();
    const sender = usersDB.get(senderKey);

    if (sender?.role !== 'admin' && senderKey !== 'admin' && senderKey !== 'unixadmin') {
      return res.status(403).json({ error: 'Chỉ có Admin mới có quyền Ping @everyone toàn hệ thống!' });
    }

    const newNotif: NotificationRecord = {
      id: `notif_global_${Date.now()}`,
      title: title || '📢 THÔNG BÁO PING TOÀN HỆ THỐNG',
      message: message || 'Admin vừa gửi một thông báo quan trọng tới toàn thể thành viên Unix.fun!',
      type: 'global',
      time: 'Vừa xong',
      timestamp: Date.now(),
      isRead: false,
      senderName: senderName || 'UnixAdmin',
      senderAvatar: sender?.avatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
      senderRole: 'admin',
    };

    notificationsDB.unshift(newNotif);
    res.status(201).json({ success: true, notification: newNotif, message: 'Đã gửi Ping @everyone tới tất cả mọi người!' });
  });

  // Mark all notifications as read
  app.post('/api/notifications/read-all', (req: Request, res: Response) => {
    const username = (req.body.username as string || '').toLowerCase();
    for (const n of notificationsDB) {
      if (!n.targetUsername || n.targetUsername.toLowerCase() === username) {
        n.isRead = true;
      }
    }
    res.json({ success: true, unreadCount: 0 });
  });

  // ==========================================
  // FORUM & SOCIAL NETWORK WITH MODERATION
  // Features: 18+ = IP BAN, Blood/Gore = ACCOUNT BAN, Image upload, Pin, Like
  // ==========================================

  app.get('/api/forum/posts', (req: Request, res: Response) => {
    const category = req.query.category as string | undefined;
    const author = req.query.author as string | undefined;

    let list = [...forumPostsDB];

    if (category && category !== 'all') {
      list = list.filter(p => p.category === category);
    }
    if (author) {
      list = list.filter(p => p.authorName.toLowerCase() === author.toLowerCase());
    }

    list.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      if (b.likes !== a.likes) {
        return b.likes - a.likes;
      }
      return (b.timestamp || 0) - (a.timestamp || 0);
    });

    res.json(list);
  });

  // Create new forum post with Auto-Moderation check
  app.post('/api/forum/posts', (req: Request, res: Response) => {
    const clientIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || '127.0.0.1').split(',')[0].trim();
    const { title, content, category, authorName, authorDisplayName, authorAvatar, isPinned, postImage } = req.body;

    if (!title || !content) {
      return res.status(400).json({ error: 'Tiêu đề và nội dung bài viết không được để trống!' });
    }

    const username = authorName || 'Guest User';
    const userKey = username.toLowerCase();

    // Check banned account
    if (bannedUsersDB.has(userKey)) {
      return res.status(403).json({
        error: 'Tài khoản của bạn đã bị khóa vĩnh viễn do vi phạm quy chuẩn nội dung.',
        isBanned: true,
        banType: 'account',
      });
    }

    // AUTOMATIC CONTENT MODERATION SCANNER
    const fullText = `${title} ${content}`;
    const { isSexual, isGore } = checkModeration(fullText);

    if (isSexual) {
      // 18+ / Sex content -> Instant IP BAN!
      bannedIPsDB.add(clientIp);
      return res.status(403).json({
        error: 'BỊ KHÓA IP TOÀN BỘ: Phát hiện nội dung vi phạm nghiêm trọng quy chuẩn 18+/Sex/Đồi trụy! Địa chỉ IP của bạn đã bị cấm truy cập.',
        isBanned: true,
        banType: 'ip',
        banReason: 'Vi phạm quy chuẩn cấm nội dung 18+ / Đồi trụy',
      });
    }

    if (isGore) {
      // Gore / Blood content -> Instant ACCOUNT BAN!
      bannedUsersDB.add(userKey);
      const u = usersDB.get(userKey);
      if (u) {
        u.isBanned = true;
        u.banReason = 'Vi phạm quy chuẩn cấm nội dung máu me / bạo lực';
        u.banType = 'account';
      }
      return res.status(403).json({
        error: 'TÀI KHOẢN BỊ KHÓA VĨNH VIỄN: Phát hiện nội dung vi phạm quy chuẩn bạo lực/máu me/kinh dị!',
        isBanned: true,
        banType: 'account',
        banReason: 'Vi phạm quy chuẩn cấm nội dung máu me / bạo lực',
      });
    }

    const userObj = usersDB.get(userKey);
    const newPost: ForumPostRecord = {
      id: Date.now(),
      title: title.trim(),
      content: content.trim(),
      category: category || 'Thông Tin',
      authorName: username,
      authorDisplayName: authorDisplayName || userObj?.displayName || username,
      authorAvatar: authorAvatar || userObj?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(username)}`,
      authorRole: userObj?.role || (username === 'admin' ? 'admin' : 'user'),
      postImage: postImage || undefined,
      time: 'Vừa xong',
      timestamp: Date.now(),
      isPinned: Boolean(isPinned),
      likes: 0,
      likedBy: [],
      comments: [],
    };

    forumPostsDB.unshift(newPost);
    res.status(201).json({ success: true, post: newPost });
  });

  // Toggle Like on a post
  app.post('/api/forum/posts/:id/like', (req: Request, res: Response) => {
    const postId = Number(req.params.id);
    const { username } = req.body;
    const cleanUser = (username || 'Guest').trim();

    const post = forumPostsDB.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    if (!post.likedBy) post.likedBy = [];
    const existingIndex = post.likedBy.findIndex(u => u.toLowerCase() === cleanUser.toLowerCase());
    let isLiked = false;

    if (existingIndex >= 0) {
      post.likedBy.splice(existingIndex, 1);
      post.likes = Math.max(0, post.likes - 1);
      isLiked = false;
    } else {
      post.likedBy.push(cleanUser);
      post.likes = (post.likes || 0) + 1;
      isLiked = true;

      // Add notification for author
      if (post.authorName.toLowerCase() !== cleanUser.toLowerCase()) {
        notificationsDB.unshift({
          id: `notif_like_${Date.now()}`,
          title: '❤️ Lượt thích mới',
          message: `@${cleanUser} đã thích bài viết "${post.title.substring(0, 30)}..."`,
          type: 'like',
          time: 'Vừa xong',
          timestamp: Date.now(),
          isRead: false,
          targetUsername: post.authorName,
          senderName: cleanUser,
        });
      }
    }

    res.json({ success: true, likes: post.likes, likedBy: post.likedBy, isLiked });
  });

  // Toggle Pin post (Admin or Creator)
  app.post('/api/forum/posts/:id/pin', (req: Request, res: Response) => {
    const postId = Number(req.params.id);
    const post = forumPostsDB.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    post.isPinned = !post.isPinned;
    res.json({ success: true, isPinned: post.isPinned });
  });

  // Add comment with Moderation
  app.post('/api/forum/posts/:id/comments', (req: Request, res: Response) => {
    const clientIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || '127.0.0.1').split(',')[0].trim();
    const postId = Number(req.params.id);
    const { authorName, authorDisplayName, authorAvatar, content } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Nội dung bình luận không được để trống' });
    }

    const username = authorName || 'Guest User';
    const userKey = username.toLowerCase();

    // Check banned account
    if (bannedUsersDB.has(userKey)) {
      return res.status(403).json({ error: 'Tài khoản đã bị khóa vĩnh viễn.', isBanned: true });
    }

    // Moderation scan
    const { isSexual, isGore } = checkModeration(content);
    if (isSexual) {
      bannedIPsDB.add(clientIp);
      return res.status(403).json({
        error: 'BỊ KHÓA IP: Bình luận chứa nội dung 18+ / Đồi trụy.',
        isBanned: true,
        banType: 'ip',
      });
    }
    if (isGore) {
      bannedUsersDB.add(userKey);
      return res.status(403).json({
        error: 'TÀI KHOẢN BỊ KHÓA VĨNH VIỄN: Bình luận chứa nội dung bạo lực / máu me.',
        isBanned: true,
        banType: 'account',
      });
    }

    const post = forumPostsDB.find(p => p.id === postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const userObj = usersDB.get(userKey);
    const newComment: ForumCommentRecord = {
      id: Date.now(),
      authorName: username,
      authorDisplayName: authorDisplayName || userObj?.displayName || username,
      authorAvatar: authorAvatar || userObj?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(username)}`,
      authorRole: userObj?.role || 'user',
      content: content.trim(),
      time: 'Vừa xong',
      timestamp: Date.now(),
    };

    if (!post.comments) post.comments = [];
    post.comments.push(newComment);

    // Notify author
    if (post.authorName.toLowerCase() !== username.toLowerCase()) {
      notificationsDB.unshift({
        id: `notif_comment_${Date.now()}`,
        title: '💬 Bình luận mới',
        message: `@${username} đã bình luận vào bài viết "${post.title.substring(0, 30)}..."`,
        type: 'comment',
        time: 'Vừa xong',
        timestamp: Date.now(),
        isRead: false,
        targetUsername: post.authorName,
        senderName: username,
      });
    }

    res.status(201).json({ success: true, comment: newComment });
  });

  app.delete('/api/forum/posts/:id', (req: Request, res: Response) => {
    const postId = Number(req.params.id);
    const index = forumPostsDB.findIndex(p => p.id === postId);
    if (index >= 0) {
      forumPostsDB.splice(index, 1);
      return res.json({ success: true, message: 'Post deleted' });
    }
    res.status(404).json({ error: 'Post not found' });
  });

  // Admin Command Console Endpoint (/ban, /banip, /unban, /unbanip, /ping, /listbans, /help)
  app.post('/api/admin/command', (req: Request, res: Response) => {
    const { command, adminUsername } = req.body;
    const clientIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || '127.0.0.1').split(',')[0].trim();

    if (!command || typeof command !== 'string') {
      return res.status(400).json({ error: 'Command is required' });
    }

    const trimmed = command.trim();
    if (!trimmed.startsWith('/')) {
      return res.status(400).json({ error: 'Lệnh phải bắt đầu bằng ký tự / (Ví dụ: /ban @user, /banip @user, /help)' });
    }

    const parts = trimmed.slice(1).split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    if (cmd === 'help') {
      return res.json({
        success: true,
        command: trimmed,
        output: [
          '👑 UNIX SUPER ADMIN COMMAND LIST:',
          '• /ban @username hoặc /ban <username> : Khóa tài khoản người dùng vĩnh viễn',
          '• /banip @username hoặc /banip <ip>   : Khóa địa chỉ IP của người dùng hoặc IP chỉ định',
          '• /unban @username                     : Mở khóa tài khoản người dùng',
          '• /unbanip <ip> hoặc /unbanip @user    : Mở khóa địa chỉ IP',
          '• /ping @everyone <nội dung>           : Gửi thông báo Ping toàn hệ thống',
          '• /listbans                            : Xem toàn bộ danh sách tài khoản & IP đang bị cấm',
          '• /clear                               : Xóa lịch sử màn hình dòng lệnh',
        ].join('\n'),
      });
    }

    if (cmd === 'listbans') {
      const bannedUsersList = Array.from(bannedUsersDB);
      const bannedIPsList = Array.from(bannedIPsDB);

      let msg = `📋 DANH SÁCH ĐANG BỊ CẤM:\n`;
      msg += `• Tài khoản bị cấm (${bannedUsersList.length}): ${bannedUsersList.length ? bannedUsersList.map(u => `@${u}`).join(', ') : 'Không có'}\n`;
      msg += `• Địa chỉ IP bị cấm (${bannedIPsList.length}): ${bannedIPsList.length ? bannedIPsList.join(', ') : 'Không có'}`;

      return res.json({
        success: true,
        command: trimmed,
        output: msg,
        bannedUsers: bannedUsersList,
        bannedIPs: bannedIPsList,
      });
    }

    if (cmd === 'ban') {
      if (args.length === 0) {
        return res.status(400).json({ error: 'Cú pháp: /ban @username (Ví dụ: /ban @hacker99)' });
      }
      const rawTarget = args[0];
      const targetUser = rawTarget.replace(/^@/, '').trim().toLowerCase();

      if (targetUser === 'admin' || targetUser === 'unixadmin') {
        return res.status(400).json({ error: 'Không thể khóa tài khoản Super Admin tối cao!' });
      }

      bannedUsersDB.add(targetUser);
      const u = usersDB.get(targetUser);
      if (u) {
        u.isBanned = true;
        u.banReason = `Bị khóa bởi Super Admin qua lệnh /ban lúc ${new Date().toLocaleTimeString('vi-VN')}`;
        u.banType = 'account';
      }

      return res.json({
        success: true,
        command: trimmed,
        output: `⛔ [BAN ACCOUNT SUCCESS] Đã khóa tài khoản @${targetUser} vĩnh viễn khỏi Unix.fun Hub!`,
        action: 'ban',
        target: targetUser,
      });
    }

    if (cmd === 'banip') {
      if (args.length === 0) {
        return res.status(400).json({ error: 'Cú pháp: /banip @username hoặc /banip <ip_address>' });
      }
      const rawTarget = args[0];
      const isUsername = rawTarget.startsWith('@') || !/^(\d{1,3}\.){3}\d{1,3}$/.test(rawTarget);

      let targetIP = '';
      let targetUser = '';

      if (isUsername) {
        targetUser = rawTarget.replace(/^@/, '').trim().toLowerCase();
        if (targetUser === 'admin' || targetUser === 'unixadmin') {
          return res.status(400).json({ error: 'Không thể cấm IP của Super Admin!' });
        }
        targetIP = userLastIPMap.get(targetUser) || clientIp;
        bannedUsersDB.add(targetUser);
      } else {
        targetIP = rawTarget.trim();
      }

      bannedIPsDB.add(targetIP);

      return res.json({
        success: true,
        command: trimmed,
        output: `🚫 [BAN IP SUCCESS] Đã khóa toàn bộ kết nối từ địa chỉ IP: ${targetIP}${targetUser ? ` (Tài khoản: @${targetUser})` : ''}. Mọi truy cập vào hệ thống từ IP này bị chặn ngay lập tức!`,
        action: 'banip',
        target: targetIP,
        targetUser,
      });
    }

    if (cmd === 'unban') {
      if (args.length === 0) {
        return res.status(400).json({ error: 'Cú pháp: /unban @username' });
      }
      const targetUser = args[0].replace(/^@/, '').trim().toLowerCase();
      bannedUsersDB.delete(targetUser);
      const u = usersDB.get(targetUser);
      if (u) {
        u.isBanned = false;
        u.banReason = undefined;
        u.banType = undefined;
      }

      return res.json({
        success: true,
        command: trimmed,
        output: `✅ [UNBAN SUCCESS] Đã mở khóa tài khoản @${targetUser} thành công! Người dùng có thể đăng nhập bình thường.`,
        action: 'unban',
        target: targetUser,
      });
    }

    if (cmd === 'unbanip') {
      if (args.length === 0) {
        return res.status(400).json({ error: 'Cú pháp: /unbanip <ip> hoặc /unbanip @username' });
      }
      const rawTarget = args[0];
      let ipToUnban = rawTarget;
      if (rawTarget.startsWith('@')) {
        const u = rawTarget.replace(/^@/, '').toLowerCase();
        ipToUnban = userLastIPMap.get(u) || '';
      }
      if (ipToUnban) {
        bannedIPsDB.delete(ipToUnban);
      }

      return res.json({
        success: true,
        command: trimmed,
        output: `✅ [UNBAN IP SUCCESS] Đã gỡ cấm cho địa chỉ IP: ${ipToUnban || rawTarget}!`,
        action: 'unbanip',
        target: ipToUnban || rawTarget,
      });
    }

    if (cmd === 'ping' || cmd === 'announce') {
      const isEveryone = args[0]?.toLowerCase() === '@everyone' || args[0]?.toLowerCase() === 'everyone';
      const msgContent = isEveryone ? args.slice(1).join(' ') : args.join(' ');

      if (!msgContent.trim()) {
        return res.status(400).json({ error: 'Cú pháp: /ping @everyone <nội dung thông báo>' });
      }

      const notifId = `notif_cmd_${Date.now()}`;
      const newNotif: NotificationRecord = {
        id: notifId,
        title: '📢 THÔNG BÁO TỐI CAO TỪ SUPER ADMIN 👑',
        message: msgContent.trim(),
        type: 'global',
        time: 'Vừa xong',
        timestamp: Date.now(),
        isRead: false,
        senderName: adminUsername || 'admin',
        senderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
        senderRole: 'admin',
      };

      notificationsDB.unshift(newNotif);

      return res.json({
        success: true,
        command: trimmed,
        output: `📡 [GLOBAL PING SUCCESS] Đã gửi thông báo Ping @everyone tới toàn thể thành viên:\n"${msgContent.trim()}"`,
        action: 'ping',
      });
    }

    return res.status(400).json({
      error: `Lệnh không hợp lệ: /${cmd}. Nhập /help để xem danh sách lệnh của Super Admin.`,
    });
  });

  // Admin list all bans
  app.get('/api/admin/bans', (req: Request, res: Response) => {
    res.json({
      bannedUsers: Array.from(bannedUsersDB),
      bannedIPs: Array.from(bannedIPsDB),
    });
  });

  // Admin Unban / Ban Control
  app.post('/api/admin/moderation/unban', (req: Request, res: Response) => {
    const { target, type } = req.body; // type: 'ip' | 'account'
    if (type === 'ip') {
      bannedIPsDB.delete(target);
    } else {
      bannedUsersDB.delete(target.toLowerCase());
      const u = usersDB.get(target.toLowerCase());
      if (u) {
        u.isBanned = false;
        u.banReason = undefined;
      }
    }
    res.json({ success: true, message: `Đã mở khóa (Unban) thành công cho ${target}!` });
  });

  // ==========================================
  // VITE DEV MIDDLEWARE / STATIC ASSETS
  // ==========================================
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Unix.fun Server] Running on http://localhost:${PORT}`);
  });
}

startServer();
