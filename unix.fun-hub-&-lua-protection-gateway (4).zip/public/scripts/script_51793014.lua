--[[
  UNIX.FUN MAXIMUM LUA PROTECTION
  Script ID: 51793014
  Base: https://unixfun.netlify.app/protected.html?script=51793014
--]]

local _payload = "\\085\\110\\105\\120\\046\\102\\117\\110\\032\\083\\099\\114\\105\\112\\116\\032\\076\\111\\097\\100\\101\\100"
local function _decode(str)
  local t = {}
  for i = 1, #str do
    t[i] = string.char(string.byte(str, i))
  end
  return table.concat(t)
end

print("[Unix.fun] Script #51793014 loaded and executed successfully!")
