import React from 'react';
import { UserAccount } from '../types';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tabId: string) => void;
  currentUser: UserAccount | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenProfile: (username: string) => void;
  onOpenNotifications: () => void;
  unreadNotificationsCount: number;
  lang: 'vi' | 'en';
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onOpenAuth,
  onLogout,
  onOpenProfile,
  onOpenNotifications,
  unreadNotificationsCount,
  lang,
}) => {
  const navItems = [
    { id: 'download', icon: 'fa-download', labelVi: 'Download', labelEn: 'Download' },
    { id: 'scripthub', icon: 'fa-code', labelVi: 'Script Hub', labelEn: 'Script Hub' },
    { id: 'obfuscator', icon: 'fa-shield-halved', labelVi: 'Lua Obfuscator', labelEn: 'Lua Obfuscator' },
    { id: 'protection', icon: 'fa-file-shield', labelVi: 'Lua Protection', labelEn: 'Lua Protection' },
    { id: 'forum', icon: 'fa-comments', labelVi: 'Diễn Đàn', labelEn: 'Forum' },
  ];

  return (
    <aside
      style={{
        width: '270px',
        background: 'var(--sidebar-bg)',
        borderRight: '1px solid var(--border-color)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        padding: '24px 18px',
        position: 'sticky',
        top: 0,
        height: '100vh',
        zIndex: 10,
        flexShrink: 0,
      }}
      className="sidebar-container"
    >
      <div>
        {/* Top Logo with Red Notification Badge */}
        <div
          onClick={() => onSelectTab('download')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '14px',
            textDecoration: 'none',
            color: 'var(--text-main)',
            padding: '10px 12px',
            borderRadius: '12px',
            background: 'rgba(255, 255, 255, 0.02)',
            border: '1px solid var(--border-color)',
            marginBottom: '24px',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            position: 'relative',
          }}
          className="hover:border-[#ff2a6d] hover:shadow-[0_0_12px_rgba(255,42,109,0.35)]"
        >
          {/* Logo with Discord-style Red Ping Badge */}
          <div
            style={{
              position: 'relative',
              fontSize: '24px',
              fontWeight: 900,
              background: 'rgba(255, 255, 255, 0.05)',
              padding: '6px 12px',
              borderRadius: '8px',
              border: '1px solid var(--border-color)',
              letterSpacing: '-1px',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <span style={{ color: '#fff' }}>U</span>
            <span style={{ color: 'var(--primary-pink)' }}>X</span>

            {/* Red Notification Badge exactly matching the uploaded screenshot */}
            {unreadNotificationsCount > 0 && (
              <span
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenNotifications();
                }}
                title={lang === 'vi' ? `${unreadNotificationsCount} thông báo mới (Bấm để xem)` : `${unreadNotificationsCount} unread notifications`}
                style={{
                  position: 'absolute',
                  top: '-7px',
                  right: '-7px',
                  backgroundColor: '#ff1744',
                  color: '#ffffff',
                  fontSize: '11px',
                  fontWeight: 900,
                  width: '20px',
                  height: '20px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 0 10px rgba(255, 23, 68, 0.8), 0 0 2px #fff',
                  border: '2px solid #07070a',
                  zIndex: 20,
                  animation: 'pulse 1.8s infinite',
                }}
              >
                {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
              </span>
            )}
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ fontWeight: 700, fontSize: '17px', display: 'block' }}>Unix.fun Hub</span>
            </div>
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Advanced Edition</span>
          </div>
        </div>

        {/* Navigation Items */}
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '12px 16px',
                  color: isActive ? '#fff' : 'var(--text-muted)',
                  background: isActive ? 'rgba(255, 42, 109, 0.15)' : 'transparent',
                  borderColor: isActive ? 'rgba(255, 42, 109, 0.3)' : 'transparent',
                  boxShadow: isActive ? '0 0 15px rgba(255, 42, 109, 0.15)' : 'none',
                  borderRadius: '12px',
                  fontWeight: 600,
                  fontSize: '14px',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.2s ease',
                  width: '100%',
                }}
                className={isActive ? '' : 'hover:text-white hover:bg-[rgba(255,42,109,0.1)]'}
              >
                <i className={`fa-solid ${item.icon}`} style={{ width: '18px', textAlign: 'center' }}></i>
                <span>{lang === 'vi' ? item.labelVi : item.labelEn}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* User Account / Profile Box at Bottom */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          padding: '12px',
          background: 'rgba(255, 255, 255, 0.02)',
          borderRadius: '14px',
          border: '1px solid var(--border-color)',
          marginTop: 'auto',
        }}
      >
        {currentUser ? (
          <>
            <div
              onClick={() => onOpenProfile(currentUser.username)}
              title={lang === 'vi' ? 'Xem & Chỉnh sửa Profile của bạn' : 'View & Edit Profile'}
              style={{
                width: '38px',
                height: '38px',
                borderRadius: '10px',
                overflow: 'hidden',
                cursor: 'pointer',
                border: '1px solid rgba(255, 42, 109, 0.5)',
                boxShadow: '0 0 10px rgba(255, 42, 109, 0.3)',
                flexShrink: 0,
              }}
            >
              <img
                src={
                  currentUser.avatar ||
                  `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(currentUser.username)}`
                }
                alt=""
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
            </div>

            <div
              onClick={() => onOpenProfile(currentUser.username)}
              style={{ flexGrow: 1, overflow: 'hidden', cursor: 'pointer' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <p
                  style={{
                    fontSize: '13px',
                    fontWeight: 700,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    color: '#fff',
                    margin: 0,
                  }}
                  title={currentUser.displayName || currentUser.username}
                >
                  {currentUser.displayName || currentUser.username}
                </p>
                {(currentUser.role === 'admin' || currentUser.username.toLowerCase() === 'admin') && (
                  <span
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '3px',
                      backgroundColor: 'rgba(239, 68, 68, 0.2)',
                      color: '#f87171',
                      border: '1px solid rgba(239, 68, 68, 0.5)',
                      borderRadius: '10px',
                      padding: '1px 5px',
                      fontSize: '9.5px',
                      fontWeight: 800,
                      boxShadow: '0 0 6px rgba(239, 68, 68, 0.3)',
                    }}
                  >
                    <span
                      style={{
                        width: '5px',
                        height: '5px',
                        borderRadius: '50%',
                        backgroundColor: '#ef4444',
                        boxShadow: '0 0 5px #ef4444',
                        display: 'inline-block',
                      }}
                    />
                    <span>Admin</span>
                  </span>
                )}
              </div>
              <p style={{ fontSize: '11px', color: 'var(--text-muted)', margin: 0 }}>
                @{currentUser.username}
              </p>
            </div>

            <button
              onClick={onLogout}
              title={lang === 'vi' ? 'Đăng xuất' : 'Sign Out'}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#f85149',
                cursor: 'pointer',
                fontSize: '15px',
                padding: '4px',
              }}
            >
              <i className="fa-solid fa-right-from-bracket"></i>
            </button>
          </>
        ) : (
          <>
            <div
              style={{
                width: '38px',
                height: '38px',
                borderRadius: '10px',
                background: 'rgba(255,42,109,0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--primary-pink)',
                flexShrink: 0,
              }}
            >
              <i className="fa-solid fa-user"></i>
            </div>
            <div style={{ flexGrow: 1 }}>
              <p style={{ fontSize: '11px', color: 'var(--text-muted)', margin: 0 }}>
                {lang === 'vi' ? 'Tài khoản' : 'Account'}
              </p>
              <button
                onClick={onOpenAuth}
                style={{
                  background: 'rgba(255, 42, 109, 0.2)',
                  color: '#fff',
                  border: '1px solid rgba(255, 42, 109, 0.4)',
                  padding: '4px 10px',
                  borderRadius: '8px',
                  fontSize: '11.5px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  marginTop: '4px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                }}
              >
                <i className="fa-solid fa-right-to-bracket"></i> {lang === 'vi' ? 'Đăng nhập' : 'Sign In'}
              </button>
            </div>
          </>
        )}
      </div>
    </aside>
  );
};
