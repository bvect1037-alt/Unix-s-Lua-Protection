import React, { useState, useRef, useEffect } from 'react';
import { UserAccount } from '../types';

interface AdminCommandConsoleProps {
  currentUser: UserAccount | null;
  onShowToast: (msg: string, isError?: boolean) => void;
  lang: 'vi' | 'en';
}

interface CommandLog {
  id: string;
  time: string;
  command: string;
  output: string;
  isError?: boolean;
}

export const AdminCommandConsole: React.FC<AdminCommandConsoleProps> = ({
  currentUser,
  onShowToast,
  lang,
}) => {
  // Check if current user is admin
  const isAdmin = Boolean(
    currentUser &&
      (currentUser.role === 'admin' ||
        currentUser.username.toLowerCase() === 'admin' ||
        currentUser.username.toLowerCase() === 'unixadmin' ||
        currentUser.username.toLowerCase().startsWith('@admin'))
  );

  const [isOpen, setIsOpen] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [commandInput, setCommandInput] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [logs, setLogs] = useState<CommandLog[]>([
    {
      id: 'init_1',
      time: new Date().toLocaleTimeString('vi-VN'),
      command: 'system:init',
      output:
        '👑 UNIX SUPER ADMIN CONSOLE ACTIVATED\n• Role: Super Admin (🔴 Chấm đỏ Quản trị viên)\n• Gõ /help để xem hướng dẫn lệnh.\n• Lệnh có sẵn: /ban @user, /banip @user, /unban @user, /unbanip <ip>, /ping @everyone, /listbans, /clear',
    },
  ]);

  const terminalEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen && !isMinimized) {
      terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isOpen, isMinimized]);

  if (!isAdmin) {
    return null;
  }

  const handleExecuteCommand = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const rawCmd = commandInput.trim();
    if (!rawCmd) return;

    // Handle local /clear
    if (rawCmd.toLowerCase() === '/clear' || rawCmd.toLowerCase() === 'clear') {
      setLogs([]);
      setCommandInput('');
      return;
    }

    const newCmd = rawCmd.startsWith('/') ? rawCmd : `/${rawCmd}`;
    setHistory((prev) => [newCmd, ...prev.slice(0, 30)]);
    setHistoryIndex(-1);
    setCommandInput('');
    setIsExecuting(true);

    try {
      const res = await fetch('/api/admin/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: newCmd,
          adminUsername: currentUser?.username || 'admin',
        }),
      });

      const data = await res.json();
      const timestamp = new Date().toLocaleTimeString('vi-VN');

      if (res.ok && data.success) {
        setLogs((prev) => [
          ...prev,
          {
            id: `log_${Date.now()}`,
            time: timestamp,
            command: newCmd,
            output: data.output || 'Lệnh thực thi thành công.',
            isError: false,
          },
        ]);

        if (data.action === 'ban' || data.action === 'banip') {
          onShowToast(
            lang === 'vi'
              ? `Đã thực hiện lệnh khóa thành công: ${data.target}`
              : `Banned successfully: ${data.target}`,
            false
          );
        } else if (data.action === 'ping') {
          onShowToast(
            lang === 'vi' ? 'Đã phát Global Ping @everyone!' : 'Global Ping @everyone broadcasted!',
            false
          );
        }
      } else {
        setLogs((prev) => [
          ...prev,
          {
            id: `log_${Date.now()}`,
            time: timestamp,
            command: newCmd,
            output: `❌ LỖI: ${data.error || 'Lệnh thất bại'}`,
            isError: true,
          },
        ]);
        onShowToast(data.error || 'Lỗi thực thi lệnh', true);
      }
    } catch {
      setLogs((prev) => [
        ...prev,
        {
          id: `log_${Date.now()}`,
          time: new Date().toLocaleTimeString('vi-VN'),
          command: newCmd,
          output: '❌ Không thể kết nối tới máy chủ Admin API',
          isError: true,
        },
      ]);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length > 0) {
        const nextIndex = Math.min(historyIndex + 1, history.length - 1);
        setHistoryIndex(nextIndex);
        setCommandInput(history[nextIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const prevIndex = historyIndex - 1;
        setHistoryIndex(prevIndex);
        setCommandInput(history[prevIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCommandInput('');
      }
    }
  };

  const quickInsert = (cmdPrefix: string) => {
    setCommandInput(cmdPrefix);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '18px',
        right: '18px',
        zIndex: 9998,
        maxWidth: isMinimized ? '280px' : '480px',
        width: 'calc(100vw - 36px)',
        fontFamily: "'JetBrains Mono', 'Consolas', monospace",
      }}
      className="transition-all duration-200 animate-fade-in"
    >
      {/* Container Box */}
      <div
        style={{
          background: 'rgba(8, 8, 14, 0.96)',
          border: '1px solid rgba(239, 68, 68, 0.6)',
          borderRadius: '16px',
          boxShadow: '0 0 35px rgba(239, 68, 68, 0.35), 0 10px 40px rgba(0, 0, 0, 0.8)',
          backdropFilter: 'blur(12px)',
          overflow: 'hidden',
        }}
      >
        {/* Terminal Header Bar */}
        <div
          style={{
            background: 'linear-gradient(90deg, rgba(239, 68, 68, 0.25), rgba(15, 10, 20, 0.95))',
            borderBottom: '1px solid rgba(239, 68, 68, 0.35)',
            padding: '10px 14px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            userSelect: 'none',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            {/* Pulsing Red Dot (Chấm đỏ Admin) */}
            <span
              style={{
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                backgroundColor: '#ef4444',
                boxShadow: '0 0 10px #ef4444, 0 0 4px #fff',
                display: 'inline-block',
                animation: 'pulse 1.5s infinite',
              }}
            />
            <span style={{ fontSize: '12px', fontWeight: 800, color: '#fca5a5', letterSpacing: '0.5px' }}>
              ADMIN COMMAND BAR
            </span>
            <span
              style={{
                fontSize: '10px',
                padding: '2px 6px',
                borderRadius: '6px',
                backgroundColor: 'rgba(239, 68, 68, 0.2)',
                color: '#ef4444',
                fontWeight: 700,
                border: '1px solid rgba(239, 68, 68, 0.4)',
              }}
            >
              @admin
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <button
              type="button"
              onClick={() => setIsMinimized(!isMinimized)}
              title={isMinimized ? 'Mở rộng bảng lệnh' : 'Thu nhỏ bảng lệnh'}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#9ca3af',
                cursor: 'pointer',
                padding: '2px 6px',
                fontSize: '12px',
              }}
              className="hover:text-white"
            >
              <i className={`fa-solid ${isMinimized ? 'fa-chevron-up' : 'fa-minus'}`}></i>
            </button>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              title="Đóng bảng lệnh"
              style={{
                background: 'transparent',
                border: 'none',
                color: '#9ca3af',
                cursor: 'pointer',
                padding: '2px 6px',
                fontSize: '12px',
              }}
              className="hover:text-red-400"
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        {!isMinimized && (
          <>
            {/* Terminal Output Log Area */}
            <div
              style={{
                height: '190px',
                overflowY: 'auto',
                padding: '12px',
                fontSize: '11.5px',
                lineHeight: 1.5,
                color: '#d1d5db',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
                background: '#040407',
              }}
            >
              {logs.map((log) => (
                <div key={log.id} style={{ wordBreak: 'break-word' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', opacity: 0.75 }}>
                    <span style={{ color: '#6b7280', fontSize: '10px' }}>[{log.time}]</span>
                    <span style={{ color: '#ef4444', fontWeight: 700 }}>root@unix:~$</span>
                    <span style={{ color: '#f3f4f6', fontWeight: 600 }}>{log.command}</span>
                  </div>
                  <div
                    style={{
                      whiteSpace: 'pre-wrap',
                      marginTop: '3px',
                      paddingLeft: '10px',
                      borderLeft: `2px solid ${log.isError ? '#ef4444' : '#10b981'}`,
                      color: log.isError ? '#f87171' : '#34d399',
                    }}
                  >
                    {log.output}
                  </div>
                </div>
              ))}
              <div ref={terminalEndRef} />
            </div>

            {/* Quick Command Suggestions / Pills */}
            <div
              style={{
                padding: '6px 10px',
                background: 'rgba(255, 255, 255, 0.02)',
                borderTop: '1px solid rgba(255, 255, 255, 0.05)',
                display: 'flex',
                gap: '6px',
                overflowX: 'auto',
                whiteSpace: 'nowrap',
              }}
            >
              <button
                type="button"
                onClick={() => quickInsert('/ban @')}
                className="px-2 py-0.5 rounded bg-red-500/20 hover:bg-red-500/30 text-red-300 text-[10.5px] border border-red-500/40 cursor-pointer"
              >
                /ban @user
              </button>
              <button
                type="button"
                onClick={() => quickInsert('/banip @')}
                className="px-2 py-0.5 rounded bg-red-500/20 hover:bg-red-500/30 text-red-300 text-[10.5px] border border-red-500/40 cursor-pointer"
              >
                /banip @user
              </button>
              <button
                type="button"
                onClick={() => quickInsert('/unban @')}
                className="px-2 py-0.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[10.5px] border border-emerald-500/40 cursor-pointer"
              >
                /unban @user
              </button>
              <button
                type="button"
                onClick={() => quickInsert('/ping @everyone ')}
                className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[10.5px] border border-amber-500/40 cursor-pointer"
              >
                /ping @everyone
              </button>
              <button
                type="button"
                onClick={() => quickInsert('/listbans')}
                className="px-2 py-0.5 rounded bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 text-[10.5px] border border-blue-500/40 cursor-pointer"
              >
                /listbans
              </button>
              <button
                type="button"
                onClick={() => quickInsert('/help')}
                className="px-2 py-0.5 rounded bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 text-[10.5px] border border-purple-500/40 cursor-pointer"
              >
                /help
              </button>
            </div>

            {/* Command Input Form */}
            <form
              onSubmit={handleExecuteCommand}
              style={{
                display: 'flex',
                alignItems: 'center',
                padding: '8px 12px',
                background: '#0a0a10',
                borderTop: '1px solid rgba(239, 68, 68, 0.3)',
                gap: '8px',
              }}
            >
              <span style={{ color: '#ef4444', fontWeight: 800, fontSize: '13px' }}>&gt;</span>
              <input
                ref={inputRef}
                type="text"
                value={commandInput}
                onChange={(e) => setCommandInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="/ban @user, /banip @user, /ping @everyone..."
                disabled={isExecuting}
                style={{
                  flexGrow: 1,
                  background: 'transparent',
                  border: 'none',
                  outline: 'none',
                  color: '#ffffff',
                  fontSize: '12px',
                  fontFamily: 'inherit',
                }}
              />
              <button
                type="submit"
                disabled={isExecuting || !commandInput.trim()}
                style={{
                  background: commandInput.trim() ? '#ef4444' : 'rgba(239, 68, 68, 0.3)',
                  border: 'none',
                  color: '#ffffff',
                  padding: '4px 10px',
                  borderRadius: '6px',
                  fontSize: '11px',
                  fontWeight: 700,
                  cursor: commandInput.trim() ? 'pointer' : 'default',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                }}
              >
                {isExecuting ? (
                  <i className="fa-solid fa-circle-notch fa-spin"></i>
                ) : (
                  <>
                    <span>Gửi</span>
                    <i className="fa-solid fa-paper-plane text-[10px]"></i>
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
