import React, { useState, useEffect, useMemo, useRef } from 'react';
import { ForumPost, UserAccount } from '../types';

interface ForumSectionProps {
  lang: 'vi' | 'en';
  currentUser: UserAccount | null;
  onShowToast: (msg: string, isError?: boolean) => void;
  onOpenAuth: () => void;
  onOpenProfile: (username: string) => void;
  onTriggerBan: (banType: 'ip' | 'account', banReason?: string) => void;
  onOpenNotifications: () => void;
}

const DEFAULT_POSTS: ForumPost[] = [
  {
    id: 1,
    title: '📢 Cập nhật Unix.fun Client v3.5 - 100% Raw Lua & 0.01s Ultra Anti-Crack',
    content:
      'Hệ thống Unix Auth Gateway v3.5 chính thức ra mắt:\n• Phục vụ 100% mã nguồn Pure Raw Lua nguyên bản, không inject wrapper làm hỏng logic, tương thích mọi Executor (Delta, Fluxus, Wave, Codex, Solara, MacSploit).\n• Tích hợp bẫy tự huỷ & Reload 0.01s (10ms) liên tục trên trình duyệt chống skid crack mã nguồn.\n• Cập nhật trang Profile cá nhân, tải ảnh đính kèm và thông báo Ping Logo!',
    category: 'Thông Tin',
    authorName: 'admin',
    authorDisplayName: 'Unix Super Admin 👑',
    authorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
    authorRole: 'admin',
    time: '2 giờ trước',
    timestamp: Date.now() - 7200000,
    isPinned: true,
    likes: 58,
    likedBy: ['admin', 'RobloxScripter99', 'CyberNinja'],
    comments: [
      {
        id: 101,
        authorName: 'RobloxScripter99',
        authorDisplayName: 'Roblox Scripter 99',
        authorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=RobloxScripter99',
        authorRole: 'user',
        content: 'Bản update quá mượt ad ơi, chạy loadstring game:HttpGet nhận ngay trên Fluxus & Delta!',
        time: '1 giờ trước',
        timestamp: Date.now() - 3600000,
      },
    ],
  },
  {
    id: 2,
    title: '💻 Chia sẻ mã nguồn ESP Box & Tracers Universal cho mọi Game Roblox',
    content:
      'Đoạn script ESP vẽ khung 2D và đường kẻ Tracer mượt mà sử dụng Drawing API Roblox. Hoạt động trên mọi game FPS, không bị drop FPS, hoàn toàn tương thích với Unix Auth Gateway.',
    category: 'Chia Sẻ Code',
    authorName: 'CyberNinja',
    authorDisplayName: 'CyberNinja ⚡',
    authorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=CyberNinja',
    authorRole: 'user',
    time: '4 giờ trước',
    timestamp: Date.now() - 14400000,
    isPinned: false,
    likes: 34,
    likedBy: ['admin', 'RobloxScripter99'],
    comments: [],
  },
];

export const ForumSection: React.FC<ForumSectionProps> = ({
  lang,
  currentUser,
  onShowToast,
  onOpenAuth,
  onOpenProfile,
  onTriggerBan,
  onOpenNotifications,
}) => {
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortTab, setSortTab] = useState<'hot' | 'new' | 'pinned' | 'following'>('hot');
  const [followedUsers, setFollowedUsers] = useState<string[]>([]);

  // New Post Form State
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('Thông Tin');
  const [newContent, setNewContent] = useState('');
  const [newIsPinned, setNewIsPinned] = useState(false);
  const [postImageBase64, setPostImageBase64] = useState<string | null>(null);
  const [isSubmittingPost, setIsSubmittingPost] = useState(false);

  // File input ref for post image
  const postImageInputRef = useRef<HTMLInputElement | null>(null);

  // Comments State
  const [openCommentsId, setOpenCommentsId] = useState<number | null>(null);
  const [commentInputs, setCommentInputs] = useState<Record<number, string>>({});
  const [submittingCommentId, setSubmittingCommentId] = useState<number | null>(null);

  // Search filter
  const [searchQuery, setSearchQuery] = useState('');

  const isAdmin =
    currentUser?.role === 'admin' ||
    currentUser?.username?.toLowerCase() === 'admin' ||
    currentUser?.username?.toLowerCase() === 'unixadmin';

  useEffect(() => {
    fetchPosts();
    loadFollowedUsers();
  }, [currentUser]);

  const loadFollowedUsers = async () => {
    if (currentUser?.username) {
      try {
        const res = await fetch(`/api/users/${encodeURIComponent(currentUser.username)}/following`);
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.following)) {
            setFollowedUsers(data.following);
            return;
          }
        }
      } catch {
        // fallback
      }
    }
    const saved = localStorage.getItem('unix_followed_users');
    if (saved) {
      try {
        setFollowedUsers(JSON.parse(saved));
      } catch {
        setFollowedUsers([]);
      }
    }
  };

  const fetchPosts = async () => {
    try {
      const res = await fetch('/api/forum/posts');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setPosts(data);
          localStorage.setItem('nnvn_forum_posts', JSON.stringify(data));
          return;
        }
      }
    } catch {
      // offline fallback
    }

    const saved = localStorage.getItem('nnvn_forum_posts');
    if (saved) {
      try {
        setPosts(JSON.parse(saved));
      } catch {
        setPosts(DEFAULT_POSTS);
      }
    } else {
      setPosts(DEFAULT_POSTS);
    }
  };

  const savePostsLocally = (updated: ForumPost[]) => {
    setPosts(updated);
    localStorage.setItem('nnvn_forum_posts', JSON.stringify(updated));
  };

  // Image Upload handler for post
  const handlePostImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      onShowToast(lang === 'vi' ? 'Dung lượng ảnh tối đa là 8MB!' : 'Max image size is 8MB!', true);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setPostImageBase64(reader.result as string);
      onShowToast(lang === 'vi' ? 'Đã đính kèm ảnh vào bài viết!' : 'Image attached!');
    };
    reader.readAsDataURL(file);
  };

  // Like / Unlike Post Handler
  const handleToggleLike = async (postId: number) => {
    const currentUsername = currentUser?.username || 'Guest';

    // Optimistic UI update
    const updated = posts.map((post) => {
      if (post.id === postId) {
        const likedBy = post.likedBy || [];
        const isLiked = likedBy.some((u) => u.toLowerCase() === currentUsername.toLowerCase());
        const newLikedBy = isLiked
          ? likedBy.filter((u) => u.toLowerCase() !== currentUsername.toLowerCase())
          : [...likedBy, currentUsername];
        const newLikes = isLiked ? Math.max(0, post.likes - 1) : post.likes + 1;

        return {
          ...post,
          likes: newLikes,
          likedBy: newLikedBy,
        };
      }
      return post;
    });

    savePostsLocally(updated);

    try {
      const res = await fetch(`/api/forum/posts/${postId}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: currentUsername }),
      });
      if (res.ok) {
        const data = await res.json();
        onShowToast(
          data.isLiked
            ? (lang === 'vi' ? 'Đã thích bài viết! (+1 Ưu tiên diễn đàn)' : 'Liked post! (+1 Priority)')
            : (lang === 'vi' ? 'Đã bỏ thích bài viết' : 'Unliked post')
        );
      }
    } catch {
      // ignore
    }
  };

  // Pin / Ping Post to Top
  const handleTogglePin = async (postId: number) => {
    const updated = posts.map((post) => {
      if (post.id === postId) {
        return {
          ...post,
          isPinned: !post.isPinned,
        };
      }
      return post;
    });

    savePostsLocally(updated);

    try {
      const res = await fetch(`/api/forum/posts/${postId}/pin`, {
        method: 'POST',
      });
      if (res.ok) {
        const data = await res.json();
        onShowToast(
          data.isPinned
            ? (lang === 'vi' ? '📌 Đã ghim bài viết lên đầu diễn đàn!' : '📌 Post pinned to top!')
            : (lang === 'vi' ? 'Đã bỏ ghim bài viết.' : 'Post unpinned.')
        );
      }
    } catch {
      // ignore
    }
  };

  // Follow / Unfollow User
  const handleToggleFollow = async (targetUsername: string) => {
    if (!currentUser) {
      onShowToast(lang === 'vi' ? 'Vui lòng đăng nhập để theo dõi người dùng!' : 'Please sign in to follow users!', true);
      onOpenAuth();
      return;
    }

    if (currentUser.username.toLowerCase() === targetUsername.toLowerCase()) {
      onShowToast(lang === 'vi' ? 'Bạn không thể tự theo dõi chính mình!' : 'You cannot follow yourself!', true);
      return;
    }

    const isCurrentlyFollowing = followedUsers.some((u) => u.toLowerCase() === targetUsername.toLowerCase());
    const newFollowing = isCurrentlyFollowing
      ? followedUsers.filter((u) => u.toLowerCase() !== targetUsername.toLowerCase())
      : [...followedUsers, targetUsername];

    setFollowedUsers(newFollowing);
    localStorage.setItem('unix_followed_users', JSON.stringify(newFollowing));

    try {
      const res = await fetch(`/api/users/${encodeURIComponent(targetUsername)}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentUsername: currentUser.username }),
      });
      if (res.ok) {
        const data = await res.json();
        onShowToast(
          data.isFollowing
            ? (lang === 'vi' ? `Đã theo dõi @${targetUsername}!` : `Now following @${targetUsername}!`)
            : (lang === 'vi' ? `Đã hủy theo dõi @${targetUsername}` : `Unfollowed @${targetUsername}`)
        );
      }
    } catch {
      // ignore
    }
  };

  // Delete Post
  const handleDeletePost = async (postId: number) => {
    if (!window.confirm(lang === 'vi' ? 'Bạn có chắc chắn muốn xóa bài viết này?' : 'Delete this post?')) {
      return;
    }

    const updated = posts.filter((p) => p.id !== postId);
    savePostsLocally(updated);

    try {
      await fetch(`/api/forum/posts/${postId}`, { method: 'DELETE' });
      onShowToast(lang === 'vi' ? 'Đã xóa bài viết!' : 'Post deleted!');
    } catch {
      // ignore
    }
  };

  // Create Post with Auto Moderation Check
  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) {
      onShowToast(lang === 'vi' ? 'Vui lòng điền đủ tiêu đề và nội dung!' : 'Please fill all fields!', true);
      return;
    }

    setIsSubmittingPost(true);
    const author = currentUser ? currentUser.username : 'Guest User';
    const displayName = currentUser?.displayName || author;
    const avatar = currentUser?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(author)}`;

    try {
      const res = await fetch('/api/forum/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle.trim(),
          content: newContent.trim(),
          category: newCategory,
          authorName: author,
          authorDisplayName: displayName,
          authorAvatar: avatar,
          authorRole: currentUser?.role || 'user',
          isPinned: newIsPinned,
          postImage: postImageBase64 || undefined,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        if (err.isBanned) {
          onTriggerBan(err.banType || 'account', err.banReason);
          setIsSubmittingPost(false);
          return;
        }
        onShowToast(err.error || 'Failed to submit post', true);
        setIsSubmittingPost(false);
        return;
      }

      setNewTitle('');
      setNewContent('');
      setNewIsPinned(false);
      setPostImageBase64(null);
      fetchPosts();
      onShowToast(lang === 'vi' ? 'Đăng bài thành công!' : 'Post submitted successfully!');
    } catch {
      onShowToast('Lỗi gửi bài viết', true);
    }

    setIsSubmittingPost(false);
  };

  // Submit Comment with Auto Moderation Check
  const handleCommentSubmit = async (e: React.FormEvent, postId: number) => {
    e.preventDefault();
    const commentText = (commentInputs[postId] || '').trim();
    if (!commentText) return;

    setSubmittingCommentId(postId);
    const author = currentUser ? currentUser.username : 'Guest User';
    const displayName = currentUser?.displayName || author;
    const avatar = currentUser?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(author)}`;

    try {
      const res = await fetch(`/api/forum/posts/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorName: author,
          authorDisplayName: displayName,
          authorAvatar: avatar,
          content: commentText,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        if (err.isBanned) {
          onTriggerBan(err.banType || 'account', err.banReason);
          setSubmittingCommentId(null);
          return;
        }
        onShowToast(err.error || 'Failed to submit comment', true);
        setSubmittingCommentId(null);
        return;
      }

      const data = await res.json();
      const updated = posts.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            comments: [...(p.comments || []), data.comment],
          };
        }
        return p;
      });

      savePostsLocally(updated);
      setCommentInputs({ ...commentInputs, [postId]: '' });
      onShowToast(lang === 'vi' ? 'Đã gửi bình luận!' : 'Comment posted!');
    } catch {
      onShowToast('Lỗi gửi bình luận', true);
    }

    setSubmittingCommentId(null);
  };

  const categories = [
    { id: 'all', labelVi: 'Tất cả bài viết', labelEn: 'All Posts', icon: 'fa-globe' },
    { id: 'Thông Tin', labelVi: 'Thông Tin', labelEn: 'Announcements', icon: 'fa-bullhorn' },
    { id: 'Chia Sẻ Code', labelVi: 'Chia Sẻ Code', labelEn: 'Code Share', icon: 'fa-code' },
    { id: 'Hỏi Đáp Script', labelVi: 'Hỏi Đáp Script', labelEn: 'Q&A Script', icon: 'fa-circle-question' },
    { id: 'Thảo Luận Chung', labelVi: 'Thảo Luận Chung', labelEn: 'General Discussion', icon: 'fa-comments' },
    { id: 'Bảo Mật & Bug', labelVi: 'Bảo Mật & Bug', labelEn: 'Security & Bugs', icon: 'fa-shield-halved' },
  ];

  // Sorter and Filter computation
  const sortedAndFilteredPosts = useMemo(() => {
    let result = [...posts];

    // Category Filter
    if (activeCategory !== 'all') {
      result = result.filter((p) => p.category === activeCategory);
    }

    // Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.content.toLowerCase().includes(q) ||
          p.authorName.toLowerCase().includes(q) ||
          (p.authorDisplayName && p.authorDisplayName.toLowerCase().includes(q))
      );
    }

    // Tab Filter
    if (sortTab === 'pinned') {
      result = result.filter((p) => p.isPinned);
    } else if (sortTab === 'following') {
      result = result.filter((p) =>
        followedUsers.some((f) => f.toLowerCase() === p.authorName.toLowerCase())
      );
    }

    // Prioritization sorting rule:
    // 1. Pinned posts ALWAYS stick to top
    // 2. High likes get prioritized to top (More likes = Higher position)
    // 3. Newest timestamp
    result.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;

      if (sortTab === 'hot') {
        if ((b.likes || 0) !== (a.likes || 0)) {
          return (b.likes || 0) - (a.likes || 0);
        }
      } else if (sortTab === 'new') {
        return (b.timestamp || 0) - (a.timestamp || 0);
      } else {
        if ((b.likes || 0) !== (a.likes || 0)) {
          return (b.likes || 0) - (a.likes || 0);
        }
      }

      return (b.timestamp || 0) - (a.timestamp || 0);
    });

    return result;
  }, [posts, activeCategory, sortTab, followedUsers, searchQuery]);

  return (
    <section className="space-y-6">
      {/* Top Banner with Social Stats & Moderation Notice */}
      <div className="bg-[#0e0e18]/80 border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ff2a6d] animate-pulse"></span>
            <h2 className="text-lg font-bold text-white tracking-wide">
              {lang === 'vi' ? 'Diễn Đàn Thảo Luận & Chia Sẻ Script' : 'Community Forum & Script Hub'}
            </h2>
          </div>
          <p className="text-[12px] text-gray-400">
            {lang === 'vi'
              ? 'Thả tim like bài đăng để ưu tiên lên đầu • Tải ảnh lên bài • Nhấp avatar để xem hồ sơ cá nhân'
              : 'Like posts to boost them to top • Upload images • Click avatars to view user profiles'}
          </p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          {/* Admin Global Ping Trigger shortcut */}
          {isAdmin && (
            <button
              onClick={onOpenNotifications}
              className="px-3.5 py-2 bg-gradient-to-r from-amber-500/20 to-red-500/20 border border-amber-500/40 text-amber-300 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.25)] shrink-0"
            >
              <i className="fa-solid fa-bullhorn text-[11px]"></i>
              <span>{lang === 'vi' ? 'Ping @everyone' : 'Global Ping'}</span>
            </button>
          )}

          <div className="relative flex-grow md:w-64">
            <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 text-[13px]"></i>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={lang === 'vi' ? 'Tìm bài viết, tác giả...' : 'Search posts, author...'}
              className="w-full bg-[#07070d] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-[12.5px] text-white placeholder:text-gray-600 focus:outline-none focus:border-[#ff2a6d]"
            />
          </div>
        </div>
      </div>

      {/* Moderation Rules Warning Banner */}
      <div className="bg-gradient-to-r from-red-950/40 to-black border border-red-500/30 rounded-2xl p-3.5 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-xs shrink-0 border border-red-500/40">
            <i className="fa-solid fa-shield-halved"></i>
          </div>
          <span className="text-gray-300">
            <strong className="text-red-400">
              {lang === 'vi' ? 'Quy chuẩn kiểm duyệt tự động:' : 'Auto Moderation Rules:'}
            </strong>{' '}
            {lang === 'vi'
              ? 'Nghiêm cấm nội dung 18+/Sex (Khoá IP ngay lập tức) • Nghiêm cấm hình ảnh máu me/bạo lực (Khoá tài khoản vĩnh viễn).'
              : 'Strictly No 18+/NSFW (Instant IP Ban) • No Gore/Blood (Permanent Account Ban).'}
          </span>
        </div>
      </div>

      {/* Sorting & Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
        {/* Sort Tabs */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setSortTab('hot')}
            className={`px-3.5 py-1.5 rounded-xl text-[12.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              sortTab === 'hot'
                ? 'bg-[#ff2a6d] text-white shadow-[0_0_12px_rgba(255,42,109,0.4)]'
                : 'bg-[#12121e] text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            <i className="fa-solid fa-fire text-amber-300"></i>
            <span>{lang === 'vi' ? 'Nhiều Like Nhất (Ưu Tiên)' : 'Most Liked (Top)'}</span>
          </button>

          <button
            onClick={() => setSortTab('new')}
            className={`px-3.5 py-1.5 rounded-xl text-[12.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              sortTab === 'new'
                ? 'bg-[#00ffcc] text-black shadow-[0_0_12px_rgba(0,255,204,0.4)]'
                : 'bg-[#12121e] text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            <i className="fa-solid fa-sparkles"></i>
            <span>{lang === 'vi' ? 'Mới Nhất' : 'Newest'}</span>
          </button>

          <button
            onClick={() => setSortTab('pinned')}
            className={`px-3.5 py-1.5 rounded-xl text-[12.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              sortTab === 'pinned'
                ? 'bg-[#b388ff] text-white shadow-[0_0_12px_rgba(179,136,255,0.4)]'
                : 'bg-[#12121e] text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            <i className="fa-solid fa-thumbtack"></i>
            <span>{lang === 'vi' ? 'Đã Ghim (Pinned)' : 'Pinned'}</span>
          </button>

          <button
            onClick={() => setSortTab('following')}
            className={`px-3.5 py-1.5 rounded-xl text-[12.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              sortTab === 'following'
                ? 'bg-[#3b82f6] text-white shadow-[0_0_12px_rgba(59,130,246,0.4)]'
                : 'bg-[#12121e] text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            <i className="fa-solid fa-user-group"></i>
            <span>
              {lang === 'vi' ? `Đang Theo Dõi (${followedUsers.length})` : `Following (${followedUsers.length})`}
            </span>
          </button>
        </div>

        {/* Total post count */}
        <span className="text-[12px] font-mono text-gray-500">
          {sortedAndFilteredPosts.length} {lang === 'vi' ? 'bài viết' : 'posts'}
        </span>
      </div>

      {/* Category Filter Chips */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-[12px] font-semibold whitespace-nowrap flex items-center gap-1.5 cursor-pointer transition-all border ${
                isActive
                  ? 'bg-white/15 text-white border-[#ff2a6d]/60 shadow-[0_0_10px_rgba(255,42,109,0.25)]'
                  : 'bg-[#0d0d16] text-gray-400 border-white/5 hover:border-white/20 hover:text-gray-200'
              }`}
            >
              <i className={`fa-solid ${cat.icon} text-[11px]`}></i>
              <span>{lang === 'vi' ? cat.labelVi : cat.labelEn}</span>
            </button>
          );
        })}
      </div>

      {/* New Post Form Box */}
      <div className="bg-[#0e0e18] border border-white/10 rounded-2xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-pen-to-square text-[#ff2a6d]"></i>
            <h3 className="text-sm font-bold text-white">
              {lang === 'vi' ? 'Tạo Bài Viết / Thảo Luận Mới' : 'Create New Discussion'}
            </h3>
          </div>
          <span className="text-[11.5px] text-gray-400">
            {currentUser ? (
              <span
                onClick={() => onOpenProfile(currentUser.username)}
                className="flex items-center gap-1.5 cursor-pointer hover:underline"
              >
                <img
                  src={currentUser.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(currentUser.username)}`}
                  alt=""
                  className="w-5 h-5 rounded-full object-cover"
                />
                <strong className="text-white">
                  {currentUser.displayName || currentUser.username}
                </strong>
                {currentUser.role === 'admin' && <span className="text-amber-400">👑</span>}
              </span>
            ) : (
              <button
                type="button"
                onClick={onOpenAuth}
                className="text-[#00ffcc] hover:underline cursor-pointer"
              >
                {lang === 'vi' ? 'Đăng nhập để nhận huy hiệu' : 'Sign in for verified badge'}
              </button>
            )}
          </span>
        </div>

        <form onSubmit={handlePostSubmit} className="space-y-3">
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder={lang === 'vi' ? 'Tiêu đề bài viết (VD: Chia sẻ script Blox Fruits auto farm...)' : 'Discussion title...'}
            required
            className="w-full bg-[#07070d] border border-white/10 rounded-xl px-4 py-2.5 text-[13px] text-white placeholder:text-gray-600 focus:outline-none focus:border-[#ff2a6d]"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              className="w-full bg-[#07070d] border border-white/10 rounded-xl px-3.5 py-2.5 text-[13px] text-gray-200 focus:outline-none focus:border-[#ff2a6d]"
            >
              <option value="Thông Tin">📢 Thông Tin / Announcement</option>
              <option value="Chia Sẻ Code">💻 Chia Sẻ Code / Script Share</option>
              <option value="Hỏi Đáp Script">❓ Hỏi Đáp Script / Q&A</option>
              <option value="Thảo Luận Chung">💬 Thảo Luận Chung / General</option>
              <option value="Bảo Mật & Bug">🛡️ Bảo Mật & Bug</option>
            </select>

            <label className="flex items-center gap-2 bg-[#07070d] border border-white/10 rounded-xl px-3.5 py-2.5 cursor-pointer hover:border-white/20">
              <input
                type="checkbox"
                checked={newIsPinned}
                onChange={(e) => setNewIsPinned(e.target.checked)}
                className="w-4 h-4 rounded text-[#ff2a6d] focus:ring-0 bg-black border-white/20"
              />
              <span className="text-[12.5px] font-semibold text-gray-300 flex items-center gap-1">
                <i className="fa-solid fa-thumbtack text-amber-400 text-[11px]"></i>
                {lang === 'vi' ? 'Ghim bài lên đầu diễn đàn (Pin to top)' : 'Pin this post to top'}
              </span>
            </label>
          </div>

          <textarea
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            rows={3}
            placeholder={
              lang === 'vi'
                ? 'Nội dung chi tiết, câu hỏi, hướng dẫn hoặc đoạn mã Lua cần chia sẻ...'
                : 'Detailed content, code snippets, questions or tutorials...'
            }
            required
            className="w-full bg-[#07070d] border border-white/10 rounded-xl p-4 text-[13px] text-gray-200 placeholder:text-gray-600 focus:outline-none focus:border-[#ff2a6d] leading-relaxed resize-y"
          />

          {/* Post Image Upload Attachment */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => postImageInputRef.current?.click()}
              className="px-3.5 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-bold text-gray-200 flex items-center gap-2 cursor-pointer transition-all"
            >
              <i className="fa-solid fa-image text-[#00ffcc]"></i>
              <span>{lang === 'vi' ? 'Đính kèm ảnh bài đăng (PNG/JPG)' : 'Attach Image (PNG/JPG)'}</span>
            </button>
            <input
              ref={postImageInputRef}
              type="file"
              accept="image/png, image/jpeg, image/webp, image/gif"
              onChange={handlePostImageUpload}
              className="hidden"
            />

            {postImageBase64 && (
              <div className="relative inline-block border border-white/20 rounded-xl overflow-hidden group">
                <img src={postImageBase64} alt="Attached" className="w-14 h-14 object-cover" />
                <button
                  type="button"
                  onClick={() => setPostImageBase64(null)}
                  className="absolute top-1 right-1 bg-red-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px] cursor-pointer"
                  title="Remove image"
                >
                  <i className="fa-solid fa-xmark"></i>
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-white/5">
            <button
              type="submit"
              disabled={isSubmittingPost}
              className="bg-gradient-to-r from-[#ff2a6d] to-[#ff5e87] hover:brightness-110 text-white font-bold text-[13px] py-2.5 px-5 rounded-xl shadow-[0_0_15px_rgba(255,42,109,0.35)] transition-all flex items-center gap-2 cursor-pointer"
            >
              <i className="fa-solid fa-paper-plane"></i>
              <span>{isSubmittingPost ? (lang === 'vi' ? 'Đang kiểm duyệt...' : 'Checking...') : (lang === 'vi' ? 'Đăng Bài Ngay' : 'Publish Post')}</span>
            </button>

            <span className="text-[11px] text-gray-500">
              {lang === 'vi' ? 'Bài đăng có nhiều lượt like sẽ tự động được ưu tiên lên đầu' : 'Posts with more likes are boosted to top'}
            </span>
          </div>
        </form>
      </div>

      {/* Posts Feed */}
      <div className="space-y-4">
        {sortedAndFilteredPosts.length === 0 ? (
          <div className="bg-[#0e0e18] border border-white/10 rounded-2xl p-12 text-center text-gray-400 space-y-2">
            <i className="fa-solid fa-inbox text-3xl text-gray-600"></i>
            <p className="text-sm font-semibold">
              {lang === 'vi' ? 'Chưa có bài viết nào phù hợp bộ lọc.' : 'No posts match the selected filter.'}
            </p>
            <p className="text-xs text-gray-500">
              {lang === 'vi' ? 'Hãy là người đầu tiên tạo thảo luận mới!' : 'Be the first one to create a post!'}
            </p>
          </div>
        ) : (
          sortedAndFilteredPosts.map((post) => {
            const commentCount = post.comments ? post.comments.length : 0;
            const isCommentsOpen = openCommentsId === post.id;
            const currentUsername = currentUser?.username || 'Guest';
            const isLikedByMe = (post.likedBy || []).some(
              (u) => u.toLowerCase() === currentUsername.toLowerCase()
            );
            const isFollowingAuthor = followedUsers.some(
              (u) => u.toLowerCase() === post.authorName.toLowerCase()
            );
            const isMyPost = currentUser?.username && currentUser.username.toLowerCase() === post.authorName.toLowerCase();

            return (
              <div
                key={post.id}
                className={`bg-[#0e0e18] border rounded-2xl p-5 transition-all space-y-3.5 hover:border-white/20 shadow-md ${
                  post.isPinned
                    ? 'border-[#ff2a6d]/60 shadow-[0_0_20px_rgba(255,42,109,0.15)] bg-gradient-to-b from-[#181122] to-[#0e0e18]'
                    : 'border-white/10'
                }`}
              >
                {/* Post Top Row: Author, Follow, Category, Pin Badge */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={
                        post.authorAvatar ||
                        `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(post.authorName)}`
                      }
                      alt={post.authorName}
                      onClick={() => onOpenProfile(post.authorName)}
                      className="w-10 h-10 rounded-xl border border-white/15 bg-white/5 shrink-0 cursor-pointer object-cover hover:border-[#ff2a6d] transition-all"
                      title={lang === 'vi' ? 'Xem hồ sơ cá nhân' : 'View Profile'}
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          onClick={() => onOpenProfile(post.authorName)}
                          className="text-[14px] font-bold text-white truncate cursor-pointer hover:text-[#ff2a6d] hover:underline"
                        >
                          {post.authorDisplayName || post.authorName}
                        </span>

                        {(post.authorRole === 'admin' || post.authorName.toLowerCase() === 'admin') && (
                          <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/50 text-[10px] font-extrabold flex items-center gap-1.5 shadow-[0_0_8px_rgba(239,68,68,0.3)]">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_4px_#ef4444] animate-pulse"></span>
                            <span>Admin</span>
                          </span>
                        )}

                        {/* Follow / Following Button */}
                        {!isMyPost && post.authorName !== 'Guest User' && (
                          <button
                            type="button"
                            onClick={() => handleToggleFollow(post.authorName)}
                            className={`px-2 py-0.5 rounded-md text-[10.5px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                              isFollowingAuthor
                                ? 'bg-white/10 text-emerald-300 border border-emerald-500/30'
                                : 'bg-[#ff2a6d]/15 text-[#ff2a6d] hover:bg-[#ff2a6d] hover:text-white border border-[#ff2a6d]/30'
                            }`}
                          >
                            <i className={`fa-solid ${isFollowingAuthor ? 'fa-check' : 'fa-plus'} text-[9px]`}></i>
                            <span>{isFollowingAuthor ? (lang === 'vi' ? 'Đang Follow' : 'Following') : 'Follow'}</span>
                          </button>
                        )}
                      </div>
                      <span className="text-[11px] text-gray-500 block">
                        @{post.authorName} • {post.time}
                      </span>
                    </div>
                  </div>

                  {/* Right Tags: Pinned Badge & Category */}
                  <div className="flex items-center gap-2 shrink-0">
                    {post.isPinned && (
                      <span className="px-2.5 py-1 rounded-lg bg-[#ff2a6d]/20 text-[#ff2a6d] border border-[#ff2a6d]/40 text-[11px] font-bold flex items-center gap-1.5 shadow-[0_0_8px_rgba(255,42,109,0.3)]">
                        <i className="fa-solid fa-thumbtack text-[10px]"></i>
                        <span>{lang === 'vi' ? 'ĐÃ GHIM' : 'PINNED'}</span>
                      </span>
                    )}

                    <span className="px-2.5 py-1 rounded-lg bg-white/5 text-gray-300 border border-white/10 text-[11px] font-semibold">
                      {post.category}
                    </span>
                  </div>
                </div>

                {/* Post Title & Content */}
                <div>
                  <h3 className="text-[15.5px] font-bold text-white mb-1.5 leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-[13.5px] text-gray-300 leading-relaxed whitespace-pre-line">
                    {post.content}
                  </p>
                </div>

                {/* Attached Post Image if present */}
                {post.postImage && (
                  <div className="pt-2">
                    <img
                      src={post.postImage}
                      alt="Post Attachment"
                      className="max-h-96 w-auto rounded-2xl border border-white/15 object-contain bg-black/40 shadow-[0_0_20px_rgba(0,0,0,0.5)]"
                    />
                  </div>
                )}

                {/* Post Footer Actions: Like, Pin Toggle, Comments Drawer Toggle, Delete */}
                <div className="flex items-center justify-between border-t border-white/5 pt-3">
                  <div className="flex items-center gap-2">
                    {/* Like Button */}
                    <button
                      type="button"
                      onClick={() => handleToggleLike(post.id)}
                      className={`px-3.5 py-1.5 rounded-xl text-[12.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
                        isLikedByMe
                          ? 'bg-[#ff2a6d]/20 text-[#ff2a6d] border-[#ff2a6d]/50 shadow-[0_0_12px_rgba(255,42,109,0.3)]'
                          : 'bg-[#07070d] text-gray-400 hover:text-[#ff2a6d] border-white/10 hover:border-[#ff2a6d]/30'
                      }`}
                    >
                      <i className={`fa-solid fa-heart ${isLikedByMe ? 'text-[#ff2a6d]' : ''}`}></i>
                      <span>{post.likes || 0}</span>
                      <span className="hidden sm:inline text-[11px] font-normal text-gray-400 ml-0.5">
                        {lang === 'vi' ? 'Thích' : 'Likes'}
                      </span>
                    </button>

                    {/* Comments Toggle Button */}
                    <button
                      type="button"
                      onClick={() => setOpenCommentsId(isCommentsOpen ? null : post.id)}
                      className={`px-3.5 py-1.5 rounded-xl text-[12.5px] font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
                        isCommentsOpen
                          ? 'bg-white/15 text-white border-white/30'
                          : 'bg-[#07070d] text-gray-400 hover:text-white border-white/10 hover:border-white/20'
                      }`}
                    >
                      <i className="fa-solid fa-comment-dots text-gray-400"></i>
                      <span>{commentCount}</span>
                      <span className="hidden sm:inline text-[11px] font-normal text-gray-400 ml-0.5">
                        {lang === 'vi' ? 'Bình luận' : 'Comments'}
                      </span>
                    </button>

                    {/* Pin / Ping Toggle for Creator or Admin */}
                    {(isAdmin || isMyPost) && (
                      <button
                        type="button"
                        onClick={() => handleTogglePin(post.id)}
                        title={lang === 'vi' ? 'Ghim/Bỏ ghim bài viết lên đầu' : 'Pin/Unpin post to top'}
                        className={`px-2.5 py-1.5 rounded-xl text-[11.5px] font-semibold flex items-center gap-1 transition-all cursor-pointer border ${
                          post.isPinned
                            ? 'bg-amber-400/20 text-amber-300 border-amber-400/40'
                            : 'bg-[#07070d] text-gray-500 hover:text-amber-300 border-white/10'
                        }`}
                      >
                        <i className="fa-solid fa-thumbtack"></i>
                        <span className="hidden md:inline">
                          {post.isPinned
                            ? (lang === 'vi' ? 'Bỏ Ghim' : 'Unpin')
                            : (lang === 'vi' ? 'Ghim Bài' : 'Pin')}
                        </span>
                      </button>
                    )}
                  </div>

                  {/* Right Actions: Delete Post */}
                  {(isMyPost || isAdmin) && (
                    <button
                      type="button"
                      onClick={() => handleDeletePost(post.id)}
                      className="text-gray-500 hover:text-red-400 text-[12px] px-2 py-1 rounded-lg hover:bg-red-500/10 transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <i className="fa-solid fa-trash-can text-[11px]"></i>
                      <span className="hidden sm:inline">{lang === 'vi' ? 'Xóa' : 'Delete'}</span>
                    </button>
                  )}
                </div>

                {/* Comments Section Drawer */}
                {isCommentsOpen && (
                  <div className="mt-3 pt-3 border-t border-white/5 space-y-3 bg-[#07070d]/60 rounded-xl p-3.5">
                    <div className="space-y-2">
                      {post.comments && post.comments.length > 0 ? (
                        post.comments.map((c) => (
                          <div
                            key={c.id}
                            className="bg-[#0e0e18] border border-white/5 rounded-xl p-3 flex items-start gap-2.5"
                          >
                            <img
                              src={
                                c.authorAvatar ||
                                `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(c.authorName)}`
                              }
                              alt=""
                              onClick={() => onOpenProfile(c.authorName)}
                              className="w-8 h-8 rounded-lg bg-white/5 shrink-0 border border-white/10 cursor-pointer object-cover hover:border-[#ff2a6d]"
                              title={lang === 'vi' ? 'Xem hồ sơ cá nhân' : 'View Profile'}
                            />
                            <div className="min-w-0 flex-grow">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5">
                                  <span
                                    onClick={() => onOpenProfile(c.authorName)}
                                    className="text-[12.5px] font-bold text-gray-200 cursor-pointer hover:underline"
                                  >
                                    {c.authorDisplayName || c.authorName}
                                  </span>
                                  {(c.authorRole === 'admin' || c.authorName.toLowerCase() === 'admin') && (
                                    <span className="px-1.5 py-0.2 rounded bg-red-500/20 text-red-300 border border-red-500/40 text-[9px] font-extrabold flex items-center gap-1">
                                      <span className="w-1 h-1 rounded-full bg-red-500 shadow-[0_0_3px_#ef4444] animate-pulse"></span>
                                      <span>Admin</span>
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-gray-500">{c.time}</span>
                              </div>
                              <p className="text-[12.5px] text-gray-300 mt-1 leading-snug">
                                {c.content}
                              </p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-gray-500 text-[12px] py-2">
                          {lang === 'vi' ? 'Chưa có bình luận nào. Hãy là người đầu tiên!' : 'No comments yet. Start the conversation!'}
                        </p>
                      )}
                    </div>

                    {/* Add Comment Input */}
                    <form
                      onSubmit={(e) => handleCommentSubmit(e, post.id)}
                      className="flex items-center gap-2 pt-1"
                    >
                      <input
                        type="text"
                        value={commentInputs[post.id] || ''}
                        onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                        placeholder={lang === 'vi' ? 'Viết câu trả lời / bình luận...' : 'Write a comment...'}
                        required
                        className="flex-grow bg-[#07070d] border border-white/10 rounded-xl px-3.5 py-2 text-[12.5px] text-white placeholder:text-gray-600 focus:outline-none focus:border-[#ff2a6d]"
                      />
                      <button
                        type="submit"
                        disabled={submittingCommentId === post.id}
                        className="px-4 py-2 bg-[#ff2a6d] hover:brightness-110 text-white rounded-xl text-[12.5px] font-bold shrink-0 transition-all flex items-center gap-1.5 cursor-pointer shadow-[0_0_10px_rgba(255,42,109,0.3)]"
                      >
                        <i className="fa-solid fa-paper-plane text-[11px]"></i>
                        <span>{lang === 'vi' ? 'Gửi' : 'Send'}</span>
                      </button>
                    </form>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </section>
  );
};
