import React, { useState, useEffect, useRef } from 'react';
import { UserAccount } from '../types';

interface UserProfileModalProps {
  isOpen: boolean;
  username: string | null;
  currentUser: UserAccount | null;
  onClose: () => void;
  onUpdateCurrentUser: (updatedUser: UserAccount) => void;
  onShowToast: (msg: string, isError?: boolean) => void;
  lang: 'vi' | 'en';
}

interface ProfileData {
  id?: string;
  username: string;
  displayName: string;
  bio: string;
  avatar: string;
  role: 'admin' | 'user';
  followersCount: number;
  followingCount: number;
  createdAt?: string;
  isBanned?: boolean;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  username,
  currentUser,
  onClose,
  onUpdateCurrentUser,
  onShowToast,
  lang,
}) => {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  // Edit form state
  const [editDisplayName, setEditDisplayName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Preset avatar templates
  const AVATAR_PRESETS = [
    'https://api.dicebear.com/7.x/bottts/svg?seed=CyberNinja',
    'https://api.dicebear.com/7.x/bottts/svg?seed=RobloxScripter99',
    'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
    'https://api.dicebear.com/7.x/bottts/svg?seed=ShadowHacker',
    'https://api.dicebear.com/7.x/bottts/svg?seed=QuantumV5',
    'https://api.dicebear.com/7.x/bottts/svg?seed=NeonMatrix',
  ];

  const isOwnProfile =
    currentUser?.username &&
    username &&
    currentUser.username.toLowerCase() === username.toLowerCase();

  useEffect(() => {
    if (isOpen && username) {
      fetchUserProfile(username);
      checkFollowingStatus(username);
    } else {
      setIsEditing(false);
    }
  }, [isOpen, username, currentUser]);

  const fetchUserProfile = async (targetUser: string) => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(targetUser)}`);
      if (res.ok) {
        const data = await res.json();
        setProfile(data);
        setEditDisplayName(data.displayName || data.username);
        setEditBio(data.bio || '');
        setEditAvatar(data.avatar || '');
      }
    } catch {
      // fallback
      setProfile({
        username: targetUser,
        displayName: targetUser,
        bio: 'Thành viên cộng đồng Unix.fun Hub',
        avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(targetUser)}`,
        role: targetUser.toLowerCase() === 'admin' ? 'admin' : 'user',
        followersCount: 0,
        followingCount: 0,
      });
    }
    setIsLoading(false);
  };

  const checkFollowingStatus = async (targetUser: string) => {
    if (!currentUser?.username) return;
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(currentUser.username)}/following`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.following)) {
          setIsFollowing(data.following.some((u: string) => u.toLowerCase() === targetUser.toLowerCase()));
        }
      }
    } catch {
      // ignore
    }
  };

  const handleToggleFollow = async () => {
    if (!currentUser) {
      onShowToast(lang === 'vi' ? 'Vui lòng đăng nhập để theo dõi!' : 'Please log in to follow!', true);
      return;
    }
    if (!profile) return;

    try {
      const res = await fetch(`/api/users/${encodeURIComponent(profile.username)}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentUsername: currentUser.username }),
      });
      if (res.ok) {
        const data = await res.json();
        setIsFollowing(data.isFollowing);
        setProfile({
          ...profile,
          followersCount: data.followerCount ?? (isFollowing ? Math.max(0, profile.followersCount - 1) : profile.followersCount + 1),
        });
        onShowToast(
          data.isFollowing
            ? (lang === 'vi' ? `Đã theo dõi @${profile.username}!` : `Now following @${profile.username}!`)
            : (lang === 'vi' ? `Đã hủy theo dõi @${profile.username}` : `Unfollowed @${profile.username}`)
        );
      }
    } catch {
      // ignore
    }
  };

  // Handle custom image avatar file upload (PNG / JPG / WEBP)
  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      onShowToast(lang === 'vi' ? 'Dung lượng ảnh tối đa là 5MB!' : 'Max image size is 5MB!', true);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setEditAvatar(base64);
      onShowToast(lang === 'vi' ? 'Đã tải ảnh lên! Nhấn "Lưu Thay Đổi" để áp dụng.' : 'Image loaded! Click Save to apply.');
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser?.username) return;

    setIsSaving(true);
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(currentUser.username)}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          displayName: editDisplayName.trim() || currentUser.username,
          bio: editBio.trim(),
          avatar: editAvatar || currentUser.avatar,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const updatedUser: UserAccount = {
          ...currentUser,
          displayName: data.user.displayName,
          bio: data.user.bio,
          avatar: data.user.avatar,
        };
        onUpdateCurrentUser(updatedUser);
        setProfile({
          ...profile!,
          displayName: data.user.displayName,
          bio: data.user.bio,
          avatar: data.user.avatar,
        });
        setIsEditing(false);
        onShowToast(lang === 'vi' ? 'Đã cập nhật hồ sơ cá nhân thành công!' : 'Profile updated successfully!');
      } else {
        const err = await res.json();
        onShowToast(err.error || 'Update failed', true);
      }
    } catch {
      onShowToast('Lỗi cập nhật hồ sơ', true);
    }
    setIsSaving(false);
  };

  if (!isOpen || !username) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-[#0e0e18] border border-white/15 rounded-3xl p-6 sm:p-7 shadow-[0_0_50px_rgba(255,42,109,0.25)] text-white space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-all cursor-pointer"
        >
          <i className="fa-solid fa-xmark text-sm"></i>
        </button>

        {isLoading ? (
          <div className="py-16 text-center space-y-3">
            <i className="fa-solid fa-circle-notch fa-spin text-3xl text-[#ff2a6d]"></i>
            <p className="text-sm text-gray-400">{lang === 'vi' ? 'Đang tải hồ sơ...' : 'Loading profile...'}</p>
          </div>
        ) : profile ? (
          <>
            {/* Header & Avatar */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 pt-2">
              <div className="relative group shrink-0">
                <img
                  src={
                    (isEditing ? editAvatar : profile.avatar) ||
                    `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(profile.username)}`
                  }
                  alt={profile.displayName}
                  className="w-24 h-24 rounded-2xl border-2 border-[#ff2a6d]/60 bg-black/40 object-cover shadow-[0_0_20px_rgba(255,42,109,0.3)]"
                />

                {/* Edit avatar button if editing */}
                {isEditing && (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 bg-black/60 rounded-2xl flex flex-col items-center justify-center text-white text-xs font-bold gap-1 cursor-pointer transition-all hover:bg-black/70"
                  >
                    <i className="fa-solid fa-camera text-base text-[#00ffcc]"></i>
                    <span>{lang === 'vi' ? 'Tải ảnh PNG' : 'Upload PNG'}</span>
                  </button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png, image/jpeg, image/webp, image/gif"
                  onChange={handleAvatarFileUpload}
                  className="hidden"
                />
              </div>

              <div className="text-center sm:text-left flex-grow space-y-1.5 min-w-0">
                <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                  <h3 className="text-xl font-black text-white truncate">
                    {isEditing ? editDisplayName : profile.displayName || profile.username}
                  </h3>

                  {profile.role === 'admin' || profile.username.toLowerCase() === 'admin' ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/50 text-[11px] font-extrabold flex items-center gap-1.5 shadow-[0_0_10px_rgba(239,68,68,0.4)]">
                      <span className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_6px_#ef4444] animate-pulse"></span>
                      <span>Admin</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full bg-white/5 text-gray-300 border border-white/10 text-[11px] font-semibold">
                      Member
                    </span>
                  )}
                </div>

                <p className="text-xs font-mono text-gray-400">@{profile.username}</p>

                {/* Follow Stats */}
                <div className="flex items-center justify-center sm:justify-start gap-4 pt-1 text-xs">
                  <div className="flex items-center gap-1.5">
                    <strong className="text-white font-bold text-sm">{profile.followersCount || 0}</strong>
                    <span className="text-gray-400">{lang === 'vi' ? 'Người theo dõi' : 'Followers'}</span>
                  </div>
                  <span className="text-gray-600">•</span>
                  <div className="flex items-center gap-1.5">
                    <strong className="text-white font-bold text-sm">{profile.followingCount || 0}</strong>
                    <span className="text-gray-400">{lang === 'vi' ? 'Đang theo dõi' : 'Following'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Profile Bio Section */}
            {!isEditing ? (
              <div className="bg-[#07070d] border border-white/10 rounded-2xl p-4 space-y-2">
                <span className="text-[11.5px] font-bold text-gray-400 uppercase tracking-wider block">
                  {lang === 'vi' ? 'Tiểu sử cá nhân' : 'About / Bio'}
                </span>
                <p className="text-[13.5px] text-gray-200 leading-relaxed whitespace-pre-line">
                  {profile.bio || (lang === 'vi' ? 'Chưa có tiểu sử.' : 'No bio available.')}
                </p>
              </div>
            ) : (
              /* Edit Profile Form */
              <form onSubmit={handleSaveProfile} className="space-y-4 bg-[#07070d] border border-white/10 rounded-2xl p-4">
                <div className="space-y-1.5">
                  <label className="text-[12px] font-bold text-gray-300 block">
                    {lang === 'vi' ? 'Tên hiển thị (Display Name)' : 'Display Name'}
                  </label>
                  <input
                    type="text"
                    value={editDisplayName}
                    onChange={(e) => setEditDisplayName(e.target.value)}
                    required
                    placeholder="VD: CyberScripter ⚡"
                    className="w-full bg-[#12121e] border border-white/10 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-[#ff2a6d]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[12px] font-bold text-gray-300 block">
                    {lang === 'vi' ? 'Tiểu sử (Bio)' : 'Bio description'}
                  </label>
                  <textarea
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    rows={3}
                    placeholder={lang === 'vi' ? 'Giới thiệu về bạn, script sở trường...' : 'Tell about yourself...'}
                    className="w-full bg-[#12121e] border border-white/10 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-[#ff2a6d] resize-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[12px] font-bold text-gray-300 block">
                    {lang === 'vi' ? 'Ảnh đại diện (Avatar)' : 'Profile Avatar'}
                  </label>

                  {/* Upload file or URL */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3.5 py-2 bg-white/10 hover:bg-white/15 border border-white/15 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-2 cursor-pointer transition-all"
                    >
                      <i className="fa-solid fa-file-arrow-up text-[#00ffcc]"></i>
                      <span>{lang === 'vi' ? 'Tải Ảnh Từ Máy (PNG/JPG)' : 'Upload Device Image'}</span>
                    </button>

                    <input
                      type="text"
                      value={editAvatar.startsWith('data:') ? '' : editAvatar}
                      onChange={(e) => setEditAvatar(e.target.value)}
                      placeholder={lang === 'vi' ? 'Hoặc dán Link URL ảnh...' : 'Or paste Avatar Image URL...'}
                      className="bg-[#12121e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff2a6d]"
                    />
                  </div>

                  {/* Preset Avatars */}
                  <div className="space-y-1 pt-1">
                    <span className="text-[11px] text-gray-400 block font-semibold">
                      {lang === 'vi' ? 'Hoặc chọn nhanh mẫu Avatar Bot Scripter:' : 'Or choose a Bot avatar preset:'}
                    </span>
                    <div className="flex items-center gap-2 overflow-x-auto py-1">
                      {AVATAR_PRESETS.map((preset, idx) => (
                        <img
                          key={idx}
                          src={preset}
                          alt=""
                          onClick={() => setEditAvatar(preset)}
                          className={`w-9 h-9 rounded-xl border-2 cursor-pointer transition-all object-cover shrink-0 hover:scale-105 ${
                            editAvatar === preset ? 'border-[#00ffcc] shadow-[0_0_10px_#00ffcc]' : 'border-white/10 hover:border-white/40'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 bg-white/5 hover:bg-white/10 text-gray-300 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    {lang === 'vi' ? 'Hủy' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-5 py-2 bg-[#ff2a6d] hover:brightness-110 text-white rounded-xl text-xs font-bold shadow-[0_0_15px_rgba(255,42,109,0.4)] flex items-center gap-1.5 cursor-pointer"
                  >
                    <i className="fa-solid fa-check"></i>
                    <span>{isSaving ? (lang === 'vi' ? 'Đang lưu...' : 'Saving...') : (lang === 'vi' ? 'Lưu Thay Đổi' : 'Save Changes')}</span>
                  </button>
                </div>
              </form>
            )}

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              {isOwnProfile ? (
                !isEditing && (
                  <button
                    type="button"
                    onClick={() => setIsEditing(true)}
                    className="w-full py-2.5 bg-gradient-to-r from-[#ff2a6d] to-[#ff5e87] hover:brightness-110 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(255,42,109,0.35)] transition-all"
                  >
                    <i className="fa-solid fa-user-pen"></i>
                    <span>{lang === 'vi' ? 'Chỉnh Sửa Hồ Sơ (Đổi Avatar, Tên, Bio)' : 'Edit Profile (Avatar, Name, Bio)'}</span>
                  </button>
                )
              ) : (
                <button
                  type="button"
                  onClick={handleToggleFollow}
                  className={`w-full py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
                    isFollowing
                      ? 'bg-white/10 hover:bg-white/15 text-emerald-300 border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                      : 'bg-[#ff2a6d] hover:brightness-110 text-white shadow-[0_0_15px_rgba(255,42,109,0.4)]'
                  }`}
                >
                  <i className={`fa-solid ${isFollowing ? 'fa-user-check' : 'fa-user-plus'}`}></i>
                  <span>
                    {isFollowing
                      ? (lang === 'vi' ? 'Đang Theo Dõi (Bấm để hủy)' : 'Following (Click to unfollow)')
                      : (lang === 'vi' ? `Theo dõi @${profile.username}` : `Follow @${profile.username}`)}
                  </span>
                </button>
              )}
            </div>
          </>
        ) : (
          <p className="text-center text-gray-400 py-10">
            {lang === 'vi' ? 'Không tìm thấy thông tin người dùng.' : 'User profile not found.'}
          </p>
        )}
      </div>
    </div>
  );
};
