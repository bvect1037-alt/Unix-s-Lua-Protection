import React, { useState, useEffect } from 'react';
import {
  generateScriptId,
  generateSecurePassword,
  buildSecureLuaPackage,
  ProtectionResult,
} from '../services/luaProtection';
import { ProtectedHistoryItem, UserAccount, ProtectedScriptItem } from '../types';

interface ProtectionSectionProps {
  lang: 'vi' | 'en';
  currentUser: UserAccount | null;
  onShowToast: (msg: string, isError?: boolean) => void;
  onOpenAuth?: () => void;
  onOpenGatewaySimulator: (scriptId: string) => void;
}

export const ProtectionSection: React.FC<ProtectionSectionProps> = ({
  lang,
  currentUser,
  onShowToast,
  onOpenAuth,
  onOpenGatewaySimulator,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'create' | 'manage'>('create');

  // Generator form states
  const [inputCode, setInputCode] = useState('');
  const [fileName, setFileName] = useState('');
  const [scriptName, setScriptName] = useState('');
  const [baseUrl, setBaseUrl] = useState('');

  // Results & History
  const [result, setResult] = useState<ProtectionResult | null>(null);
  const [userScripts, setUserScripts] = useState<ProtectedScriptItem[]>([]);
  const [historyList, setHistoryList] = useState<ProtectedHistoryItem[]>([]);

  // Edit / Update Raw Modal State
  const [editingScript, setEditingScript] = useState<ProtectedScriptItem | null>(null);
  const [editSourceCode, setEditSourceCode] = useState('');
  const [editScriptName, setEditScriptName] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Executor Test State
  const [simulatingScriptId, setSimulatingScriptId] = useState<string | null>(null);
  const [simulatedContent, setSimulatedContent] = useState<string>('');
  const [isSimulating, setIsSimulating] = useState(false);

  // Multi-Host Selection: 'public' (Dpaste/Paste.rs CDN) | 'direct' (Web App .lua) | 'safe' (Safe pcall Loader)
  const [selectedHostType, setSelectedHostType] = useState<'public' | 'direct' | 'safe'>('public');
  const [isPublishingCdn, setIsPublishingCdn] = useState(false);

  useEffect(() => {
    setBaseUrl(window.location.origin);
    loadScripts();
  }, [currentUser]);

  const loadScripts = async () => {
    const saved = localStorage.getItem('unix_history_list');
    let localHistory: ProtectedHistoryItem[] = [];
    if (saved) {
      try {
        localHistory = JSON.parse(saved);
        setHistoryList(localHistory);
      } catch {
        setHistoryList([]);
      }
    }

    try {
      const url = currentUser?.username
        ? `/api/scripts?username=${encodeURIComponent(currentUser.username)}`
        : '/api/scripts';
      const res = await fetch(url);
      if (res.ok) {
        const data: ProtectedScriptItem[] = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setUserScripts(data);
          return;
        }
      }
    } catch {
      // offline fallback
    }

    const localScripts: ProtectedScriptItem[] = localHistory.map((h) => {
      const luaUrl = `${window.location.origin}/raw/${h.id}.lua`;
      const loadstring = `loadstring(game:HttpGet("${luaUrl}"))()`;

      return {
        id: h.id,
        name: h.name,
        password: h.password,
        antiHook: h.antiHook,
        ownerUsername: h.ownerUsername || currentUser?.username || 'Guest',
        sourceCode: h.sourceCode || `-- Source for #${h.id}`,
        protectedLua: h.protectedLua || h.sourceCode || `-- Script #${h.id}`,
        rawUrl: luaUrl,
        gatewayUrl: luaUrl,
        loadstringCmd: loadstring,
        createdAt: h.time || (lang === 'vi' ? new Date().toLocaleString('vi-VN') : new Date().toLocaleString('en-US')),
        updatedAt: h.updatedAt || h.time || (lang === 'vi' ? new Date().toLocaleString('vi-VN') : new Date().toLocaleString('en-US')),
      };
    });

    setUserScripts(localScripts);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const lower = file.name.toLowerCase();
    if (!lower.endsWith('.lua') && !lower.endsWith('.txt')) {
      onShowToast(lang === 'vi' ? 'Chỉ hỗ trợ file .lua hoặc .txt!' : 'Only .lua or .txt files supported!', true);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const content = String(reader.result || '');
      setInputCode(content);
      setFileName(file.name);

      const base = file.name.replace(/\.(lua|txt)$/i, '');
      if (!scriptName.trim()) {
        setScriptName(base);
      }
      onShowToast(lang === 'vi' ? `Đã đọc file: ${file.name}` : `File loaded: ${file.name}`);
    };
    reader.onerror = () => {
      onShowToast(lang === 'vi' ? 'Không đọc được file!' : 'Failed to read file!', true);
    };
    reader.readAsText(file);
  };

  const handlePublishToPublicCdn = async (code: string, name: string, id: string) => {
    setIsPublishingCdn(true);
    try {
      const res = await fetch('/api/publish-raw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          name,
          id,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.publicRawUrl) {
          setResult((prev) => {
            if (!prev) return prev;
            return {
              ...prev,
              publicRawUrl: data.publicRawUrl,
              publicProvider: data.provider || 'Dpaste CDN',
              safeLoadstring: data.safeLoadstring,
            };
          });

          // Update local history
          setHistoryList((prevList) =>
            prevList.map((item) =>
              item.id === id
                ? {
                    ...item,
                    publicRawUrl: data.publicRawUrl,
                    publicProvider: data.provider,
                  }
                : item
            )
          );

          onShowToast(
            lang === 'vi'
              ? `Đã xuất bản lên Host Public (${data.provider || 'Dpaste'}) thành công!`
              : `Published to Public Host (${data.provider || 'Dpaste'})!`
          );
        }
      }
    } catch (err) {
      console.warn('Publish CDN error:', err);
    } finally {
      setIsPublishingCdn(false);
    }
  };

  const handleGenerateProtection = async () => {
    if (!inputCode.trim()) {
      onShowToast(lang === 'vi' ? 'Vui lòng nhập mã nguồn Lua!' : 'Please enter Lua source code!', true);
      return;
    }

    // Auto-generated ID
    const scriptId = generateScriptId();
    const cleanBase = (baseUrl.trim() || window.location.origin).replace(/\/+$/, '');
    const cleanName = scriptName.trim() || `Script_${scriptId.substring(0, 6)}`;

    // 100% Pure Untouched Raw Lua Code (Zero modification)
    const rawLuaCode = inputCode.trim();

    // Primary .lua Raw URL & Loadstring (with 0.01s Browser Trap + Pure Executor Stream)
    const luaUrl = `${cleanBase}/raw/${scriptId}.lua`;
    const luaLoadstring = `loadstring(game:HttpGet("${luaUrl}"))()`;

    const initialResult: ProtectionResult = {
      scriptId,
      scriptName: cleanName,
      rawLua: rawLuaCode,
      rawUrl: luaUrl,
      gatewayUrl: luaUrl,
      loadstringCmd: luaLoadstring,
      txtUrl: luaUrl,
      txtLoadstring: luaLoadstring,
      createdAt: lang === 'vi' ? new Date().toLocaleString('vi-VN') : new Date().toLocaleString('en-US'),
      protectionMode: 'pure',
    };

    setResult(initialResult);

    // Save locally
    const historyItem: ProtectedHistoryItem = {
      id: scriptId,
      name: cleanName,
      antiHook: false,
      link: luaUrl,
      rawUrl: luaUrl,
      time: initialResult.createdAt,
      updatedAt: initialResult.createdAt,
      ownerUsername: currentUser?.username || 'Guest',
      sourceCode: rawLuaCode,
      protectedLua: rawLuaCode,
    };

    const updatedHistory = [historyItem, ...historyList.filter((h) => h.id !== scriptId)];
    setHistoryList(updatedHistory);
    localStorage.setItem('unix_history_list', JSON.stringify(updatedHistory));
    localStorage.setItem(
      `unix_prot_${scriptId}`,
      JSON.stringify({
        id: scriptId,
        name: cleanName,
        lua: rawLuaCode,
        source: rawLuaCode,
        createdAt: initialResult.createdAt,
      })
    );

    // Save to server DB so executor game:HttpGet can fetch it immediately
    try {
      await fetch('/api/scripts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: scriptId,
          name: cleanName,
          ownerUsername: currentUser?.username || 'Guest',
          sourceCode: rawLuaCode,
          protectedLua: rawLuaCode,
        }),
      });
      loadScripts();
    } catch {
      // ignore
    }

    // Automatically publish to Universal Public Host (Dpaste / Paste.rs) in background
    handlePublishToPublicCdn(rawLuaCode, cleanName, scriptId);

    onShowToast(
      lang === 'vi'
        ? `Đã tạo script thành công! Đang kết nối Host Public toàn cầu...`
        : `Generated script! Connecting to global public host...`
    );
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    onShowToast(lang === 'vi' ? `Đã sao chép ${label}!` : `Copied ${label}!`);
  };

  const openEditModal = (script: ProtectedScriptItem) => {
    setEditingScript(script);
    setEditScriptName(script.name);
    setEditSourceCode(script.sourceCode || script.protectedLua || '');
  };

  const handleSaveEditedScript = async () => {
    if (!editingScript) return;
    if (!editSourceCode.trim()) {
      onShowToast(lang === 'vi' ? 'Mã nguồn Lua không được để trống!' : 'Lua code cannot be empty!', true);
      return;
    }

    setIsSavingEdit(true);

    try {
      const cleanName = editScriptName.trim() || editingScript.name;
      const rawLua = editSourceCode.trim();

      // Update server
      const res = await fetch(`/api/scripts/${editingScript.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: cleanName,
          ownerUsername: editingScript.ownerUsername || currentUser?.username || 'Guest',
          sourceCode: editSourceCode,
          protectedLua: rawLua,
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to update script on server');
      }

      const nowTime = lang === 'vi' ? new Date().toLocaleString('vi-VN') : new Date().toLocaleString('en-US');

      // Update local storage
      const updatedHistory = historyList.map((h) => {
        if (h.id === editingScript.id) {
          return {
            ...h,
            name: cleanName,
            sourceCode: editSourceCode,
            protectedLua: rawLua,
            updatedAt: nowTime,
          };
        }
        return h;
      });
      setHistoryList(updatedHistory);
      localStorage.setItem('unix_history_list', JSON.stringify(updatedHistory));
      localStorage.setItem(
        `unix_prot_${editingScript.id}`,
        JSON.stringify({
          id: editingScript.id,
          name: cleanName,
          lua: rawLua,
          source: editSourceCode,
          updatedAt: nowTime,
        })
      );

      // If active result is this script, update it
      if (result && result.scriptId === editingScript.id) {
        const txtUrl = `${window.location.origin}/raw/${editingScript.id}.txt`;
        const loadstringCmd = `loadstring(game:HttpGet("${txtUrl}"))()`;

        setResult({
          ...result,
          scriptName: cleanName,
          rawLua,
          rawUrl: txtUrl,
          gatewayUrl: txtUrl,
          txtUrl,
          txtLoadstring: loadstringCmd,
          loadstringCmd,
        });
      }

      await loadScripts();
      setEditingScript(null);
      onShowToast(
        lang === 'vi'
          ? `Đã cập nhật Raw Lua thành công cho Script #${editingScript.id}!`
          : `Updated Raw Lua successfully for Script #${editingScript.id}!`
      );
    } catch (err) {
      console.error(err);
      onShowToast(lang === 'vi' ? 'Lỗi khi cập nhật script!' : 'Error updating script!', true);
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleDeleteScript = async (scriptId: string) => {
    if (!window.confirm(lang === 'vi' ? 'Bạn có chắc chắn muốn xóa script này?' : 'Are you sure you want to delete this script?')) {
      return;
    }

    try {
      await fetch(`/api/scripts/${scriptId}`, { method: 'DELETE' });
    } catch {
      // ignore
    }

    const updated = historyList.filter((h) => h.id !== scriptId);
    setHistoryList(updated);
    localStorage.setItem('unix_history_list', JSON.stringify(updated));
    localStorage.removeItem(`unix_prot_${scriptId}`);

    if (result && result.scriptId === scriptId) {
      setResult(null);
    }

    await loadScripts();
    onShowToast(lang === 'vi' ? 'Đã xóa script thành công!' : 'Script deleted successfully!');
  };

  const handleSimulateRobloxHttpGet = async (scriptId: string) => {
    setIsSimulating(true);
    setSimulatingScriptId(scriptId);
    try {
      const res = await fetch(`/raw/${scriptId}.txt`, {
        headers: {
          'x-unix-sim': '1',
          'User-Agent': 'Roblox/WinInet (Unix Auth Plain Executor Stream)',
        },
      });
      const text = await res.text();
      setSimulatedContent(text);
    } catch {
      setSimulatedContent(lang === 'vi' ? '-- [Error] Không thể tải dữ liệu từ máy chủ' : '-- [Error] Failed to fetch data from server');
    } finally {
      setIsSimulating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div
        style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--border-color)',
          borderRadius: '16px',
          padding: '24px',
        }}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00ffcc] shadow-[0_0_8px_#00ffcc]"></span>
              <span className="text-[12px] font-bold tracking-wider text-[#00ffcc] uppercase">
                UNIX AUTH V5 • LUA RAW PROTECTION (.LUA)
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              {lang === 'vi' ? 'Bảo Vệ & Cấp Link Loadstring Lua (.lua • Reload 0.01s)' : 'Lua Raw Protection (.lua • 0.01s Reload)'}
            </h2>
            <p className="text-[13.5px] text-gray-400 mt-1 max-w-2xl leading-relaxed">
              {lang === 'vi'
                ? 'Hệ thống cấp link .lua thuần túy: Khi mở trên Trình duyệt sẽ tự động Reload liên tục 0.01s (chống soi/dump mã nguồn); khi chạy bằng game:HttpGet trên Roblox Executor sẽ trả về 100% mã nguồn nguyên bản, không can thiệp code.'
                : 'Pure .lua script service: Automatically reloads every 0.01s in web browsers (anti-inspect / anti-dump), while delivering 100% untouched Lua code to Roblox Executors via game:HttpGet.'}
            </p>
          </div>

          {/* Sub-tab Navigation */}
          <div className="flex items-center bg-[#07070d] p-1.5 rounded-xl border border-white/10 shrink-0">
            <button
              onClick={() => setActiveSubTab('create')}
              className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition-all flex items-center gap-2 ${
                activeSubTab === 'create'
                  ? 'bg-[#ff2a6d] text-white shadow-[0_0_15px_rgba(255,42,109,0.4)]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <i className="fa-solid fa-plus-circle"></i>
              <span>{lang === 'vi' ? 'Tạo Script Mới' : 'Create Script'}</span>
            </button>
            <button
              onClick={() => setActiveSubTab('manage')}
              className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition-all flex items-center gap-2 ${
                activeSubTab === 'manage'
                  ? 'bg-[#b388ff] text-white shadow-[0_0_15px_rgba(179,136,255,0.4)]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <i className="fa-solid fa-folder-tree"></i>
              <span>{lang === 'vi' ? 'Quản Lý Scripts' : 'Manage Scripts'}</span>
              <span className="px-2 py-0.5 text-[11px] rounded-full bg-white/15 text-white">
                {userScripts.length}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* SUB-TAB 1: CREATE SCRIPT */}
      {activeSubTab === 'create' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Form Configuration */}
          <div className="lg:col-span-7 space-y-5">
            <div
              style={{
                background: 'var(--card-bg)',
                border: '1px solid var(--border-color)',
                borderRadius: '16px',
                padding: '24px',
              }}
              className="space-y-5"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <i className="fa-solid fa-shield-halved text-[#ff2a6d]"></i>
                  <h3 className="text-base font-bold text-white">
                    {lang === 'vi' ? 'Cấu Hình Bảo Vệ & Mã Nguồn' : 'Protection Settings & Source'}
                  </h3>
                </div>
                <div className="text-[12px] text-gray-400">
                  {currentUser ? (
                    <span className="text-[#00ffcc] font-medium flex items-center gap-1.5">
                      <i className="fa-solid fa-user-check"></i>
                      {currentUser.username}
                    </span>
                  ) : (
                    <button
                      onClick={onOpenAuth}
                      className="text-[#ff2a6d] hover:underline text-[12px] flex items-center gap-1"
                    >
                      <i className="fa-solid fa-arrow-right-to-bracket"></i>
                      {lang === 'vi' ? 'Đăng nhập để lưu' : 'Sign in to save'}
                    </button>
                  )}
                </div>
              </div>

              {/* Script Name */}
              <div>
                <label className="block text-[13px] font-semibold text-gray-300 mb-1.5">
                  {lang === 'vi' ? 'Tên Script / Dự Án' : 'Script / Project Name'}
                </label>
                <input
                  type="text"
                  value={scriptName}
                  onChange={(e) => setScriptName(e.target.value)}
                  placeholder={lang === 'vi' ? 'Ví dụ: HWF Hub' : 'E.g.: HWF Hub'}
                  className="w-full bg-[#07070d] border border-white/10 rounded-xl px-3.5 py-2.5 text-[13.5px] text-white focus:outline-none focus:border-[#00ffcc] transition-all font-mono placeholder:text-gray-600"
                />
              </div>

              {/* File Upload Option */}
              <div>
                <label className="block text-[13px] font-semibold text-gray-300 mb-1.5">
                  {lang === 'vi' ? 'Tải File Script Từ Máy Tính' : 'Upload Script File from PC'}
                </label>
                <label className="w-full bg-[#07070d] border border-white/10 hover:border-[#00ffcc]/50 rounded-xl px-3.5 py-2.5 text-[13px] text-gray-300 flex items-center justify-between cursor-pointer transition-all">
                  <span className="truncate max-w-[280px] text-gray-400">
                    {fileName || (lang === 'vi' ? 'Chưa chọn file (.lua, .txt)' : 'No file selected (.lua, .txt)')}
                  </span>
                  <span className="px-2.5 py-1 text-[11px] font-semibold rounded bg-white/10 text-white shrink-0">
                    <i className="fa-solid fa-upload mr-1"></i> {lang === 'vi' ? 'Chọn File' : 'Browse'}
                  </span>
                  <input
                    type="file"
                    accept=".lua,.txt"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Lua Code Textarea */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[13px] font-semibold text-gray-300">
                    {lang === 'vi' ? 'Mã Nguồn Raw Lua (100% Nguyên Bản Không Can Thiệp)' : 'Raw Lua Source Code (100% Untouched)'}
                  </label>
                  <span className="text-[11.5px] text-gray-500 font-mono">
                    {inputCode ? `${inputCode.split('\n').length} ${lang === 'vi' ? 'dòng' : 'lines'} • ${inputCode.length} ${lang === 'vi' ? 'ký tự' : 'chars'}` : (lang === 'vi' ? 'Chưa có mã' : 'Empty')}
                  </span>
                </div>
                <textarea
                  rows={14}
                  value={inputCode}
                  onChange={(e) => setInputCode(e.target.value)}
                  placeholder={
                    lang === 'vi'
                      ? '-- Dán mã nguồn Lua của bạn vào đây...\n-- Ví dụ: Fluent UI, Rayfield UI, Auto Farm, ESP, Teleport, etc.\n\nlocal Rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()'
                      : '-- Paste your raw Lua script here...\n-- E.g. Fluent UI, Rayfield UI, Auto Farm, ESP, Teleport, etc.\n\nlocal Rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()'
                  }
                  spellCheck={false}
                  className="w-full bg-[#050508] border border-white/10 rounded-xl p-4 text-[13px] text-gray-200 font-mono focus:outline-none focus:border-[#00ffcc] transition-all leading-relaxed resize-y placeholder:text-gray-600"
                  style={{ minHeight: '260px' }}
                />
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerateProtection}
                className="w-full bg-gradient-to-r from-[#00ffcc] to-[#00b386] hover:brightness-110 text-black font-bold text-[14.5px] py-3.5 px-6 rounded-xl shadow-[0_0_20px_rgba(0,255,204,0.35)] transition-all flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <i className="fa-solid fa-bolt text-base"></i>
                <span>{lang === 'vi' ? 'Tạo Link .lua & Loadstring' : 'Generate .lua Loadstring'}</span>
              </button>
            </div>
          </div>

          {/* Right Column: Output & Loadstring Box */}
          <div className="lg:col-span-5 space-y-5">
            {result ? (
              <div
                style={{
                  background: 'var(--card-bg)',
                  border: '1px solid #00ffcc',
                  borderRadius: '16px',
                  padding: '24px',
                }}
                className="space-y-5 shadow-[0_0_30px_rgba(0,255,204,0.15)]"
              >
                {/* Result Header */}
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#00ffcc] animate-pulse"></span>
                    <h3 className="text-base font-bold text-white">
                      {lang === 'vi' ? 'Kết Quả Script Loadstring' : 'Script Loadstring Result'}
                    </h3>
                  </div>
                  <span className="text-[11px] font-mono font-semibold px-2.5 py-1 bg-white/10 text-[#00ffcc] rounded-lg">
                    #{result.scriptId}.lua
                  </span>
                </div>

                {/* Host Mode Switcher Tabs */}
                <div className="space-y-2">
                  <label className="text-[12px] font-semibold text-gray-300 block">
                    {lang === 'vi' ? 'Chọn Máy Chủ / Kiểu Loadstring:' : 'Select Host / Loadstring Mode:'}
                  </label>
                  <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#050508] border border-white/10 rounded-xl">
                    <button
                      onClick={() => setSelectedHostType('public')}
                      className={`py-2 px-2 text-[11.5px] font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        selectedHostType === 'public'
                          ? 'bg-[#00ffcc] text-black shadow-[0_0_10px_rgba(0,255,204,0.4)]'
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      <i className="fa-solid fa-earth-americas"></i>
                      <span>{lang === 'vi' ? 'Public CDN' : 'Public CDN'}</span>
                    </button>

                    <button
                      onClick={() => setSelectedHostType('direct')}
                      className={`py-2 px-2 text-[11.5px] font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        selectedHostType === 'direct'
                          ? 'bg-[#00ffcc] text-black shadow-[0_0_10px_rgba(0,255,204,0.4)]'
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      <i className="fa-solid fa-bolt"></i>
                      <span>{lang === 'vi' ? 'Web Direct' : 'Web Direct'}</span>
                    </button>

                    <button
                      onClick={() => setSelectedHostType('safe')}
                      className={`py-2 px-2 text-[11.5px] font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        selectedHostType === 'safe'
                          ? 'bg-[#00ffcc] text-black shadow-[0_0_10px_rgba(0,255,204,0.4)]'
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      <i className="fa-solid fa-shield"></i>
                      <span>{lang === 'vi' ? 'Safe Loader' : 'Safe Loader'}</span>
                    </button>
                  </div>
                </div>

                {/* TAB 1: PUBLIC HOST (DPASTE / PASTE.RS) - RECOMMENDED FOR ROBLOX */}
                {selectedHostType === 'public' && (
                  <div className="p-4 bg-[#07070d] border border-[#00ffcc]/60 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <i className="fa-solid fa-cloud text-[#00ffcc]"></i>
                        <span className="text-[13px] font-bold text-white">
                          {lang === 'vi' ? 'Roblox Loadstring (Public CDN)' : 'Roblox Loadstring (Public CDN)'}
                        </span>
                        <span className="text-[10px] bg-[#00ffcc]/20 text-[#00ffcc] px-1.5 py-0.5 rounded font-mono font-bold">
                          {result.publicProvider || 'Dpaste CDN'}
                        </span>
                      </div>

                      <button
                        onClick={() =>
                          copyToClipboard(
                            result.publicRawUrl
                              ? `loadstring(game:HttpGet("${result.publicRawUrl}"))()`
                              : result.txtLoadstring,
                            'Loadstring Public CDN'
                          )
                        }
                        className="text-[12px] font-bold text-black bg-[#00ffcc] hover:bg-[#00e6b8] px-3 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer shadow-[0_0_10px_rgba(0,255,204,0.3)]"
                      >
                        <i className="fa-solid fa-copy"></i>
                        {lang === 'vi' ? 'Sao chép' : 'Copy'}
                      </button>
                    </div>

                    <div className="bg-[#050508] border border-[#00ffcc]/30 rounded-lg p-3 text-[12px] font-mono text-[#00ffcc] break-all select-all leading-relaxed shadow-inner">
                      {result.publicRawUrl ? (
                        `loadstring(game:HttpGet("${result.publicRawUrl}"))()`
                      ) : isPublishingCdn ? (
                        <span className="text-gray-400 flex items-center gap-2">
                          <i className="fa-solid fa-spinner fa-spin text-[#00ffcc]"></i>
                          {lang === 'vi' ? 'Đang kết nối tạo link Public CDN...' : 'Connecting to Public CDN...'}
                        </span>
                      ) : (
                        `loadstring(game:HttpGet("${result.txtUrl}"))()`
                      )}
                    </div>

                    <div className="p-2.5 bg-[#00ffcc]/10 border border-[#00ffcc]/30 rounded-lg text-[11.5px] text-[#00ffcc] flex items-start gap-2">
                      <i className="fa-solid fa-circle-check text-base mt-0.5 shrink-0"></i>
                      <span>
                        {lang === 'vi'
                          ? '🌟 Khuyên Dùng: Chạy 100% trên Roblox ngoài máy (Delta, Fluxus, Wave, Codex, Solara), không bao giờ bị lỗi nil value hay lỗi chặn sandbox.'
                          : '🌟 Recommended: Runs 100% on external Roblox executors without nil value errors or sandbox blocks.'}
                      </span>
                    </div>

                    {/* Re-Publish Button */}
                    <button
                      onClick={() => handlePublishToPublicCdn(result.rawLua, result.scriptName, result.scriptId)}
                      disabled={isPublishingCdn}
                      className="w-full text-xs text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <i className={`fa-solid fa-rotate ${isPublishingCdn ? 'fa-spin' : ''}`}></i>
                      <span>{lang === 'vi' ? 'Đổi Sang Host Public Khác / Xuất Bản Lại' : 'Switch to Alternative Public Host'}</span>
                    </button>
                  </div>
                )}

                {/* TAB 2: DIRECT WEB APP .LUA */}
                {selectedHostType === 'direct' && (
                  <div className="p-4 bg-[#07070d] border border-white/15 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <i className="fa-solid fa-bolt text-[#ff2a6d]"></i>
                        <span className="text-[13px] font-bold text-white">
                          {lang === 'vi' ? 'Web Direct Loadstring (.lua)' : 'Web Direct Loadstring (.lua)'}
                        </span>
                      </div>

                      <button
                        onClick={() => copyToClipboard(result.txtLoadstring, 'Loadstring Web Direct')}
                        className="text-[12px] font-bold text-white bg-white/15 hover:bg-white/25 px-3 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                      >
                        <i className="fa-solid fa-copy"></i>
                        {lang === 'vi' ? 'Sao chép' : 'Copy'}
                      </button>
                    </div>

                    <div className="bg-[#050508] border border-white/15 rounded-lg p-3 text-[12px] font-mono text-[#00ffcc] break-all select-all leading-relaxed shadow-inner">
                      {result.txtLoadstring}
                    </div>

                    <div className="p-2.5 bg-[#ff2a6d]/10 border border-[#ff2a6d]/30 rounded-lg text-[11.5px] text-[#ff2a6d] flex items-start gap-2">
                      <i className="fa-solid fa-circle-exclamation text-base mt-0.5 shrink-0"></i>
                      <span>
                        {lang === 'vi'
                          ? '⚠️ Lưu ý: Nếu URL có dạng ais-dev-...run.app, máy ngoài sẽ bị Google Sandbox chặn và trả về nil value. Hãy dùng tab Public CDN để chạy thật trên Roblox!'
                          : '⚠️ Note: If URL is ais-dev-...run.app, external clients are blocked by Google Sandbox auth. Use Public CDN tab for Roblox!'}
                      </span>
                    </div>
                  </div>
                )}

                {/* TAB 3: SAFE LOADER WITH ERROR CATCHING */}
                {selectedHostType === 'safe' && (
                  <div className="p-4 bg-[#07070d] border border-[#b388ff]/50 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <i className="fa-solid fa-shield-halved text-[#b388ff]"></i>
                        <span className="text-[13px] font-bold text-white">
                          {lang === 'vi' ? 'Safe Loader (Tự Bắt Lỗi & Chống Crash)' : 'Safe Loader (Error-Proof)'}
                        </span>
                      </div>

                      <button
                        onClick={() =>
                          copyToClipboard(
                            result.safeLoadstring ||
                              `local url = "${result.publicRawUrl || result.txtUrl}"\nlocal s = game:HttpGet(url)\nif s and #s > 0 then loadstring(s)() else warn("[Unix] Khong the tai ma!") end`,
                            'Safe Loader'
                          )
                        }
                        className="text-[12px] font-bold text-white bg-[#b388ff] hover:bg-[#9d6efc] px-3 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer shadow-[0_0_10px_rgba(179,136,255,0.3)]"
                      >
                        <i className="fa-solid fa-copy"></i>
                        {lang === 'vi' ? 'Sao chép' : 'Copy'}
                      </button>
                    </div>

                    <pre className="bg-[#050508] border border-[#b388ff]/20 rounded-lg p-3 text-[11.5px] font-mono text-gray-200 whitespace-pre-wrap select-all leading-relaxed shadow-inner max-h-[160px] overflow-y-auto">
                      {result.safeLoadstring ||
                        `local url = "${result.publicRawUrl || result.txtUrl}"\nlocal s = game:HttpGet(url)\nif s and #s > 0 then\n    local run, err = loadstring(s)\n    if run then\n        run()\n    else\n        warn("[Unix] Loi cu phap: " .. tostring(err))\n    end\nelse\n    warn("[Unix] Khong the tai ma nguon tu link!")\nend`}
                    </pre>

                    <p className="text-[11px] text-gray-400">
                      {lang === 'vi'
                        ? '🛡️ Tự động kiểm tra dữ liệu tải về từ game:HttpGet, báo lỗi chi tiết ra Developer Console (F9) thay vì văng crash game.'
                        : '🛡️ Verifies response before execution, reporting errors to F9 Console without crashing.'}
                    </p>
                  </div>
                )}

                {/* Direct Raw Link & Details */}
                <div className="pt-2 border-t border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>{lang === 'vi' ? 'Link Raw Trực Tiếp:' : 'Direct Raw URL:'}</span>
                    <button
                      onClick={() => copyToClipboard(result.publicRawUrl || result.txtUrl, 'Link Raw')}
                      className="text-[#00ffcc] hover:underline flex items-center gap-1"
                    >
                      <i className="fa-solid fa-copy"></i> {lang === 'vi' ? 'Copy URL' : 'Copy URL'}
                    </button>
                  </div>
                  <div className="bg-[#050508] border border-white/10 rounded-lg p-2.5 text-[11.5px] font-mono text-gray-300 break-all select-all">
                    {result.publicRawUrl || result.txtUrl}
                  </div>
                </div>

                {/* Testing Simulation Action */}
                <div className="pt-1">
                  <button
                    onClick={() => handleSimulateRobloxHttpGet(result.scriptId)}
                    className="w-full bg-[#12131e] hover:bg-[#1a1c2b] border border-white/15 hover:border-[#00ffcc]/50 text-[#00ffcc] font-semibold text-[13px] py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <i className="fa-solid fa-play"></i>
                    <span>{lang === 'vi' ? 'Kiểm Tra / Test Roblox HttpGet' : 'Test Roblox HttpGet'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div
                style={{
                  background: 'var(--card-bg)',
                  border: '1px dashed var(--border-color)',
                  borderRadius: '16px',
                  padding: '32px 24px',
                }}
                className="text-center space-y-4"
              >
                <div className="w-14 h-14 mx-auto rounded-2xl bg-[#00ffcc]/10 border border-[#00ffcc]/20 flex items-center justify-center text-[#00ffcc] text-2xl">
                  <i className="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                  <h4 className="text-base font-bold text-white mb-1">
                    {lang === 'vi' ? 'Chưa Có Script Nào Được Tạo' : 'No Script Generated Yet'}
                  </h4>
                  <p className="text-[13px] text-gray-400 max-w-sm mx-auto leading-relaxed">
                    {lang === 'vi'
                      ? 'Nhập mã nguồn Lua ở cột bên trái và bấm "Tạo Script Bảo Vệ & Link .txt" để nhận ngay loadstring hoạt động 100% trên Roblox.'
                      : 'Input your Lua code on the left and click "Generate Protected .txt Loadstring" to get a 100% working Roblox executor command.'}
                  </p>
                </div>
              </div>
            )}

            {/* LIVE SIMULATOR MODAL / RESULT BOX */}
            {simulatingScriptId && (
              <div
                style={{
                  background: '#07070d',
                  border: '1px solid #00ffcc',
                  borderRadius: '16px',
                  padding: '20px',
                }}
                className="space-y-3 shadow-[0_0_20px_rgba(0,255,204,0.15)]"
              >
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <div className="flex items-center gap-2">
                    <i className="fa-solid fa-circle-check text-[#00ffcc]"></i>
                    <span className="text-[13px] font-bold text-white">
                      {lang === 'vi' ? `Kết Quả Test game:HttpGet(/raw/${simulatingScriptId}.txt)` : `Test Output: game:HttpGet(/raw/${simulatingScriptId}.txt)`}
                    </span>
                  </div>
                  <button
                    onClick={() => setSimulatingScriptId(null)}
                    className="text-gray-400 hover:text-white text-xs"
                  >
                    <i className="fa-solid fa-xmark"></i>
                  </button>
                </div>

                {isSimulating ? (
                  <div className="py-6 text-center text-gray-400 text-sm flex items-center justify-center gap-2">
                    <i className="fa-solid fa-spinner fa-spin text-[#00ffcc]"></i>
                    <span>{lang === 'vi' ? 'Đang gửi yêu cầu HttpGet...' : 'Sending HttpGet request...'}</span>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-gray-400">
                      <span className="text-[#00ffcc]">Status: 200 OK (Content-Type: text/plain)</span>
                      <span>{simulatedContent.split('\n').length} lines</span>
                    </div>
                    <pre className="bg-[#050508] border border-white/10 rounded-lg p-3 text-[11.5px] font-mono text-gray-300 max-h-[180px] overflow-y-auto whitespace-pre-wrap select-all">
                      {simulatedContent}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: MANAGE SCRIPTS */}
      {activeSubTab === 'manage' && (
        <div
          style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: '16px',
            padding: '24px',
          }}
          className="space-y-4"
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <i className="fa-solid fa-list-check text-[#b388ff]"></i>
              <span>{lang === 'vi' ? 'Danh Sách Script Đã Bảo Vệ' : 'Protected Scripts List'}</span>
            </h3>
            <span className="text-xs text-gray-400">
              {userScripts.length} {lang === 'vi' ? 'kết quả' : 'records'}
            </span>
          </div>

          {userScripts.length === 0 ? (
            <div className="text-center py-12 text-gray-400 space-y-2">
              <i className="fa-solid fa-folder-open text-3xl opacity-40"></i>
              <p>{lang === 'vi' ? 'Chưa có script nào trong danh sách' : 'No scripts in history yet'}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {userScripts.map((s) => {
                const directUrl = `${window.location.origin}/raw/${s.id}.lua`;
                const activeUrl = s.publicRawUrl || directUrl;
                const loadstring = `loadstring(game:HttpGet("${activeUrl}"))()`;

                return (
                  <div
                    key={s.id}
                    className="bg-[#07070d] border border-white/10 hover:border-[#00ffcc]/50 rounded-xl p-4 space-y-3 transition-all flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[13px] font-bold text-white truncate max-w-[180px]">
                          {s.name}
                        </span>
                        <span className={`text-[10.5px] font-mono px-2 py-0.5 rounded border ${
                          s.publicRawUrl
                            ? 'text-[#00ffcc] bg-[#00ffcc]/10 border-[#00ffcc]/30'
                            : 'text-gray-400 bg-white/5 border-white/10'
                        }`}>
                          {s.publicRawUrl ? (s.publicProvider || 'Public CDN') : `#${s.id}.lua`}
                        </span>
                      </div>

                      <div className="bg-[#050508] border border-white/10 rounded-lg p-2 text-[11px] font-mono text-gray-300 break-all select-all">
                        {loadstring}
                      </div>

                      <div className="text-[11px] text-gray-500 flex items-center justify-between">
                        <span>{s.updatedAt || s.createdAt}</span>
                        <span>{s.ownerUsername}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                      <button
                        onClick={() => copyToClipboard(loadstring, 'Loadstring')}
                        className="flex-1 bg-[#00ffcc]/15 hover:bg-[#00ffcc]/25 text-[#00ffcc] text-xs font-semibold py-1.5 px-3 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <i className="fa-solid fa-copy"></i>
                        <span>{lang === 'vi' ? 'Copy Loadstring' : 'Copy'}</span>
                      </button>

                      <button
                        onClick={() => openEditModal(s)}
                        className="p-1.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-all"
                        title={lang === 'vi' ? 'Sửa script' : 'Edit script'}
                      >
                        <i className="fa-solid fa-pen-to-square"></i>
                      </button>

                      <button
                        onClick={() => handleDeleteScript(s.id)}
                        className="p-1.5 text-gray-400 hover:text-[#ff2a6d] hover:bg-[#ff2a6d]/10 rounded-lg transition-all"
                        title={lang === 'vi' ? 'Xóa script' : 'Delete script'}
                      >
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* EDIT MODAL */}
      {editingScript && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div
            style={{
              background: '#0a0a14',
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: '20px',
              maxWidth: '640px',
              width: '100%',
              padding: '24px',
            }}
            className="space-y-4 shadow-[0_0_50px_rgba(0,255,204,0.15)]"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <i className="fa-solid fa-pen-to-square text-[#00ffcc]"></i>
                <span>{lang === 'vi' ? `Chỉnh Sửa Script: ${editingScript.name}` : `Edit Script: ${editingScript.name}`}</span>
              </h3>
              <button
                onClick={() => setEditingScript(null)}
                className="text-gray-400 hover:text-white"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <div>
              <label className="block text-[13px] font-semibold text-gray-300 mb-1.5">
                {lang === 'vi' ? 'Tên Script' : 'Script Name'}
              </label>
              <input
                type="text"
                value={editScriptName}
                onChange={(e) => setEditScriptName(e.target.value)}
                className="w-full bg-[#050508] border border-white/15 rounded-xl px-3.5 py-2 text-[13px] text-white focus:outline-none focus:border-[#00ffcc] font-mono"
              />
            </div>

            <div>
              <label className="block text-[13px] font-semibold text-gray-300 mb-1.5">
                {lang === 'vi' ? 'Mã Nguồn Raw Lua' : 'Raw Lua Code'}
              </label>
              <textarea
                rows={10}
                value={editSourceCode}
                onChange={(e) => setEditSourceCode(e.target.value)}
                className="w-full bg-[#050508] border border-white/15 rounded-xl p-3.5 text-[12.5px] text-gray-200 font-mono focus:outline-none focus:border-[#00ffcc] leading-relaxed resize-y"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setEditingScript(null)}
                className="px-4 py-2 text-sm text-gray-400 hover:text-white"
              >
                {lang === 'vi' ? 'Hủy' : 'Cancel'}
              </button>
              <button
                onClick={handleSaveEditedScript}
                disabled={isSavingEdit}
                className="bg-[#00ffcc] hover:bg-[#00e6b8] text-black font-bold text-sm px-5 py-2.5 rounded-xl transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSavingEdit ? (
                  <i className="fa-solid fa-spinner fa-spin"></i>
                ) : (
                  <i className="fa-solid fa-floppy-disk"></i>
                )}
                <span>{lang === 'vi' ? 'Lưu Thay Đổi' : 'Save Changes'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
