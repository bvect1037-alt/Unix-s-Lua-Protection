import React, { useState } from 'react';
import { buildAdvancedProtectedLua } from '../services/luaProtection';

interface ObfuscatorSectionProps {
  lang: 'vi' | 'en';
  onShowToast: (msg: string, isError?: boolean) => void;
}

export const ObfuscatorSection: React.FC<ObfuscatorSectionProps> = ({ lang, onShowToast }) => {
  const [inputCode, setInputCode] = useState('');
  const [outputCode, setOutputCode] = useState('');
  const [optXor, setOptXor] = useState(true);
  const [optVm, setOptVm] = useState(true);

  const handleObfuscate = () => {
    if (!inputCode.trim()) {
      onShowToast(lang === 'vi' ? 'Vui lòng nhập mã nguồn Lua!' : 'Please enter Lua source code!', true);
      return;
    }

    try {
      const obfuscated = buildAdvancedProtectedLua(inputCode, {
        scriptName: 'ObfuscatedScript',
        baseUrl: window.location.origin,
        vmSandbox: optVm,
        antiHook: optXor,
      });

      setOutputCode(obfuscated);
      onShowToast(lang === 'vi' ? 'Mã hóa thành công!' : 'Obfuscated successfully!');
    } catch {
      onShowToast(lang === 'vi' ? 'Lỗi trong quá trình mã hóa!' : 'Error during obfuscation!', true);
    }
  };

  const handleCopy = () => {
    if (!outputCode) {
      onShowToast(lang === 'vi' ? 'Không có mã để copy!' : 'No code to copy!', true);
      return;
    }
    navigator.clipboard.writeText(outputCode).then(() => {
      onShowToast(lang === 'vi' ? 'Đã copy mã thành công!' : 'Code copied to clipboard!');
    });
  };

  const handleDownload = () => {
    if (!outputCode) {
      onShowToast(lang === 'vi' ? 'Không có mã để tải!' : 'No code to download!', true);
      return;
    }
    const blob = new Blob([outputCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'UnixFun_MaximumProtected.lua';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(lang === 'vi' ? 'Đã tải file .lua thành công!' : 'Downloaded .lua file successfully!');
  };

  return (
    <section>
      <div
        style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--border-color)',
          borderRadius: '16px',
          padding: '24px',
          marginBottom: '24px',
        }}
      >
        <h2 style={{ fontSize: '20px', margin: '4px 0 8px 0', color: 'var(--primary-pink)', fontWeight: 700 }}>
          <i className="fa-solid fa-shield-halved"></i> Unix.fun Maximum Lua Obfuscator
        </h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '13.5px', lineHeight: 1.5, margin: 0 }}>
          {lang === 'vi'
            ? 'Cơ chế mã hóa chuyên sâu với bảng mảng Byte XOR, xáo trộn biến ngầm và bọc máy ảo bảo mật giúp che giấu 100% mã nguồn gốc.'
            : 'Advanced encryption with XOR byte arrays, variable mangling, and VM sandboxing to completely hide your source code.'}
        </p>
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '18px',
        }}
      >
        {/* Box 1: Input */}
        <div
          style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: '16px',
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
          }}
        >
          <h3 style={{ color: '#fff', fontSize: '15px', fontWeight: 700, margin: 0 }}>
            <i className="fa-solid fa-code"></i> {lang === 'vi' ? 'Mã nguồn Lua gốc (Input)' : 'Original Lua Code (Input)'}
          </h3>

          <textarea
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value)}
            placeholder={
              lang === 'vi'
                ? "-- Nhập mã Lua của bạn tại đây\nprint('Protected by Unix.fun')"
                : "-- Enter your Lua code here\nprint('Protected by Unix.fun')"
            }
            style={{
              width: '100%',
              height: '260px',
              background: 'rgba(8, 8, 15, 0.95)',
              border: '1px solid var(--border-color)',
              borderRadius: '10px',
              padding: '14px',
              color: '#00ffcc',
              fontFamily: 'monospace',
              fontSize: '12.5px',
              resize: 'vertical',
              outline: 'none',
              lineHeight: 1.4,
            }}
          />

          <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', fontSize: '12.5px', color: 'var(--text-muted)' }}>
            <label style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={optXor}
                onChange={(e) => setOptXor(e.target.checked)}
                style={{ accentColor: 'var(--primary-pink)' }}
              />
              <span>{lang === 'vi' ? 'Mã hóa Byte XOR (Bytecode Armor)' : 'Bytecode XOR Armor'}</span>
            </label>
            <label style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={optVm}
                onChange={(e) => setOptVm(e.target.checked)}
                style={{ accentColor: 'var(--primary-pink)' }}
              />
              <span>{lang === 'vi' ? 'Bọc môi trường ảo hóa (VM Sandbox)' : 'VM Sandbox Wrapper'}</span>
            </label>
          </div>

          <button
            onClick={handleObfuscate}
            style={{
              background: 'rgba(255, 42, 109, 0.25)',
              color: '#fff',
              fontWeight: 600,
              padding: '10px 18px',
              borderRadius: '10px',
              border: '1px solid var(--primary-pink)',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              fontSize: '13.5px',
              boxShadow: '0 0 15px var(--wibu-glow)',
              marginTop: '4px',
            }}
          >
            <i className="fa-solid fa-lock"></i>
            <span>{lang === 'vi' ? 'Mã hóa bảo mật cao (Obfuscate)' : 'Obfuscate Securely'}</span>
          </button>
        </div>

        {/* Box 2: Output */}
        <div
          style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: '16px',
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
          }}
        >
          <h3 style={{ color: '#fff', fontSize: '15px', fontWeight: 700, margin: 0 }}>
            <i className="fa-solid fa-file-shield"></i> {lang === 'vi' ? 'Mã nguồn đã mã hóa (Output)' : 'Obfuscated Code (Output)'}
          </h3>

          <textarea
            value={outputCode}
            readOnly
            placeholder={
              lang === 'vi'
                ? '-- Kết quả mã hóa bảo mật sẽ hiển thị ở đây...'
                : '-- Encrypted code will appear here...'
            }
            style={{
              width: '100%',
              height: '260px',
              background: 'rgba(8, 8, 15, 0.95)',
              border: '1px solid var(--border-color)',
              borderRadius: '10px',
              padding: '14px',
              color: '#00ffcc',
              fontFamily: 'monospace',
              fontSize: '12.5px',
              resize: 'vertical',
              outline: 'none',
              lineHeight: 1.4,
            }}
          />

          <div style={{ display: 'flex', gap: '10px', marginTop: '4px' }}>
            <button
              onClick={handleCopy}
              style={{
                flex: 1,
                background: 'rgba(255, 255, 255, 0.05)',
                color: '#fff',
                fontWeight: 600,
                padding: '10px 18px',
                borderRadius: '10px',
                border: '1px solid var(--border-color)',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                fontSize: '13.5px',
              }}
              className="hover:bg-[rgba(255,255,255,0.1)] hover:border-[#ff2a6d]"
            >
              <i className="fa-solid fa-copy"></i>
              <span>{lang === 'vi' ? 'Copy mã' : 'Copy Code'}</span>
            </button>
            <button
              onClick={handleDownload}
              style={{
                flex: 1,
                background: 'rgba(255, 42, 109, 0.25)',
                color: '#fff',
                fontWeight: 600,
                padding: '10px 18px',
                borderRadius: '10px',
                border: '1px solid rgba(255, 42, 109, 0.4)',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                fontSize: '13.5px',
              }}
              className="hover:bg-[rgba(255,42,109,0.4)]"
            >
              <i className="fa-solid fa-download"></i>
              <span>{lang === 'vi' ? 'Tải file .lua' : 'Download .lua'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
