import React, { useState, useEffect } from 'react';
import { NotificationItem, UserAccount } from '../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount | null;
  onShowToast: (msg: string, isError?: boolean) => void;
  lang: 'vi' | 'en';
  onRefreshUnreadCount: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onShowToast,
  lang,
  onRefreshUnreadCount,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Admin Broadcast Ping Form State
  const [isPingFormOpen, setIsPingFormOpen] = useState(false);
  const [pingTitle, setPingTitle] = useState('');
  const [pingMessage, setPingMessage] = useState('');
  const [isBroadcasting, setIsBroadcasting] = useState(false);

  const isAdmin =
    currentUser?.role === 'admin' ||
    currentUser?.username?.toLowerCase() === 'admin' ||
    currentUser?.username?.toLowerCase() === 'unixadmin';

  useEffect(() => {
    if (isOpen) {
      fetchNotifications();
    }
  }, [isOpen, currentUser]);

  const fetchNotifications = async () => {
    setIsLoading(true);
    try {
      const username = currentUser?.username || '';
      const res = await fetch(`/api/notifications?username=${encodeURIComponent(username)}`);
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch {
      // fallback
    }
    setIsLoading(false);
  };

  const handleMarkAllAsRead = async () => {
    try {
      await fetch('/api/notifications/read-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: currentUser?.username || '' }),
      });
      setNotifications(notifications.map((n) => ({ ...n, isRead: true })));
      onRefreshUnreadCount();
      onShowToast(lang === 'vi' ? 'Đã đánh dấu đã đọc tất cả thông báo!' : 'Marked all as read!');
    } catch {
      // ignore
    }
  };

  const handleBroadcastGlobalPing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      onShowToast(lang === 'vi' ? 'Chỉ có Admin mới có quyền Ping @everyone!' : 'Admin privilege required!', true);
      return;
    }
    if (!pingTitle.trim() || !pingMessage.trim()) {
      onShowToast(lang === 'vi' ? 'Vui lòng điền đủ tiêu đề và nội dung ping!' : 'Fill all fields!', true);
      return;
    }

    setIsBroadcasting(true);
    try {
      const res = await fetch('/api/notifications/ping-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderName: currentUser?.username || 'UnixAdmin',
          title: pingTitle.trim(),
          message: pingMessage.trim(),
        }),
      });

      if (res.ok) {
        setPingTitle('');
        setPingMessage('');
        setIsPingFormOpen(false);
        fetchNotifications();
        onRefreshUnreadCount();
        onShowToast(lang === 'vi' ? '👑 Đã gửi Ping @everyone thành công tới toàn bộ người dùng!' : '👑 Global Ping sent to everyone!');
      } else {
        const err = await res.json();
        onShowToast(err.error || 'Failed to ping', true);
      }
    } catch {
      onShowToast('Lỗi gửi ping', true);
    }
    setIsBroadcasting(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-[#0e0e18] border border-white/15 rounded-3xl p-6 shadow-[0_0_50px_rgba(255,42,109,0.25)] text-white space-y-5 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#ff2a6d]/20 border border-[#ff2a6d]/40 flex items-center justify-center text-[#ff2a6d]">
              <i className="fa-solid fa-bell"></i>
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {lang === 'vi' ? 'Thông Báo & Tin Nhắn Ping' : 'Notifications & Pings'}
              </h3>
              <p className="text-xs text-gray-400">
                {lang === 'vi' ? 'Cập nhật từ hệ thống & quản trị viên' : 'System updates & admin broadcasts'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllAsRead}
              className="text-xs text-[#00ffcc] hover:underline cursor-pointer"
            >
              {lang === 'vi' ? 'Đọc tất cả' : 'Read all'}
            </button>
            <button
              onClick={onClose}
              className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-all cursor-pointer"
            >
              <i className="fa-solid fa-xmark text-xs"></i>
            </button>
          </div>
        </div>

        {/* Admin Super Power: Global Ping Button & Form */}
        {isAdmin && (
          <div className="shrink-0 bg-gradient-to-r from-[#181122] to-[#251222] border border-[#ff2a6d]/40 rounded-2xl p-3.5 space-y-3 shadow-[0_0_15px_rgba(255,42,109,0.2)]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
                  <i className="fa-solid fa-crown text-[10px]"></i>
                  {lang === 'vi' ? 'Quyền Admin: Ping @everyone toàn bộ thành viên' : 'Admin: Global Ping Broadcast'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsPingFormOpen(!isPingFormOpen)}
                className="px-2.5 py-1 rounded-lg bg-[#ff2a6d] hover:brightness-110 text-white text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1"
              >
                <i className="fa-solid fa-bullhorn text-[10px]"></i>
                <span>{isPingFormOpen ? (lang === 'vi' ? 'Thu gọn' : 'Collapse') : (lang === 'vi' ? 'Gửi Ping Mới' : 'New Ping')}</span>
              </button>
            </div>

            {isPingFormOpen && (
              <form onSubmit={handleBroadcastGlobalPing} className="space-y-2.5 pt-1">
                <input
                  type="text"
                  value={pingTitle}
                  onChange={(e) => setPingTitle(e.target.value)}
                  placeholder={lang === 'vi' ? 'Tiêu đề thông báo (VD: 📢 Bảo trì máy chủ / Cập nhật script mới)' : 'Notification title...'}
                  required
                  className="w-full bg-[#07070d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder:text-gray-600 focus:outline-none focus:border-[#ff2a6d]"
                />
                <textarea
                  value={pingMessage}
                  onChange={(e) => setPingMessage(e.target.value)}
                  rows={2}
                  placeholder={lang === 'vi' ? 'Nội dung chi tiết sẽ hiển thị số thông báo đỏ trên logo của tất cả mọi người...' : 'Detailed message that alerts all users...'}
                  required
                  className="w-full bg-[#07070d] border border-white/10 rounded-xl p-3 text-xs text-white placeholder:text-gray-600 focus:outline-none focus:border-[#ff2a6d] resize-none"
                />
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isBroadcasting}
                    className="px-4 py-2 bg-gradient-to-r from-[#ff2a6d] to-[#ff5e87] hover:brightness-110 text-white rounded-xl text-xs font-bold shadow-[0_0_12px_rgba(255,42,109,0.4)] flex items-center gap-1.5 cursor-pointer"
                  >
                    <i className="fa-solid fa-paper-plane text-[10px]"></i>
                    <span>{isBroadcasting ? (lang === 'vi' ? 'Đang phát sóng...' : 'Broadcasting...') : (lang === 'vi' ? 'Phát Sóng Ping Cho Tất Cả' : 'Send Global Ping')}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* Notifications Scrollable List */}
        <div className="flex-grow overflow-y-auto space-y-2.5 pr-1">
          {isLoading ? (
            <div className="py-12 text-center text-gray-400">
              <i className="fa-solid fa-circle-notch fa-spin text-2xl text-[#ff2a6d] mb-2"></i>
              <p className="text-xs">{lang === 'vi' ? 'Đang tải thông báo...' : 'Loading...'}</p>
            </div>
          ) : notifications.length === 0 ? (
            <div className="py-12 text-center text-gray-500 space-y-2">
              <i className="fa-solid fa-bell-slash text-3xl text-gray-600"></i>
              <p className="text-xs font-semibold">
                {lang === 'vi' ? 'Bạn không có thông báo mới nào.' : 'No notifications.'}
              </p>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border transition-all space-y-1.5 ${
                  !item.isRead
                    ? 'bg-[#181224] border-[#ff2a6d]/40 shadow-[0_0_12px_rgba(255,42,109,0.15)]'
                    : 'bg-[#07070d] border-white/5'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    {item.type === 'global' ? (
                      <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] shrink-0 border border-amber-500/30">
                        <i className="fa-solid fa-bullhorn"></i>
                      </span>
                    ) : item.type === 'like' ? (
                      <span className="w-6 h-6 rounded-lg bg-[#ff2a6d]/20 text-[#ff2a6d] flex items-center justify-center text-[10px] shrink-0 border border-[#ff2a6d]/30">
                        <i className="fa-solid fa-heart"></i>
                      </span>
                    ) : item.type === 'follow' ? (
                      <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-[10px] shrink-0 border border-emerald-500/30">
                        <i className="fa-solid fa-user-plus"></i>
                      </span>
                    ) : (
                      <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center text-[10px] shrink-0 border border-blue-500/30">
                        <i className="fa-solid fa-comment"></i>
                      </span>
                    )}

                    <strong className="text-xs font-bold text-white truncate">{item.title}</strong>
                  </div>

                  <span className="text-[10.5px] text-gray-500 shrink-0">{item.time}</span>
                </div>

                <p className="text-xs text-gray-300 leading-relaxed pl-8">{item.message}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
