import React, { useState, useEffect } from 'react';
import { UserAccount, RegisteredUser } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserAccount) => void;
  onShowToast: (msg: string, isError?: boolean) => void;
  lang: 'vi' | 'en';
}

const DEFAULT_USERS: RegisteredUser[] = [
  {
    id: 'usr_admin',
    username: 'admin',
    displayName: 'Unix Super Admin 👑',
    email: 'admin@unix.fun',
    password: 'admin',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=UnixSuperAdmin',
    role: 'admin',
    provider: 'local',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'usr_scripter',
    username: 'RobloxScripter99',
    displayName: 'Roblox Scripter 99',
    email: 'scripter99@gmail.com',
    password: 'user123',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=RobloxScripter99',
    role: 'user',
    provider: 'local',
    createdAt: new Date().toISOString(),
  },
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  onShowToast,
  lang,
}) => {
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [isGoogleSelectorOpen, setIsGoogleSelectorOpen] = useState(false);
  const [customGoogleEmail, setCustomGoogleEmail] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [saveCredentials, setSaveCredentials] = useState(true);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsGoogleSelectorOpen(false);
      const savedUsers = localStorage.getItem('unix_registered_accounts');
      if (!savedUsers) {
        localStorage.setItem('unix_registered_accounts', JSON.stringify(DEFAULT_USERS));
      }

      const savedCreds = localStorage.getItem('nnvn_saved_credentials');
      if (savedCreds) {
        try {
          const parsed = JSON.parse(savedCreds);
          if (parsed.user) setUsername(parsed.user);
          if (parsed.pass) setPassword(parsed.pass);
        } catch {
          // ignore
        }
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleLocalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUsername = username.trim();
    const cleanEmail = email.trim();

    if (!cleanUsername || !password.trim()) {
      onShowToast(
        lang === 'vi'
          ? 'Vui lòng điền đầy đủ tài khoản và mật khẩu!'
          : 'Please fill in both username and password!',
        true
      );
      return;
    }

    setLoading(true);

    try {
      if (isRegisterMode) {
        if (cleanUsername.length < 3) {
          onShowToast(
            lang === 'vi'
              ? 'Tên tài khoản phải có ít nhất 3 ký tự!'
              : 'Username must be at least 3 characters!',
            true
          );
          setLoading(false);
          return;
        }

        if (password.length < 4) {
          onShowToast(
            lang === 'vi'
              ? 'Mật khẩu phải có ít nhất 4 ký tự!'
              : 'Password must be at least 4 characters!',
            true
          );
          setLoading(false);
          return;
        }

        if (password !== confirmPassword) {
          onShowToast(
            lang === 'vi'
              ? 'Mật khẩu xác nhận không khớp!'
              : 'Password confirmation does not match!',
            true
          );
          setLoading(false);
          return;
        }

        const res = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: cleanUsername,
            displayName: displayName.trim() || cleanUsername,
            email: cleanEmail || `${cleanUsername.toLowerCase()}@unix.fun`,
            password,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          onShowToast(data.error || 'Lỗi khi đăng ký!', true);
          setLoading(false);
          return;
        }

        const account: UserAccount = data.user;
        localStorage.setItem('nnvn_user_account', JSON.stringify(account));
        if (saveCredentials) {
          localStorage.setItem(
            'nnvn_saved_credentials',
            JSON.stringify({ user: cleanUsername, pass: password })
          );
        }

        onSuccess(account);
        onClose();
        onShowToast(
          lang === 'vi'
            ? `Đăng ký thành công! Chào mừng ${cleanUsername}`
            : `Registration successful! Welcome ${cleanUsername}`
        );
      } else {
        // Login mode
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: cleanUsername, password }),
        });

        const data = await res.json();
        if (!res.ok) {
          onShowToast(data.error || 'Đăng nhập thất bại!', true);
          setLoading(false);
          return;
        }

        if (data.user) {
          localStorage.setItem('nnvn_user_account', JSON.stringify(data.user));
          if (saveCredentials) {
            localStorage.setItem(
              'nnvn_saved_credentials',
              JSON.stringify({ user: cleanUsername, pass: password })
            );
          }
          onSuccess(data.user);
          onClose();
          onShowToast(
            lang === 'vi'
              ? `Chào mừng ${data.user.role === 'admin' ? '👑 Admin' : ''} ${data.user.displayName || data.user.username}!`
              : `Welcome back, ${data.user.displayName || data.user.username}!`
          );
          setLoading(false);
          return;
        }
      }
    } catch (err) {
      console.error(err);
      onShowToast('Có lỗi xảy ra, vui lòng thử lại!', true);
    } finally {
      setLoading(false);
    }
  };

  const handleExecuteGoogleLogin = async (selectedEmail: string, googleDisplayName?: string) => {
    setLoading(true);
    try {
      const googleEmail = selectedEmail.trim().toLowerCase();
      const googleUsername = googleDisplayName || googleEmail.split('@')[0];
      const googleAvatar = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(googleUsername)}`;

      const googleUser: UserAccount = {
        id: `g_${Date.now()}`,
        username: googleUsername,
        displayName: googleUsername,
        email: googleEmail,
        avatar: googleAvatar,
        role: 'user',
        provider: 'google',
        createdAt: new Date().toISOString(),
      };

      localStorage.setItem('nnvn_user_account', JSON.stringify(googleUser));
      onSuccess(googleUser);
      onClose();
      onShowToast(
        lang === 'vi'
          ? `Đã đăng nhập thành công với Google (${googleEmail})!`
          : `Signed in with Google (${googleEmail})!`
      );
    } catch {
      onShowToast('Đăng nhập Google thất bại!', true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        background: 'rgba(0, 0, 0, 0.85)',
        zIndex: 9999,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '20px',
        backdropFilter: 'blur(8px)',
      }}
      onClick={onClose}
    >
      <div
        style={{
          background: 'rgba(14, 14, 24, 0.98)',
          border: '1px solid var(--border-color)',
          borderRadius: '20px',
          padding: '28px',
          width: '100%',
          maxWidth: '440px',
          boxShadow: '0 20px 50px rgba(0, 0, 0, 0.7)',
          position: 'relative',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
          <h2 style={{ color: 'var(--primary-pink)', fontSize: '18px', fontWeight: 700, margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <i className={`fa-solid ${isGoogleSelectorOpen ? 'fa-brands fa-google' : isRegisterMode ? 'fa-user-plus' : 'fa-user-lock'}`}></i>
            <span>
              {isGoogleSelectorOpen
                ? lang === 'vi'
                  ? 'Đăng nhập với Google'
                  : 'Sign in with Google'
                : isRegisterMode
                ? lang === 'vi'
                  ? 'Đăng ký tài khoản Unix'
                  : 'Register Unix Account'
                : lang === 'vi'
                ? 'Đăng nhập hệ thống'
                : 'System Sign In'}
            </span>
          </h2>
          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--text-muted)',
              fontSize: '18px',
              cursor: 'pointer',
            }}
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        {/* GOOGLE AUTH ACCOUNT PICKER CARD */}
        {isGoogleSelectorOpen ? (
          <div className="space-y-4">
            <p className="text-[13px] text-gray-400 leading-relaxed">
              {lang === 'vi'
                ? 'Chọn tài khoản Google của bạn để đăng nhập nhanh chóng và đồng bộ script:'
                : 'Select your Google Account to sign in quickly and sync scripts:'}
            </p>

            <button
              type="button"
              onClick={() => handleExecuteGoogleLogin('bvect1037@gmail.com', 'bvect1037')}
              disabled={loading}
              className="w-full bg-[#161724] hover:bg-[#1e2030] border border-white/15 hover:border-[#ff2a6d]/60 rounded-xl p-3.5 flex items-center justify-between text-left transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#4285F4] to-[#34A853] p-0.5 flex items-center justify-center shrink-0">
                  <div className="w-full h-full rounded-full bg-[#12121e] flex items-center justify-center font-bold text-white text-sm">
                    B
                  </div>
                </div>
                <div>
                  <div className="text-[13.5px] font-bold text-white group-hover:text-[#ff2a6d] transition-colors flex items-center gap-1.5">
                    <span>bvect1037</span>
                    <span className="text-[10px] px-1.5 py-0.5 bg-[#4285F4]/20 text-[#4285F4] rounded font-semibold">
                      Google
                    </span>
                  </div>
                  <div className="text-[12px] text-gray-400 font-mono">bvect1037@gmail.com</div>
                </div>
              </div>
              <i className="fa-solid fa-arrow-right text-gray-500 group-hover:text-white transition-colors"></i>
            </button>

            <div className="pt-2 border-t border-white/10 space-y-2">
              <label className="text-[12px] text-gray-400 block">
                {lang === 'vi' ? 'Hoặc đăng nhập tài khoản Google khác:' : 'Or use another Google email:'}
              </label>
              <div className="flex gap-2">
                <input
                  type="email"
                  value={customGoogleEmail}
                  onChange={(e) => setCustomGoogleEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="flex-1 bg-[#07070d] border border-white/10 rounded-xl px-3 py-2 text-[13px] text-white focus:outline-none focus:border-[#4285F4]"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (customGoogleEmail.trim()) {
                      handleExecuteGoogleLogin(customGoogleEmail.trim());
                    } else {
                      onShowToast(lang === 'vi' ? 'Vui lòng nhập email Google!' : 'Please enter Google email!', true);
                    }
                  }}
                  disabled={loading}
                  className="px-4 py-2 bg-[#4285F4] hover:bg-[#3367d6] text-white font-semibold text-[13px] rounded-xl cursor-pointer shrink-0"
                >
                  {loading ? <i className="fa-solid fa-spinner fa-spin"></i> : lang === 'vi' ? 'Đăng nhập' : 'Sign In'}
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsGoogleSelectorOpen(false)}
              className="w-full py-2.5 text-[12.5px] text-gray-400 hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <i className="fa-solid fa-arrow-left"></i>
              <span>{lang === 'vi' ? 'Quay lại đăng nhập thông thường' : 'Back to standard login'}</span>
            </button>
          </div>
        ) : (
          <>
            {/* Google Sign-In Trigger Button */}
            <button
              type="button"
              onClick={() => setIsGoogleSelectorOpen(true)}
              disabled={loading}
              style={{
                width: '100%',
                background: '#ffffff',
                color: '#1f2937',
                border: '1px solid #e5e7eb',
                borderRadius: '10px',
                padding: '11px 16px',
                fontSize: '13.5px',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px',
                marginBottom: '16px',
                transition: 'all 0.2s ease',
                boxShadow: '0 2px 6px rgba(0,0,0,0.2)',
              }}
              className="hover:bg-[#f3f4f6]"
            >
              <svg style={{ width: '18px', height: '18px' }} viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.14z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.26 21.36 7.33 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.94 0 12s.46 3.84 1.26 5.42l4.02-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
              <span>{lang === 'vi' ? 'Tiếp tục với Google' : 'Continue with Google'}</span>
            </button>

            {/* Divider */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                textAlign: 'center',
                margin: '14px 0',
                color: 'var(--text-muted)',
                fontSize: '11.5px',
              }}
            >
              <div style={{ flexGrow: 1, height: '1px', background: 'rgba(255, 255, 255, 0.08)' }} />
              <span style={{ padding: '0 10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                {lang === 'vi' ? 'hoặc tài khoản mật khẩu' : 'or username password'}
              </span>
              <div style={{ flexGrow: 1, height: '1px', background: 'rgba(255, 255, 255, 0.08)' }} />
            </div>

            <form onSubmit={handleLocalSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div>
                <label style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                  {lang === 'vi' ? 'Tên đăng nhập (Username):' : 'Username:'}
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={lang === 'vi' ? 'Nhập tên tài khoản duy nhất...' : 'Enter unique username...'}
                  required
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    background: 'rgba(255, 255, 255, 0.03)',
                    border: '1px solid var(--border-color)',
                    borderRadius: '10px',
                    color: '#fff',
                    outline: 'none',
                    fontSize: '13px',
                  }}
                />
              </div>

              {isRegisterMode && (
                <>
                  <div>
                    <label style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      {lang === 'vi' ? 'Tên hiển thị (Display Name):' : 'Display Name:'}
                    </label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder={lang === 'vi' ? 'VD: Pro Scripter ⚡' : 'Display name...'}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        background: 'rgba(255, 255, 255, 0.03)',
                        border: '1px solid var(--border-color)',
                        borderRadius: '10px',
                        color: '#fff',
                        outline: 'none',
                        fontSize: '13px',
                      }}
                    />
                  </div>

                  <div>
                    <label style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      {lang === 'vi' ? 'Địa chỉ Email:' : 'Email Address:'}
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        background: 'rgba(255, 255, 255, 0.03)',
                        border: '1px solid var(--border-color)',
                        borderRadius: '10px',
                        color: '#fff',
                        outline: 'none',
                        fontSize: '13px',
                      }}
                    />
                  </div>
                </>
              )}

              <div>
                <label style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                  {lang === 'vi' ? 'Mật khẩu:' : 'Password:'}
                </label>
                <div style={{ position: 'relative' }}>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    style={{
                      width: '100%',
                      padding: '10px 38px 10px 12px',
                      background: 'rgba(255, 255, 255, 0.03)',
                      border: '1px solid var(--border-color)',
                      borderRadius: '10px',
                      color: '#fff',
                      outline: 'none',
                      fontSize: '13px',
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      position: 'absolute',
                      right: '10px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      background: 'transparent',
                      border: 'none',
                      color: 'var(--text-muted)',
                      cursor: 'pointer',
                      fontSize: '13px',
                    }}
                  >
                    <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                  </button>
                </div>
              </div>

              {isRegisterMode && (
                <div>
                  <label style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                    {lang === 'vi' ? 'Xác nhận mật khẩu:' : 'Confirm Password:'}
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      background: 'rgba(255, 255, 255, 0.03)',
                      border: '1px solid var(--border-color)',
                      borderRadius: '10px',
                      color: '#fff',
                      outline: 'none',
                      fontSize: '13px',
                    }}
                  />
                </div>
              )}

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '12px', marginTop: '2px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={saveCredentials}
                    onChange={(e) => setSaveCredentials(e.target.checked)}
                    style={{ accentColor: 'var(--primary-pink)' }}
                  />
                  <span>{lang === 'vi' ? 'Ghi nhớ đăng nhập' : 'Remember me'}</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                style={{
                  marginTop: '8px',
                  background: 'linear-gradient(90deg, var(--primary-pink), var(--secondary-pink))',
                  border: 'none',
                  color: '#fff',
                  fontWeight: 700,
                  fontSize: '14px',
                  padding: '12px',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  boxShadow: '0 0 15px var(--wibu-glow)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                }}
              >
                {loading ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i>
                    <span>{lang === 'vi' ? 'Đang xử lý...' : 'Processing...'}</span>
                  </>
                ) : (
                  <>
                    <i className={`fa-solid ${isRegisterMode ? 'fa-user-check' : 'fa-right-to-bracket'}`}></i>
                    <span>
                      {isRegisterMode
                        ? lang === 'vi'
                          ? 'Tạo tài khoản mới'
                          : 'Create Account'
                        : lang === 'vi'
                        ? 'Đăng nhập ngay'
                        : 'Sign In Now'}
                    </span>
                  </>
                )}
              </button>
            </form>

            <div style={{ textAlign: 'center', marginTop: '16px', fontSize: '12.5px', color: 'var(--text-muted)' }}>
              {isRegisterMode ? (
                <span>
                  {lang === 'vi' ? 'Đã có tài khoản? ' : 'Already have an account? '}
                  <button
                    type="button"
                    onClick={() => setIsRegisterMode(false)}
                    style={{ background: 'transparent', border: 'none', color: 'var(--primary-pink)', fontWeight: 600, cursor: 'pointer' }}
                  >
                    {lang === 'vi' ? 'Đăng nhập tại đây' : 'Sign in here'}
                  </button>
                </span>
              ) : (
                <span>
                  {lang === 'vi' ? 'Chưa có tài khoản? ' : "Don't have an account? "}
                  <button
                    type="button"
                    onClick={() => setIsRegisterMode(true)}
                    style={{ background: 'transparent', border: 'none', color: 'var(--primary-pink)', fontWeight: 600, cursor: 'pointer' }}
                  >
                    {lang === 'vi' ? 'Đăng ký miễn phí' : 'Register for free'}
                  </button>
                </span>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
