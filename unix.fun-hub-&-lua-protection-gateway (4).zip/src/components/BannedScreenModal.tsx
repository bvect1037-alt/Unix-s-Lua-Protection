import React from 'react';

interface BannedScreenModalProps {
  isOpen: boolean;
  banType?: 'ip' | 'account';
  banReason?: string;
  lang: 'vi' | 'en';
  onClose: () => void;
}

export const BannedScreenModal: React.FC<BannedScreenModalProps> = ({
  isOpen,
  banType = 'account',
  banReason,
  lang,
  onClose,
}) => {
  if (!isOpen) return null;

  const isIpBan = banType === 'ip';

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-md bg-[#13080e] border-2 border-red-500/80 rounded-3xl p-7 text-center shadow-[0_0_60px_rgba(239,68,68,0.5)] text-white space-y-5">
        <div className="w-16 h-16 rounded-2xl bg-red-500/20 border border-red-500/50 flex items-center justify-center mx-auto text-red-500 text-3xl shadow-[0_0_20px_rgba(239,68,68,0.4)]">
          <i className="fa-solid fa-shield-slash"></i>
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl font-black text-red-500 tracking-wide uppercase">
            {isIpBan
              ? (lang === 'vi' ? 'ĐỊA CHỈ IP BỊ KHÓA' : 'IP ADDRESS BANNED')
              : (lang === 'vi' ? 'TÀI KHOẢN BỊ KHÓA VĨNH VIỄN' : 'ACCOUNT PERMANENTLY BANNED')}
          </h2>
          <div className="inline-block px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 font-mono text-xs font-bold">
            {isIpBan ? 'MODERATION RULE: NO 18+ / NSFW' : 'MODERATION RULE: NO BLOOD / GORE'}
          </div>
        </div>

        <div className="bg-black/60 border border-red-500/20 rounded-2xl p-4 text-left space-y-2 text-xs">
          <span className="font-bold text-gray-400 block uppercase">
            {lang === 'vi' ? 'Lý do xử phạt vi phạm:' : 'Ban Reason:'}
          </span>
          <p className="text-red-300 font-semibold leading-relaxed">
            {banReason ||
              (isIpBan
                ? (lang === 'vi' ? 'Phát hiện đăng tải bài viết/hình ảnh chứa nội dung 18+, khiêu dâm hoặc từ khóa đồi trụy. Toàn bộ IP đã bị cấm truy cập.' : '18+/NSFW/Sexual content violation. IP blocked.')
                : (lang === 'vi' ? 'Phát hiện bài viết chứa nội dung máu me, bạo lực hoặc kinh dị. Tài khoản đã bị khóa vĩnh viễn.' : 'Blood/Gore/Violence violation. Account banned.'))}
          </p>
        </div>

        <p className="text-[12px] text-gray-400 leading-relaxed">
          {lang === 'vi'
            ? 'Hệ thống tự động kiểm duyệt Unix Moderation Bot đã kích hoạt biện pháp ngăn chặn. Nếu bạn cho rằng đây là nhầm lẫn, vui lòng liên hệ Admin Unix.'
            : 'Automated moderation bot triggered. Contact Unix Admin if you believe this was an error.'}
        </p>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-[0_0_15px_rgba(239,68,68,0.4)] cursor-pointer transition-all"
        >
          {lang === 'vi' ? 'Tôi đã hiểu & Đóng' : 'I Understand & Close'}
        </button>
      </div>
    </div>
  );
};
