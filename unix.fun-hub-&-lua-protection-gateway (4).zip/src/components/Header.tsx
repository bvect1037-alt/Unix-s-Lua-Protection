import React from 'react';
import { UserAccount } from '../types';

interface HeaderProps {
  currentTab: string;
  lang: 'vi' | 'en';
  onSetLang: (lang: 'vi' | 'en') => void;
  currentUser: UserAccount | null;
  onOpenNotifications: () => void;
  onOpenProfile: (username: string) => void;
  unreadCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  lang,
  onSetLang,
  currentUser,
  onOpenNotifications,
  onOpenProfile,
  unreadCount,
}) => {
  const titles: Record<string, { vi: { title: string; subtitle: string }; en: { title: string; subtitle: string } }> = {
    download: {
      vi: { title: 'Tải xuống Công cụ Unix.fun', subtitle: 'Downloads & Resources' },
      en: { title: 'Unix.fun Tools Download', subtitle: 'Downloads & Resources' },
    },
    scripthub: {
      vi: { title: 'Script Hub & Search', subtitle: 'ScriptBlox Cloud' },
      en: { title: 'Script Hub & Search', subtitle: 'ScriptBlox Cloud' },
    },
    obfuscator: {
      vi: { title: 'Maximum Lua Obfuscator', subtitle: 'Security & Protection' },
      en: { title: 'Maximum Lua Obfuscator', subtitle: 'Security & Protection' },
    },
    protection: {
      vi: { title: 'Lua Protection — Khóa file script', subtitle: 'File Lock & Gateway Protection' },
      en: { title: 'Lua Protection — Lock Script File', subtitle: 'File Lock & Gateway Protection' },
    },
    forum: {
      vi: { title: 'Diễn đàn Thảo luận & Chia sẻ Unix.fun', subtitle: 'Community Forum' },
      en: { title: 'Unix.fun Community & Discussion', subtitle: 'Community Forum' },
    },
  };

  const currentInfo = titles[currentTab] || titles.download;

  return (
    <header
      style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '24px',
        flexWrap: 'wrap',
        gap: '16px',
      }}
    >
      <div>
        <p style={{ color: 'var(--text-muted)', fontSize: '13.5px', margin: 0 }}>
          {lang === 'vi' ? currentInfo.vi.subtitle : currentInfo.en.subtitle}
        </p>
        <h1 style={{ fontSize: '26px', fontWeight: 700, marginTop: '4px', color: '#fff', margin: 0 }}>
          {lang === 'vi' ? currentInfo.vi.title : currentInfo.en.title}
        </h1>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
        {/* Notification Bell Button with Red Badge */}
        <button
          type="button"
          onClick={onOpenNotifications}
          title={lang === 'vi' ? 'Thông báo & Tin nhắn Ping' : 'Notifications & Pings'}
          style={{
            position: 'relative',
            background: 'rgba(255, 255, 255, 0.05)',
            border: '1px solid var(--border-color)',
            color: '#fff',
            width: '40px',
            height: '40px',
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            fontSize: '15px',
            transition: 'all 0.2s ease',
          }}
          className="hover:border-[#ff2a6d] hover:bg-[rgba(255,42,109,0.15)]"
        >
          <i className="fa-solid fa-bell"></i>
          {unreadCount > 0 && (
            <span
              style={{
                position: 'absolute',
                top: '-4px',
                right: '-4px',
                backgroundColor: '#ff1744',
                color: '#fff',
                fontSize: '10.5px',
                fontWeight: 900,
                width: '18px',
                height: '18px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 0 8px rgba(255, 23, 68, 0.9)',
                border: '2px solid #07070a',
              }}
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {/* Profile Avatar Quick Link if logged in */}
        {currentUser && (
          <div
            onClick={() => onOpenProfile(currentUser.username)}
            title={lang === 'vi' ? 'Hồ sơ cá nhân của bạn' : 'My Profile'}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              background: 'rgba(255, 255, 255, 0.04)',
              border: '1px solid var(--border-color)',
              padding: '4px 10px 4px 5px',
              borderRadius: '20px',
              cursor: 'pointer',
            }}
            className="hover:border-[#ff2a6d]"
          >
            <img
              src={
                currentUser.avatar ||
                `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(currentUser.username)}`
              }
              alt=""
              style={{ width: '28px', height: '28px', borderRadius: '50%', objectFit: 'cover' }}
            />
            <span style={{ fontSize: '12.5px', fontWeight: 700, color: '#fff' }}>
              {currentUser.displayName || currentUser.username}
            </span>
            {(currentUser.role === 'admin' || currentUser.username.toLowerCase() === 'admin') && (
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '4px',
                  backgroundColor: 'rgba(239, 68, 68, 0.2)',
                  color: '#f87171',
                  border: '1px solid rgba(239, 68, 68, 0.5)',
                  borderRadius: '12px',
                  padding: '1px 7px',
                  fontSize: '10.5px',
                  fontWeight: 800,
                  boxShadow: '0 0 8px rgba(239, 68, 68, 0.4)',
                }}
              >
                <span
                  style={{
                    width: '6px',
                    height: '6px',
                    borderRadius: '50%',
                    backgroundColor: '#ef4444',
                    boxShadow: '0 0 6px #ef4444',
                    display: 'inline-block',
                  }}
                />
                <span>Admin</span>
              </span>
            )}
          </div>
        )}

        <a
          href="https://www.youtube.com/@johnistoo"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            background: 'rgba(255, 0, 0, 0.12)',
            borderColor: 'rgba(255, 0, 0, 0.3)',
            color: '#fff',
            fontWeight: 600,
            padding: '6px 14px',
            borderRadius: '10px',
            border: '1px solid rgba(255, 0, 0, 0.3)',
            textDecoration: 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '12.5px',
            transition: 'all 0.2s ease',
          }}
          className="hover:bg-[rgba(255,0,0,0.3)] hover:border-red-500 hover:shadow-[0_0_15px_rgba(255,0,0,0.3)]"
        >
          <i className="fa-brands fa-youtube" style={{ color: '#ff4d4d' }}></i> YouTube
        </a>

        <a
          href="https://discord.gg/WWyZqKw3yC"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            background: 'rgba(88, 101, 242, 0.12)',
            borderColor: 'rgba(88, 101, 242, 0.3)',
            color: '#fff',
            fontWeight: 600,
            padding: '6px 14px',
            borderRadius: '10px',
            border: '1px solid rgba(88, 101, 242, 0.3)',
            textDecoration: 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '12.5px',
            transition: 'all 0.2s ease',
          }}
          className="hover:bg-[rgba(88,101,242,0.3)] hover:border-[#5865f2] hover:shadow-[0_0_15px_rgba(88,101,242,0.3)]"
        >
          <i className="fa-brands fa-discord" style={{ color: '#5865f2' }}></i> Discord
        </a>

        <div
          style={{
            display: 'inline-flex',
            background: 'rgba(14, 14, 24, 0.95)',
            border: '1px solid var(--border-color)',
            borderRadius: '30px',
            padding: '3px',
            gap: '2px',
          }}
        >
          <button
            onClick={() => onSetLang('vi')}
            style={{
              background: lang === 'vi' ? 'var(--primary-pink)' : 'transparent',
              color: lang === 'vi' ? '#fff' : 'var(--text-muted)',
              border: 'none',
              padding: '6px 14px',
              borderRadius: '20px',
              fontSize: '13px',
              fontWeight: 700,
              cursor: 'pointer',
              boxShadow: lang === 'vi' ? '0 0 12px var(--wibu-glow)' : 'none',
              transition: 'all 0.2s ease',
            }}
          >
            VI
          </button>
          <button
            onClick={() => onSetLang('en')}
            style={{
              background: lang === 'en' ? 'var(--primary-pink)' : 'transparent',
              color: lang === 'en' ? '#fff' : 'var(--text-muted)',
              border: 'none',
              padding: '6px 14px',
              borderRadius: '20px',
              fontSize: '13px',
              fontWeight: 700,
              cursor: 'pointer',
              boxShadow: lang === 'en' ? '0 0 12px var(--wibu-glow)' : 'none',
              transition: 'all 0.2s ease',
            }}
          >
            EN
          </button>
        </div>
      </div>
    </header>
  );
};
