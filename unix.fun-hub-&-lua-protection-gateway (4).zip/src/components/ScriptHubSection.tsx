import React, { useState, useEffect, useCallback } from 'react';
import { ScriptBloxItem } from '../types';

interface ScriptHubSectionProps {
  lang: 'vi' | 'en';
  onShowToast: (msg: string, isError?: boolean) => void;
}

const FALLBACK_SCRIPTS: ScriptBloxItem[] = [
  {
    title: 'Blox Fruits Auto Farm & Sea Event Chest',
    script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/realredz/BloxFruits/main/Source.lua"))()',
    views: 125400,
    isUniversal: false,
    game: {
      name: 'Blox Fruits',
      imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=500&auto=format&fit=crop',
    },
  },
  {
    title: 'Arsenal Silent Aim & ESP Hitbox',
    script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.txt"))()',
    views: 89300,
    isUniversal: false,
    game: {
      name: 'Arsenal',
      imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=500&auto=format&fit=crop',
    },
  },
  {
    title: 'Infinite Yield Admin Universal Command Bar',
    script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()',
    views: 450200,
    isUniversal: true,
    game: {
      name: 'Universal Roblox',
      imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=500&auto=format&fit=crop',
    },
  },
  {
    title: 'Blade Ball Auto Parry & Custom Dash',
    script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/3345-c-a-t-s-u-s/Source/main/BladeBall.lua"))()',
    views: 74200,
    isUniversal: false,
    game: {
      name: 'Blade Ball',
      imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=500&auto=format&fit=crop',
    },
  },
];

export const ScriptHubSection: React.FC<ScriptHubSectionProps> = ({ lang, onShowToast }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [scripts, setScripts] = useState<ScriptBloxItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchScripts = useCallback(async (query = '') => {
    setIsLoading(true);
    try {
      let url = 'https://scriptblox.com/api/script/fetch?page=1';
      if (query.trim() !== '') {
        url = `https://scriptblox.com/api/script/search?q=${encodeURIComponent(query)}`;
      }

      const response = await fetch(url);
      if (!response.ok) throw new Error('API Response not ok');
      const data = await response.json();
      const list = data.result && data.result.scripts ? data.result.scripts : [];
      if (list.length > 0) {
        setScripts(list);
      } else {
        // Fallback filter
        const filtered = FALLBACK_SCRIPTS.filter((s) =>
          s.title.toLowerCase().includes(query.toLowerCase()) ||
          (s.game?.name && s.game.name.toLowerCase().includes(query.toLowerCase()))
        );
        setScripts(filtered);
      }
    } catch {
      // Fallback
      const filtered = FALLBACK_SCRIPTS.filter((s) =>
        query.trim() === '' ||
        s.title.toLowerCase().includes(query.toLowerCase()) ||
        (s.game?.name && s.game.name.toLowerCase().includes(query.toLowerCase()))
      );
      setScripts(filtered);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchScripts('');
  }, [fetchScripts]);

  const handleCopyScript = (scriptCode: string) => {
    navigator.clipboard.writeText(scriptCode).then(() => {
      onShowToast(lang === 'vi' ? 'Đã copy loadstring thành công!' : 'Loadstring copied to clipboard!');
    });
  };

  return (
    <section>
      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px' }}>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') fetchScripts(searchTerm);
          }}
          placeholder={
            lang === 'vi'
              ? 'Tìm kiếm script Roblox (ví dụ: Blox Fruits, Arsenal...)...'
              : 'Search Roblox scripts (e.g. Blox Fruits, Arsenal...)...'
          }
          style={{
            flexGrow: 1,
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: '12px',
            padding: '12px 18px',
            color: '#fff',
            fontSize: '14px',
            outline: 'none',
            transition: 'all 0.2s ease',
          }}
          className="focus:border-[#ff2a6d] focus:shadow-[0_0_15px_rgba(255,42,109,0.35)]"
        />
        <button
          onClick={() => fetchScripts(searchTerm)}
          style={{
            background: 'rgba(255, 42, 109, 0.25)',
            color: '#fff',
            fontWeight: 600,
            padding: '10px 20px',
            borderRadius: '12px',
            border: '1px solid var(--primary-pink)',
            cursor: 'pointer',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '13.5px',
            boxShadow: '0 0 12px var(--wibu-glow)',
          }}
        >
          <i className="fa-solid fa-magnifying-glass"></i>
          <span>{lang === 'vi' ? 'Tìm kiếm' : 'Search'}</span>
        </button>
      </div>

      {isLoading ? (
        <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '40px' }}>
          <i className="fa-solid fa-spinner fa-spin fa-2x" style={{ color: 'var(--primary-pink)' }}></i>
          <p style={{ marginTop: '10px' }}>
            {lang === 'vi' ? 'Đang tải danh sách Script...' : 'Loading Scripts...'}
          </p>
        </div>
      ) : scripts.length === 0 ? (
        <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '40px' }}>
          {lang === 'vi' ? 'Không tìm thấy script phù hợp!' : 'No scripts found!'}
        </div>
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
            gap: '16px',
          }}
        >
          {scripts.map((item, idx) => {
            let imageUrl =
              item.game?.imageUrl ||
              'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=500&auto=format&fit=crop';
            if (imageUrl.startsWith('/')) {
              imageUrl = `https://scriptblox.com${imageUrl}`;
            }

            return (
              <div
                key={idx}
                style={{
                  background: 'var(--card-bg)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '14px',
                  overflow: 'hidden',
                  display: 'flex',
                  flexDirection: 'column',
                  transition: 'all 0.2s ease',
                }}
                className="hover:border-[#ff2a6d] hover:shadow-[0_0_20px_rgba(255,42,109,0.35)]"
              >
                <div style={{ position: 'relative', width: '100%', height: '140px', background: '#0d0d15', overflow: 'hidden' }}>
                  <img
                    src={imageUrl}
                    alt={item.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=500&auto=format&fit=crop';
                    }}
                  />
                  <span
                    style={{
                      position: 'absolute',
                      top: '8px',
                      right: '8px',
                      background: 'rgba(255, 42, 109, 0.9)',
                      color: '#fff',
                      fontSize: '10px',
                      fontWeight: 700,
                      padding: '3px 8px',
                      borderRadius: '10px',
                    }}
                  >
                    {item.isUniversal ? 'Universal' : 'Game'}
                  </span>
                </div>

                <div
                  style={{
                    padding: '14px',
                    display: 'flex',
                    flexDirection: 'column',
                    flexGrow: 1,
                    justifyContent: 'space-between',
                  }}
                >
                  <div>
                    <h3
                      title={item.title}
                      style={{
                        fontSize: '14px',
                        fontWeight: 700,
                        marginBottom: '4px',
                        color: '#fff',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {item.title}
                    </h3>
                    <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '10px' }}>
                      <i className="fa-solid fa-gamepad"></i> {item.game?.name || 'Roblox'}
                    </p>
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      borderTop: '1px solid rgba(255, 255, 255, 0.05)',
                      paddingTop: '10px',
                      fontSize: '11.5px',
                      color: 'var(--text-muted)',
                    }}
                  >
                    <span>
                      <i className="fa-solid fa-eye"></i> {item.views || 0}
                    </span>
                    <button
                      onClick={() => handleCopyScript(item.script)}
                      style={{
                        background: 'rgba(255, 255, 255, 0.05)',
                        color: '#fff',
                        fontWeight: 600,
                        padding: '6px 12px',
                        borderRadius: '8px',
                        border: '1px solid rgba(255, 42, 109, 0.3)',
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '6px',
                        fontSize: '12px',
                      }}
                      className="hover:bg-[rgba(255,42,109,0.25)] hover:border-[#ff2a6d]"
                    >
                      <i className="fa-solid fa-copy"></i>
                      <span>Copy</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
