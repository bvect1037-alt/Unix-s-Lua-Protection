import React, { useState, useEffect } from 'react';

interface ProtectedGatewayViewProps {
  scriptId: string;
  lang?: 'vi' | 'en';
  onBackToHub?: () => void;
  onShowToast: (msg: string, isError?: boolean) => void;
}

export const ProtectedGatewayView: React.FC<ProtectedGatewayViewProps> = ({
  scriptId,
  lang = 'en',
  onBackToHub,
  onShowToast,
}) => {
  const [scriptData, setScriptData] = useState<{
    name: string;
    lua: string;
    rawUrl: string;
    password?: string;
  } | null>(null);

  const [showExecutorSimulator, setShowExecutorSimulator] = useState(false);
  const [simulatedResponse, setSimulatedResponse] = useState<string>('');
  const [isFetchingSim, setIsFetchingSim] = useState(false);

  useEffect(() => {
    // 0.01s Anti-Devtools client trap listener for gateway simulator
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === 'F12' ||
        (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) ||
        (e.ctrlKey && (e.key === 'U' || e.key === 'u' || e.key === 'S' || e.key === 's'))
      ) {
        e.preventDefault();
        onShowToast(lang === 'vi' ? 'Anti-Skid: Đã chặn DevTools!' : 'Anti-Skid Armor: DevTools Blocked!', true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lang, onShowToast]);

  useEffect(() => {
    // Fetch script metadata
    fetch(`/api/scripts/${scriptId}`)
      .then((res) => res.json())
      .then((data) => {
        if (data && data.name) {
          setScriptData({
            name: data.name,
            lua: data.protectedLua || data.sourceCode,
            password: data.password,
            rawUrl: `${window.location.origin}/raw/${scriptId}.lua`,
          });
        }
      })
      .catch(() => {
        // fallback to localStorage
        const cached = localStorage.getItem(`unix_prot_${scriptId}`);
        if (cached) {
          try {
            const parsed = JSON.parse(cached);
            setScriptData({
              name: parsed.name || 'Protected Script',
              lua: parsed.lua || `-- Script #${scriptId}`,
              password: parsed.password,
              rawUrl: `${window.location.origin}/raw/${scriptId}.lua`,
            });
          } catch {
            // ignore
          }
        }
      });
  }, [scriptId]);

  const handleSimulateRoblox = () => {
    setIsFetchingSim(true);
    fetch(`/raw/${scriptId}.lua`, {
      headers: {
        'x-unix-sim': '1',
        'User-Agent': 'Roblox/WinInet (Unix.fun Simulator)',
      },
    })
      .then((res) => res.text())
      .then((text) => {
        setSimulatedResponse(text);
        setIsFetchingSim(false);
        onShowToast(lang === 'vi' ? 'Roblox Executor (game:HttpGet) tải Lua thành công!' : 'Roblox Executor (game:HttpGet) loaded successfully!');
      })
      .catch(() => {
        setIsFetchingSim(false);
        setSimulatedResponse(scriptData?.lua || `-- Lua output for #${scriptId}`);
      });
  };

  const handleCopyLoadstring = () => {
    const directUrl = `${window.location.origin}/raw/${scriptId}.lua`;
    const loadstring = `loadstring(game:HttpGet("${directUrl}"))()`;

    navigator.clipboard.writeText(loadstring).then(() => {
      onShowToast(lang === 'vi' ? 'Đã sao chép câu lệnh loadstring!' : 'Copied loadstring command!');
    });
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundColor: '#07070a',
        backgroundImage: `
          linear-gradient(rgba(255, 255, 255, 0.02) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255, 255, 255, 0.02) 1px, transparent 1px)
        `,
        backgroundSize: '32px 32px',
        color: '#ffffff',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px',
        position: 'relative',
        fontFamily: "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif",
      }}
    >
      {/* Background soft red glow */}
      <div
        style={{
          position: 'absolute',
          width: '450px',
          height: '450px',
          background: 'radial-gradient(circle, rgba(255, 42, 109, 0.09) 0%, rgba(0, 0, 0, 0) 70%)',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          pointerEvents: 'none',
          zIndex: 0,
        }}
      />

      {/* Main Access Denied Center Box */}
      <div
        style={{
          position: 'relative',
          zIndex: 1,
          textAlign: 'center',
          maxWidth: '540px',
          width: '100%',
          padding: '40px 24px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ff2a6d]/10 border border-[#ff2a6d]/30 text-[#ff2a6d] text-[11px] font-bold tracking-wider uppercase mb-4">
          <i className="fa-solid fa-shield-halved"></i> 0.01s Anti-Skid Shield
        </div>

        <h1
          style={{
            fontSize: '48px',
            fontWeight: 800,
            color: '#ff334b',
            letterSpacing: '-0.5px',
            marginBottom: '16px',
            textShadow: '0 0 30px rgba(255, 51, 75, 0.35)',
            lineHeight: 1.1,
          }}
        >
          Access Denied
        </h1>

        <p
          style={{
            fontSize: '16px',
            color: '#9ba1b0',
            fontWeight: 500,
            marginBottom: '6px',
          }}
        >
          File Protected by Unix Auth
        </p>

        <p
          style={{
            fontSize: '14.5px',
            color: '#6b7280',
            marginBottom: '28px',
            lineHeight: 1.5,
          }}
        >
          {lang === 'vi'
            ? 'Trình duyệt web không được cấp quyền xem trực tiếp file mã nguồn thô.'
            : 'Direct browser access to raw script payloads is strictly restricted.'}
        </p>

        <button
          onClick={onBackToHub}
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '10px',
            backgroundColor: '#121218',
            color: '#e5e7eb',
            textDecoration: 'none',
            fontSize: '14px',
            fontWeight: 600,
            padding: '12px 24px',
            borderRadius: '10px',
            border: '1px solid rgba(255, 255, 255, 0.12)',
            transition: 'all 0.2s ease',
            cursor: 'pointer',
            boxShadow: '0 4px 14px rgba(0, 0, 0, 0.4)',
          }}
          className="hover:bg-[#1a1a24] hover:border-[#ff2a6d] hover:text-white"
        >
          <i className="fa-solid fa-arrow-left"></i>
          <span>{lang === 'vi' ? 'Quay lại Unix Auth' : 'Return to Unix Auth'}</span>
        </button>

        {/* Developer / Owner Live Test Toolbar */}
        <div
          style={{
            marginTop: '36px',
            padding: '16px 20px',
            background: 'rgba(255, 255, 255, 0.02)',
            border: '1px solid rgba(255, 255, 255, 0.06)',
            borderRadius: '14px',
            width: '100%',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '11.5px', color: '#8e95a5', fontFamily: 'monospace' }}>
              <i className="fa-solid fa-terminal" style={{ color: '#ff2a6d', marginRight: '6px' }}></i>
              ID: {scriptId}
            </span>
            <button
              onClick={() => setShowExecutorSimulator(!showExecutorSimulator)}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#ff2a6d',
                fontSize: '12px',
                cursor: 'pointer',
                fontWeight: 600,
                textDecoration: 'underline',
              }}
            >
              {showExecutorSimulator
                ? (lang === 'vi' ? 'Ẩn Trình Test' : 'Hide Test Runner')
                : (lang === 'vi' ? 'Test Roblox Executor (game:HttpGet)' : 'Test Roblox Executor (game:HttpGet)')}
            </button>
          </div>

          {showExecutorSimulator && (
            <div style={{ marginTop: '4px', textAlign: 'left' }}>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
                <button
                  onClick={handleSimulateRoblox}
                  disabled={isFetchingSim}
                  style={{
                    flex: 1,
                    background: 'rgba(255, 42, 109, 0.2)',
                    border: '1px solid #ff2a6d',
                    color: '#fff',
                    padding: '8px 12px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <i className="fa-solid fa-play" style={{ marginRight: '6px' }}></i>
                  {isFetchingSim
                    ? (lang === 'vi' ? 'Đang gọi HttpGet...' : 'Executing HttpGet...')
                    : (lang === 'vi' ? 'Giả lập game:HttpGet()' : 'Simulate game:HttpGet()')}
                </button>
                <button
                  onClick={handleCopyLoadstring}
                  style={{
                    background: 'rgba(255, 255, 255, 0.05)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    color: '#fff',
                    padding: '8px 12px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <i className="fa-solid fa-copy" style={{ marginRight: '6px' }}></i>
                  {lang === 'vi' ? 'Sao chép Loadstring' : 'Copy Loadstring'}
                </button>
              </div>

              {simulatedResponse && (
                <div>
                  <span style={{ fontSize: '11px', color: '#00ffcc', display: 'block', marginBottom: '4px', fontWeight: 600 }}>
                    <i className="fa-solid fa-circle-check"></i> {lang === 'vi' ? 'Roblox Executor nhận được mã Lua thô:' : 'Roblox Executor received raw Lua stream:'}
                  </span>
                  <pre
                    style={{
                      background: '#040406',
                      border: '1px solid #1e1e2d',
                      borderRadius: '8px',
                      padding: '10px',
                      color: '#00ffcc',
                      fontFamily: 'monospace',
                      fontSize: '11px',
                      maxHeight: '160px',
                      overflowY: 'auto',
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-all',
                    }}
                  >
                    {simulatedResponse}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div
        style={{
          position: 'absolute',
          bottom: '28px',
          fontSize: '11px',
          fontWeight: 700,
          letterSpacing: '2px',
          color: '#374151',
          textTransform: 'uppercase',
          fontFamily: "'JetBrains Mono', monospace",
        }}
      >
        UNIX AUTH V5 • ZERO COMPROMISE
      </div>
    </div>
  );
};
