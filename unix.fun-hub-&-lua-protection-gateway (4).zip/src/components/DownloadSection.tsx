import React from 'react';

interface DownloadSectionProps {
  lang: 'vi' | 'en';
  onShowToast: (msg: string, isError?: boolean) => void;
}

export const DownloadSection: React.FC<DownloadSectionProps> = ({ lang }) => {
  return (
    <section>
      <div
        style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--border-color)',
          borderRadius: '16px',
          padding: '24px',
          marginBottom: '24px',
        }}
      >
        <h2 style={{ fontSize: '20px', margin: '4px 0 8px 0', color: 'var(--primary-pink)', fontWeight: 700 }}>
          {lang === 'vi' ? 'Công cụ độc quyền Unix.fun' : 'Exclusive Unix.fun Tools'}
        </h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '13.5px', lineHeight: 1.5, margin: 0 }}>
          {lang === 'vi'
            ? 'Tải về Unix.fun Client PC và Installer Auto Update chính chủ để trải nghiệm hệ thống script tối ưu nhất.'
            : 'Download official Unix.fun Client PC and Auto Update Installer for the ultimate script execution experience.'}
        </p>
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '20px',
        }}
      >
        {/* Card 1: Unix.fun Client PC */}
        <div
          style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: '16px',
            padding: '24px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            position: 'relative',
            transition: 'all 0.2s ease',
          }}
          className="hover:border-[#ff2a6d] hover:shadow-[0_0_25px_rgba(255,42,109,0.35)]"
        >
          <div
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '3px',
              background: 'linear-gradient(90deg, var(--primary-pink), var(--secondary-pink))',
            }}
          />
          <div>
            <div
              style={{
                width: '46px',
                height: '46px',
                background: 'rgba(255, 42, 109, 0.1)',
                border: '1px solid rgba(255, 42, 109, 0.3)',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--primary-pink)',
                fontSize: '20px',
                marginBottom: '16px',
              }}
            >
              <i className="fa-solid fa-desktop"></i>
            </div>
            <span
              style={{
                color: 'var(--primary-pink)',
                fontWeight: 700,
                fontSize: '11.5px',
                letterSpacing: '0.5px',
              }}
            >
              UNIX.FUN EXCLUSIVE
            </span>
            <h3 style={{ margin: '6px 0 8px 0', fontSize: '17px', fontWeight: 700, color: '#fff' }}>
              Unix.fun Client PC
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '13px', lineHeight: 1.5, margin: 0 }}>
              {lang === 'vi'
                ? 'Trình quản lý và chạy script độc quyền tối ưu hóa riêng cho máy tính Windows.'
                : 'Exclusive manager and script executor optimized for Windows PCs.'}
            </p>
          </div>
          <a
            href="https://github.com/bvect1037-alt/Unix.fun/raw/refs/heads/main/Unix.fun.zip"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              marginTop: '20px',
              justifyContent: 'center',
              background: 'rgba(255, 42, 109, 0.25)',
              borderColor: 'var(--primary-pink)',
              color: '#fff',
              fontWeight: 600,
              padding: '10px 18px',
              borderRadius: '10px',
              border: '1px solid rgba(255, 42, 109, 0.3)',
              cursor: 'pointer',
              textDecoration: 'none',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '13.5px',
              boxShadow: '0 0 15px var(--wibu-glow)',
            }}
          >
            <i className="fa-solid fa-download"></i>
            <span>{lang === 'vi' ? 'Tải về Unix.fun PC' : 'Download Unix.fun PC'}</span>
          </a>
        </div>

        {/* Card 2: Installer Auto Update */}
        <div
          style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: '16px',
            padding: '24px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            position: 'relative',
            transition: 'all 0.2s ease',
          }}
          className="hover:border-[#b388ff] hover:shadow-[0_0_25px_rgba(179,136,255,0.35)]"
        >
          <div
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '3px',
              background: 'linear-gradient(90deg, #b388ff, #ff5e87)',
            }}
          />
          <div>
            <div
              style={{
                width: '46px',
                height: '46px',
                background: 'rgba(179,136,255,0.1)',
                border: '1px solid rgba(179,136,255,0.3)',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#b388ff',
                fontSize: '20px',
                marginBottom: '16px',
              }}
            >
              <i className="fa-solid fa-rotate"></i>
            </div>
            <span
              style={{
                color: '#b388ff',
                fontWeight: 700,
                fontSize: '11.5px',
                letterSpacing: '0.5px',
              }}
            >
              AUTO UPDATE TOOL
            </span>
            <h3 style={{ margin: '6px 0 8px 0', fontSize: '17px', fontWeight: 700, color: '#fff' }}>
              Unix.fun Installer Auto Update
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '13px', lineHeight: 1.5, margin: 0 }}>
              {lang === 'vi'
                ? 'Công cụ cài đặt tự động cập nhật phiên bản mới nhất liên tục mà không cần thao tác thủ công.'
                : 'Auto-updater installer tool to keep your client updated continuously without manual steps.'}
            </p>
          </div>
          <a
            href="https://gofile.io/d/RcZHH8Ee"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              marginTop: '20px',
              justifyContent: 'center',
              background: 'rgba(179,136,255,0.15)',
              borderColor: 'rgba(179,136,255,0.3)',
              color: '#fff',
              fontWeight: 600,
              padding: '10px 18px',
              borderRadius: '10px',
              border: '1px solid rgba(179,136,255,0.3)',
              cursor: 'pointer',
              textDecoration: 'none',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '13.5px',
            }}
          >
            <i className="fa-solid fa-rotate"></i>
            <span>{lang === 'vi' ? 'Tải về Installer (Gofile)' : 'Download Installer (Gofile)'}</span>
          </a>
        </div>
      </div>
    </section>
  );
};
