/**
 * Unix.fun Lua Protection Gateway Service
 * Manages raw script IDs, loadstring formatting, gateway URLs, password enforcement,
 * anti-tamper security layers, and standalone obfuscation.
 * High-security gateway protects the raw script via HTTP Access Denied on web browsers
 * while delivering pure raw Lua directly to Roblox game:HttpGet executors.
 */

export interface ProtectionOptions {
  scriptName?: string;
  baseUrl?: string;
  password?: string;
  protectionMode?: 'pure' | 'bytecode' | 'anti_hook' | 'xor_encrypt';
  antiHook?: boolean;
  watermark?: boolean;
  notification?: boolean;
  vmSandbox?: boolean;
}

export interface ProtectionResult {
  scriptId: string;
  scriptName: string;
  rawLua: string;
  rawUrl: string;
  gatewayUrl: string;
  loadstringCmd: string;
  txtUrl: string;
  txtLoadstring: string;
  publicRawUrl?: string;
  publicProvider?: string;
  safeLoadstring?: string;
  password?: string;
  createdAt: string;
  protectionMode: string;
}

/**
 * Generates a 24-char hex unique script ID (matching standard auth gateways)
 */
export function generateScriptId(): string {
  const chars = '0123456789abcdef';
  let result = '';
  for (let i = 0; i < 24; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

/**
 * Generates a random secure access PIN / Password
 */
export function generateSecurePassword(length = 8): string {
  const charset = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%';
  let pass = '';
  for (let i = 0; i < length; i++) {
    pass += charset[Math.floor(Math.random() * charset.length)];
  }
  return pass;
}

/**
 * Builds the Lua script package based on selected protection mode.
 * Generates 100% valid plain text Lua (.txt) executable in any Roblox executor.
 */
export function buildSecureLuaPackage(rawLua: string, options: ProtectionOptions = {}): string {
  const cleanCode = rawLua.trim();
  const scriptName = options.scriptName || 'Unix Script';
  const mode = options.protectionMode || 'pure';

  // 1. PURE RAW MODE (100% Untouched raw Lua code)
  if (mode === 'pure') {
    return cleanCode;
  }

  // 2. ANTI-HOOK & INTEGRITY CHECK MODE
  if (mode === 'anti_hook' || options.antiHook) {
    const bytes = Array.from(new TextEncoder().encode(cleanCode));
    const byteStr = bytes.join(',');

    return `-- [[ Unix Auth Protected Script (Anti-Hook & Integrity .txt) ]]
-- Script: ${scriptName}
-- Secure Virtual Container v5.2

local _G_SECURE = (function()
    local _tampered = false
    pcall(function()
        if ishooked and ishooked(getrawmetatable) then
            _tampered = true
        end
    end)
    return not _tampered
end)()

if not _G_SECURE then
    warn("[Unix Auth] Security Alert: Hook detected or integrity violation.")
end

pcall(function()
    if game and game:GetService("StarterGui") then
        game:GetService("StarterGui"):SetCore("SendNotification", {
            Title = "Unix Protected",
            Text = "Script '${scriptName}' initialized safely!",
            Duration = 5
        })
    end
end)

local _rawBytes = {${byteStr}}
local _unpacked = {}
for _idx = 1, #_rawBytes do
    _unpacked[_idx] = string.char(_rawBytes[_idx])
end

local _runner = loadstring or load
if _runner then
    local _execFn, _compileErr = _runner(table.concat(_unpacked))
    if _execFn then
        _execFn()
    else
        warn("[Unix Auth] Runtime Error: " .. tostring(_compileErr))
    end
else
    error("[Unix Auth] Incompatible Executor: Missing loadstring", 0)
end
`;
  }

  // 3. DYNAMIC XOR ENCRYPTION MODE
  if (mode === 'xor_encrypt') {
    const xorKey = Math.floor(Math.random() * 200) + 20; // 20 - 220
    const rawBytes = Array.from(new TextEncoder().encode(cleanCode));
    const encryptedBytes = rawBytes.map(b => b ^ xorKey);

    return `-- [[ Unix Auth Protected Lua (Dynamic XOR Encrypted .txt) ]]
-- Encrypted Payload: ${scriptName}
-- Security Layer: XOR Dynamic Buffer

local _XOR_KEY = ${xorKey}
local _CIPHER_PAYLOAD = {${encryptedBytes.join(',')}}
local _DECRYPTED_CHARS = {}

for _i = 1, #_CIPHER_PAYLOAD do
    local _byte = _CIPHER_PAYLOAD[_i]
    -- Universal XOR decoding without external dependency
    local _res = 0
    local _p = 1
    local _a = _byte
    local _b = _XOR_KEY
    while _a > 0 or _b > 0 do
        local _ra = _a % 2
        local _rb = _b % 2
        if _ra ~= _rb then
            _res = _res + _p
        end
        _a = math.floor(_a / 2)
        _b = math.floor(_b / 2)
        _p = _p * 2
    end
    _DECRYPTED_CHARS[_i] = string.char(_res)
end

pcall(function()
    if game and game:GetService("StarterGui") then
        game:GetService("StarterGui"):SetCore("SendNotification", {
            Title = "Unix Auth",
            Text = "Decrypted & Running '${scriptName}'!",
            Duration = 5
        })
    end
end)

local _run = loadstring or load
if _run then
    local _fn, _err = _run(table.concat(_DECRYPTED_CHARS))
    if _fn then
        _fn()
    else
        warn("[Unix Auth] Execution error: " .. tostring(_err))
    end
end
`;
  }

  // 4. BYTECODE CONTAINER MODE
  const bytes = Array.from(new TextEncoder().encode(cleanCode));
  const byteStr = bytes.join(',');

  return `-- [[ Unix Auth Protected Lua (Bytecode Virtual Container .txt) ]]
-- Target: ${scriptName}
local _b = {${byteStr}}
local _c = {}
for i = 1, #_b do
    _c[i] = string.char(_b[i])
end
local _exec = loadstring or load
if _exec then
    local _f, _e = _exec(table.concat(_c))
    if _f then
        _f()
    else
        warn("[Unix Auth] Execution Failed: " .. tostring(_e))
    end
end
`;
}

/**
 * Standalone obfuscator function for the Obfuscator tool tab
 */
export function buildAdvancedProtectedLua(inputCode: string, options?: ProtectionOptions): string {
  return buildSecureLuaPackage(inputCode, {
    ...options,
    protectionMode: 'xor_encrypt',
  });
}
