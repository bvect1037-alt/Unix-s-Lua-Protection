import JSZip from 'jszip';

export interface ExportZipOptions {
  scripts?: Array<{ id: string; name: string; content: string; password?: string }>;
  baseUrl?: string;
}

export async function generateFullProjectZip(options: ExportZipOptions = {}): Promise<Blob> {
  const zip = new JSZip();

  const baseUrl = options.baseUrl || 'https://unixfun.netlify.app';

  // 1. netlify.toml for CORS and proper headers
  const netlifyToml = `[[headers]]
  for = "/*"
  [headers.values]
    Access-Control-Allow-Origin = "*"
    Access-Control-Allow-Methods = "GET, POST, OPTIONS"
    Access-Control-Allow-Headers = "*"

[[headers]]
  for = "/scripts/*"
  [headers.values]
    Content-Type = "text/plain; charset=utf-8"
    Access-Control-Allow-Origin = "*"
`;

  // 2. _headers for Netlify
  const headersFile = `/*
  Access-Control-Allow-Origin: *
/scripts/*
  Content-Type: text/plain; charset=utf-8
  Access-Control-Allow-Origin: *
`;

  // 3. README.md
  const readmeMd = `# Unix.fun Hub & Lua Protection Gateway (Netlify Ready)

Đây là bộ mã nguồn hoàn chỉnh của trang web **Unix.fun Hub** cùng với hệ thống **Lua Protection Gateway**.

## 📁 Cấu trúc thư mục:
- \`index.html\`: Trang chủ Unix.fun Hub (Download, Script Hub, Obfuscator, Lua Protection, Forum).
- \`protected.html\`: Trang Gateway xác thực mã bảo vệ (\`?script=ID\`).
- \`scripts/\`: Thư mục chứa các file mã Lua bảo vệ (ví dụ: \`script_51793014.lua\`).
- \`netlify.toml\` & \`_headers\`: Cấu hình cho phép Roblox Executor đọc trực tiếp file script qua \`game:HttpGet\`.

## 🚀 Cách Deploy lên Netlify siêu nhanh:
1. Đăng nhập vào [Netlify](https://app.netlify.com/).
2. Kéo thả (Drag & Drop) toàn bộ thư mục giải nén này vào ô **"Deploy manually"** trên Netlify.
3. Hoặc liên kết với GitHub Repository và push thư mục này lên.
4. Mọi link \`protected.html?script=ID\` và câu lệnh \`loadstring(game:HttpGet("https://your-site.netlify.app/scripts/script_ID.lua"))()\` sẽ hoạt động 100%!
`;

  // 4. Standalone index.html
  const standaloneIndexHtml = `<!DOCTYPE html>
<html lang="vi" id="html-root">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unix.fun Hub - Ultimate Edition & Script Hub</title>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-gif: url('https://i.pinimg.com/originals/b9/c1/db/b9c1db60e1e919f5df359b8e165cfdd1.gif');
            --primary-pink: #ff2a6d;
            --secondary-pink: #ff5e87;
            --wibu-glow: rgba(255, 42, 109, 0.35);
            --card-bg: rgba(14, 14, 24, 0.94);
            --sidebar-bg: rgba(10, 10, 18, 0.96);
            --border-color: rgba(255, 42, 109, 0.25);
            --text-main: #ffeef8;
            --text-muted: #c4b0c0;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Quicksand', sans-serif; }
        body { background: var(--bg-gif) no-repeat center center fixed; background-size: cover; color: var(--text-main); min-height: 100vh; overflow-x: hidden; display: flex; }
        .bg-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: linear-gradient(135deg, rgba(10, 8, 30, 0.94), rgba(25, 20, 60, 0.92)); z-index: -1; }
        .app-container { display: flex; width: 100%; min-height: 100vh; }
        sidebar { width: 270px; background: var(--sidebar-bg); border-right: 1px solid var(--border-color); display: flex; flex-direction: column; justify-content: space-between; padding: 24px 18px; position: sticky; top: 0; height: 100vh; z-index: 10; }
        .brand-box { display: flex; align-items: center; gap: 14px; text-decoration: none; color: var(--text-main); padding: 10px 12px; border-radius: 12px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border-color); margin-bottom: 24px; transition: all 0.2s ease; }
        .brand-box:hover { border-color: var(--primary-pink); box-shadow: 0 0 12px var(--wibu-glow); }
        .brand-logo-text { font-size: 24px; font-weight: 900; background: rgba(255, 255, 255, 0.05); padding: 6px 12px; border-radius: 8px; border: 1px solid var(--border-color); letter-spacing: -1px; display: flex; align-items: center; }
        .brand-box .title { font-weight: 700; font-size: 17px; display: block; }
        .brand-box .subtitle { font-size: 12px; color: var(--text-muted); }
        nav { display: flex; flex-direction: column; gap: 6px; flex-grow: 1; }
        nav a { display: flex; align-items: center; gap: 14px; padding: 12px 16px; color: var(--text-muted); text-decoration: none; border-radius: 12px; font-weight: 600; transition: all 0.2s ease; border: 1px solid transparent; }
        nav a:hover, nav a.active { color: #fff; background: rgba(255, 42, 109, 0.15); border-color: rgba(255, 42, 109, 0.3); box-shadow: 0 0 15px rgba(255, 42, 109, 0.15); }
        .user-profile { display: flex; align-items: center; gap: 12px; padding: 12px; background: rgba(255, 255, 255, 0.02); border-radius: 12px; border: 1px solid var(--border-color); margin-top: auto; }
        .user-avatar { width: 38px; height: 38px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-pink), var(--secondary-pink)); display: flex; align-items: center; justify-content: center; font-weight: bold; color: #fff; box-shadow: 0 0 10px var(--wibu-glow); flex-shrink: 0; }
        .user-info p:first-child { font-size: 11px; color: var(--text-muted); }
        .user-info p:last-child { font-size: 13px; font-weight: 700; }
        main { flex-grow: 1; padding: 32px; overflow-y: auto; max-height: 100vh; }
        header.main-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        header.main-header h1 { font-size: 26px; font-weight: 700; margin-top: 4px; }
        header.main-header p { color: var(--text-muted); font-size: 13.5px; }
        .header-top-controls { display: flex; align-items: center; gap: 12px; }
        .lang-switch-container { display: inline-flex; background: rgba(14, 14, 24, 0.95); border: 1px solid var(--border-color); border-radius: 30px; padding: 3px; gap: 2px; }
        .lang-btn { background: transparent; border: none; color: var(--text-muted); padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s ease; }
        .lang-btn.active { background: var(--primary-pink); color: #fff; box-shadow: 0 0 12px var(--wibu-glow); }
        .btn { background: rgba(255, 255, 255, 0.05); color: #fff; font-weight: 600; padding: 10px 18px; border-radius: 10px; border: 1px solid rgba(255, 42, 109, 0.3); cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease; font-size: 13.5px; }
        .btn:hover { background: rgba(255, 42, 109, 0.25); border-color: var(--primary-pink); box-shadow: 0 0 15px var(--wibu-glow); }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .btn-outline { background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border-color); }
        .btn-outline:hover { background: rgba(255, 255, 255, 0.08); }
        .content-section { display: none; }
        .content-section.active { display: block; }
        .workspace-banner { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 16px; padding: 24px; margin-bottom: 24px; }
        .workspace-banner h2 { font-size: 20px; margin: 4px 0 8px 0; color: var(--primary-pink); }
        .workspace-banner p { color: var(--text-muted); font-size: 13.5px; line-height: 1.5; }
        .download-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; }
        .download-card { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 16px; padding: 24px; display: flex; flex-direction: column; justify-content: space-between; position: relative; transition: all 0.2s ease; }
        .download-card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 3px; background: linear-gradient(90deg, var(--primary-pink), var(--secondary-pink)); }
        .download-card:hover { border-color: var(--primary-pink); box-shadow: 0 0 25px var(--wibu-glow); }
        .download-icon-box { width: 46px; height: 46px; background: rgba(255, 42, 109, 0.1); border: 1px solid rgba(255, 42, 109, 0.3); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: var(--primary-pink); font-size: 20px; margin-bottom: 16px; }
        .search-bar-wrapper { display: flex; gap: 12px; margin-bottom: 20px; }
        .search-input { flex-grow: 1; background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 12px; padding: 12px 18px; color: #fff; font-size: 14px; outline: none; transition: all 0.2s ease; }
        .search-input:focus { border-color: var(--primary-pink); box-shadow: 0 0 15px var(--wibu-glow); }
        .script-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 16px; }
        .script-card { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 14px; overflow: hidden; display: flex; flex-direction: column; transition: all 0.2s ease; }
        .script-thumb-wrap { position: relative; width: 100%; height: 140px; background: #0d0d15; overflow: hidden; }
        .script-thumb-wrap img { width: 100%; height: 100%; object-fit: cover; }
        .script-tag { position: absolute; top: 8px; right: 8px; background: rgba(255, 42, 109, 0.9); color: #fff; font-size: 10px; font-weight: 700; padding: 3px 8px; border-radius: 10px; }
        .script-content { padding: 14px; display: flex; flex-direction: column; flex-grow: 1; justify-content: space-between; }
        .script-content h3 { font-size: 14px; font-weight: 700; margin-bottom: 4px; color: #fff; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
        .game-name { font-size: 12px; color: var(--text-muted); margin-bottom: 10px; }
        .script-meta { display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255, 255, 255, 0.05); padding-top: 10px; font-size: 11.5px; color: var(--text-muted); }
        .forum-categories-bar { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 4px; }
        .forum-cat-chip { background: var(--card-bg); border: 1px solid var(--border-color); color: var(--text-muted); padding: 6px 14px; border-radius: 20px; font-size: 12.5px; font-weight: 600; cursor: pointer; white-space: nowrap; transition: all 0.2s ease; }
        .forum-cat-chip:hover, .forum-cat-chip.active { background: var(--primary-pink); color: #fff; border-color: var(--primary-pink); box-shadow: 0 0 10px var(--wibu-glow); }
        .forum-form-box { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 16px; padding: 20px; margin-bottom: 24px; }
        .forum-form-box input, .forum-form-box textarea, .forum-form-box select { width: 100%; background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border-color); border-radius: 10px; padding: 10px 14px; color: #fff; font-size: 13.5px; margin-bottom: 12px; outline: none; }
        .forum-posts-list { display: flex; flex-direction: column; gap: 16px; }
        .forum-post-card { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 14px; padding: 18px; transition: all 0.2s ease; }
        .obfuscator-container { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
        @media (max-width: 900px) { .obfuscator-container { grid-template-columns: 1fr; } }
        .obfuscator-box { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 16px; padding: 20px; display: flex; flex-direction: column; gap: 12px; }
        .obfuscator-textarea { width: 100%; height: 260px; background: rgba(8, 8, 15, 0.95); border: 1px solid var(--border-color); border-radius: 10px; padding: 14px; color: #00ffcc; font-family: monospace; font-size: 12.5px; resize: vertical; outline: none; line-height: 1.4; }
        .options-row { display: flex; gap: 14px; flex-wrap: wrap; font-size: 12.5px; color: var(--text-muted); align-items: center; }
        .options-row label { display: inline-flex; align-items: center; gap: 6px; cursor: pointer; }
        #toast { position: fixed; bottom: 24px; right: 24px; background: rgba(14, 14, 24, 0.98); border: 1px solid var(--primary-pink); color: #fff; padding: 10px 20px; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.4); z-index: 10000; display: none; font-weight: 600; font-size: 13.5px; }
        .history-list-box { margin-top: 15px; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border-color); border-radius: 10px; padding: 12px; max-height: 160px; overflow-y: auto; }
        .history-item { display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.05); font-size: 12px; }
        @media (max-width: 768px) { sidebar { width: 70px; padding: 14px 8px; } sidebar .brand-box .title, sidebar .brand-box .subtitle, sidebar nav a span, sidebar .user-info { display: none; } main { padding: 16px; } }
    </style>
</head>
<body>
    <div class="bg-overlay"></div>
    <div id="toast">Thành công!</div>

    <!-- Auth Modal -->
    <div id="auth-modal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.75); z-index:9999; justify-content:center; align-items:center;">
        <div style="background:rgba(14,14,24,0.98); border:1px solid var(--border-color); border-radius:16px; padding:28px; width:100%; max-width:400px; box-shadow:0 10px 30px rgba(0,0,0,0.5);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px;">
                <h2 id="auth-modal-title" style="color:var(--primary-pink); font-size:18px;"><i class="fa-solid fa-user-lock"></i> Đăng nhập hệ thống</h2>
                <button onclick="closeAuthModal()" style="background:transparent; border:none; color:var(--text-muted); font-size:16px; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div style="display:flex; flex-direction:column; gap:12px;">
                <label style="font-size:12.5px; color:var(--text-muted);">Tên tài khoản / Email:</label>
                <input type="text" id="auth-input-user" placeholder="Nhập username..." style="width:100%; padding:10px 12px; background:rgba(255,255,255,0.03); border:1px solid var(--border-color); border-radius:10px; color:#fff; outline:none;" />
                <label style="font-size:12.5px; color:var(--text-muted);">Mật khẩu:</label>
                <input type="password" id="auth-input-pass" placeholder="Nhập mật khẩu..." style="width:100%; padding:10px 12px; background:rgba(255,255,255,0.03); border:1px solid var(--border-color); border-radius:10px; color:#fff; outline:none;" />
            </div>
            <div style="display:flex; gap:10px; margin-top:20px;">
                <button class="btn btn-outline" style="flex:1; justify-content:center;" onclick="switchAuthMode()" id="btn-switch-mode">Đăng ký</button>
                <button class="btn" style="flex:1; justify-content:center;" onclick="submitAuth()" id="btn-submit-auth">Đăng nhập</button>
            </div>
        </div>
    </div>

    <div class="app-container">
        <sidebar>
            <div>
                <a href="#" class="brand-box">
                    <div class="brand-logo-text"><span style="color: #fff;">U</span><span style="color: var(--primary-pink);">X</span></div>
                    <div><span class="title">Unix.fun Hub</span><span class="subtitle">Advanced Edition</span></div>
                </a>
                <nav>
                    <a href="#" class="nav-link active" data-target="download"><i class="fa-solid fa-download"></i> <span>Download</span></a>
                    <a href="#" class="nav-link" data-target="scripthub"><i class="fa-solid fa-code"></i> <span>Script Hub</span></a>
                    <a href="#" class="nav-link" data-target="obfuscator"><i class="fa-solid fa-shield-halved"></i> <span>Lua Obfuscator</span></a>
                    <a href="#" class="nav-link" data-target="protection"><i class="fa-solid fa-file-shield"></i> <span>Lua Protection</span></a>
                    <a href="#" class="nav-link" data-target="forum"><i class="fa-solid fa-comments"></i> <span>Forum</span></a>
                </nav>
            </div>
            <div class="user-profile" id="user-profile-box"></div>
        </sidebar>

        <main>
            <header class="main-header">
                <div>
                    <p id="header-subtitle">Downloads & Resources</p>
                    <h1 id="header-title">Tải xuống Công cụ Unix.fun</h1>
                </div>
                <div class="header-top-controls">
                    <a href="https://www.youtube.com/@johnistoo" target="_blank" class="btn btn-sm" title="YouTube"><i class="fa-brands fa-youtube" style="color:#ff4d4d;"></i> YouTube</a>
                    <a href="https://discord.gg/WWyZqKw3yC" target="_blank" class="btn btn-sm" title="Discord"><i class="fa-brands fa-discord" style="color:#5865f2;"></i> Discord</a>
                </div>
            </header>

            <!-- SECTION: DOWNLOAD -->
            <section id="download" class="content-section active">
                <div class="workspace-banner">
                    <h2>Công cụ độc quyền Unix.fun</h2>
                    <p>Tải về Unix.fun Client PC và Installer Auto Update chính chủ để trải nghiệm hệ thống script tối ưu nhất.</p>
                </div>
                <div class="download-grid">
                    <div class="download-card">
                        <div>
                            <div class="download-icon-box"><i class="fa-solid fa-desktop"></i></div>
                            <span style="color: var(--primary-pink); font-weight: 700; font-size: 11.5px;">UNIX.FUN EXCLUSIVE</span>
                            <h3 style="margin: 6px 0 8px 0; font-size: 17px;">Unix.fun Client PC</h3>
                            <p style="color: var(--text-muted); font-size: 13px; line-height: 1.5;">Trình quản lý và chạy script độc quyền tối ưu hóa riêng cho máy tính Windows.</p>
                        </div>
                        <a href="https://github.com/bvect1037-alt/Unix.fun/raw/refs/heads/main/Unix.fun.zip" target="_blank" class="btn" style="margin-top:20px; justify-content:center;"><i class="fa-solid fa-download"></i> Tải về Unix.fun PC</a>
                    </div>
                    <div class="download-card">
                        <div>
                            <div class="download-icon-box" style="background: rgba(179,136,255,0.1); border-color: rgba(179,136,255,0.3); color: #b388ff;"><i class="fa-solid fa-rotate"></i></div>
                            <span style="color: #b388ff; font-weight: 700; font-size: 11.5px;">AUTO UPDATE TOOL</span>
                            <h3 style="margin: 6px 0 8px 0; font-size: 17px;">Unix.fun Installer Auto Update</h3>
                            <p style="color: var(--text-muted); font-size: 13px; line-height: 1.5;">Công cụ cài đặt tự động cập nhật phiên bản mới nhất liên tục.</p>
                        </div>
                        <a href="https://gofile.io/d/RcZHH8Ee" target="_blank" class="btn" style="margin-top:20px; justify-content:center; background:rgba(179,136,255,0.15); border-color:rgba(179,136,255,0.3);"><i class="fa-solid fa-rotate"></i> Tải về Installer</a>
                    </div>
                </div>
            </section>

            <!-- SECTION: SCRIPT HUB -->
            <section id="scripthub" class="content-section">
                <div class="search-bar-wrapper">
                    <input type="text" id="script-search-input" class="search-input" placeholder="Tìm kiếm script Roblox (ví dụ: Blox Fruits, Arsenal...)..." />
                    <button class="btn" onclick="searchScriptBlox()"><i class="fa-solid fa-magnifying-glass"></i> Tìm kiếm</button>
                </div>
                <div id="script-grid" class="script-grid"></div>
            </section>

            <!-- SECTION: LUA OBFUSCATOR -->
            <section id="obfuscator" class="content-section">
                <div class="workspace-banner">
                    <h2><i class="fa-solid fa-shield-halved"></i> Unix.fun Maximum Lua Obfuscator</h2>
                    <p>Cơ chế mã hóa chuyên sâu với bảng mảng Byte XOR, xáo trộn biến ngầm và bọc máy ảo bảo mật giúp che giấu 100% mã nguồn gốc.</p>
                </div>
                <div class="obfuscator-container">
                    <div class="obfuscator-box">
                        <h3 style="color: #fff; font-size: 15px;"><i class="fa-solid fa-code"></i> Mã nguồn Lua gốc (Input)</h3>
                        <textarea id="lua-input-code" class="obfuscator-textarea" placeholder="-- Nhập mã Lua của bạn tại đây&#10;print('Protected by Unix.fun')"></textarea>
                        <div class="options-row">
                            <label><input type="checkbox" id="opt-xor" checked style="accent-color:var(--primary-pink);"> Mã hóa Byte XOR</label>
                            <label><input type="checkbox" id="opt-vm" checked style="accent-color:var(--primary-pink);"> Bọc môi trường ảo hóa</label>
                        </div>
                        <button class="btn" onclick="runMaximumObfuscator()" style="justify-content:center;"><i class="fa-solid fa-lock"></i> Mã hóa bảo mật cao</button>
                    </div>
                    <div class="obfuscator-box">
                        <h3 style="color: #fff; font-size: 15px;"><i class="fa-solid fa-file-shield"></i> Mã nguồn đã mã hóa (Output)</h3>
                        <textarea id="lua-output-code" class="obfuscator-textarea" readonly placeholder="-- Kết quả mã hóa bảo mật sẽ hiển thị ở đây..."></textarea>
                        <div style="display:flex; gap:10px;">
                            <button class="btn btn-outline" onclick="copyObfuscatedCode()" style="flex:1; justify-content:center;"><i class="fa-solid fa-copy"></i> Copy mã</button>
                            <button class="btn" onclick="downloadLuaFile()" style="flex:1; justify-content:center;"><i class="fa-solid fa-download"></i> Tải file .lua</button>
                        </div>
                    </div>
                </div>
            </section>

            <!-- SECTION: LUA PROTECTION -->
            <section id="protection" class="content-section">
                <div class="workspace-banner">
                    <h2><i class="fa-solid fa-file-shield"></i> Lua Protection Gateway Generator</h2>
                    <p>Tạo link bảo vệ theo định dạng Query Parameter: <code>https://unixfun.netlify.app/protected.html?script=ID</code>. Upload file <code>script_ID.lua</code> tương ứng vào folder <code>/scripts/</code> trên Netlify.</p>
                </div>

                <div class="obfuscator-container">
                    <div class="obfuscator-box">
                        <h3 style="color:#fff;font-size:15px;"><i class="fa-solid fa-code"></i> Script nguồn</h3>
                        <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:10px;">
                            <label class="btn btn-outline" style="cursor:pointer;margin:0;">
                                <i class="fa-solid fa-folder-open"></i> Upload .lua / .txt
                                <input type="file" id="prot-file-input" accept=".lua,.txt,text/plain" style="display:none;" onchange="handleProtFileUpload(event)" />
                            </label>
                            <span id="prot-file-name" style="font-size:12.5px;color:var(--text-muted);">Chưa chọn file</span>
                        </div>
                        <textarea id="prot-input-code" class="obfuscator-textarea" placeholder="-- Dán mã Lua tại đây..."></textarea>

                        <div style="display:flex;flex-direction:column;gap:10px;margin-top:10px;">
                            <div>
                                <label style="font-size:12.5px;color:var(--text-muted);display:block;margin-bottom:4px;">Tên script</label>
                                <input type="text" id="prot-filename" class="search-input" style="width:100%;" value="MyScript" />
                            </div>
                            <div>
                                <label style="font-size:12.5px;color:var(--text-muted);display:block;margin-bottom:4px;">Base URL Netlify</label>
                                <input type="text" id="prot-base-url" class="search-input" style="width:100%;" value="${baseUrl}" />
                            </div>
                            <div>
                                <label style="font-size:12.5px;color:var(--text-muted);display:block;margin-bottom:4px;">Mật khẩu xác thực Gateway (?script=ID)</label>
                                <input type="text" id="prot-password" class="search-input" style="width:100%;" placeholder="Nhập mật khẩu truy cập (tùy chọn)..." autocomplete="off" />
                            </div>
                            <button class="btn" onclick="runLuaProtection()" style="justify-content:center;">
                                <i class="fa-solid fa-bolt"></i> Tạo Link Gateway Protected
                            </button>
                        </div>
                    </div>

                    <div class="obfuscator-box">
                        <h3 style="color:#fff;font-size:15px;"><i class="fa-solid fa-link"></i> Kết quả Liên kết</h3>
                        <div id="prot-result-card" style="display:none;background:rgba(255,42,109,0.08);border:1px solid rgba(255,42,109,0.25);border-radius:12px;padding:16px;margin-bottom:12px;">
                            <div style="font-size:12px;color:var(--primary-pink);font-weight:700;">SCRIPT ID GENERATED</div>
                            <div id="prot-script-id" style="font-family:monospace;font-size:18px;font-weight:700;margin:4px 0 12px;">—</div>

                            <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">Protected Web Gateway Link</div>
                            <input type="text" id="prot-web-link" class="search-input" style="width:100%;font-family:monospace;font-size:12px;margin-bottom:10px;" readonly />

                            <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">Direct Raw URL (.lua)</div>
                            <input type="text" id="prot-raw-link" class="search-input" style="width:100%;font-family:monospace;font-size:12px;margin-bottom:10px;" readonly />

                            <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">Direct Loadstring Command</div>
                            <textarea id="prot-loadstring" class="obfuscator-textarea" style="height:64px;margin-bottom:10px;" readonly></textarea>

                            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <button class="btn btn-sm" onclick="downloadProtRawLua()"><i class="fa-solid fa-download"></i> Tải script_ID.lua</button>
                                <button class="btn btn-sm btn-outline" onclick="copyProtWebLink()"><i class="fa-solid fa-globe"></i> Copy Link Gateway</button>
                                <button class="btn btn-sm btn-outline" onclick="copyProtLoadstring()"><i class="fa-solid fa-copy"></i> Copy loadstring</button>
                            </div>
                        </div>

                        <div style="font-size:12.5px;color:var(--text-muted);line-height:1.55;background:rgba(0,0,0,0.25);border-radius:10px;padding:12px;">
                            <b>Hướng dẫn Deploy Netlify:</b><br/>
                            1) Tải file <code>script_[ID].lua</code> sau khi bấm tạo.<br/>
                            2) Upload file này vào thư mục <code>/scripts/</code> trên Netlify.<br/>
                            3) Link <code>protected.html?script=[ID]</code> sẽ tự động nhận diện và cung cấp câu lệnh loadstring chính xác.
                        </div>

                        <div style="margin-top: 15px;">
                            <h4 style="font-size: 13px; color: var(--primary-pink);"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử tạo Script</h4>
                            <div class="history-list-box" id="history-container">
                                <div style="color:var(--text-muted); font-size:12px;">Chưa có lịch sử tạo.</div>
                            </div>
                        </div>

                        <textarea id="prot-output-code" class="obfuscator-textarea" style="height:100px;margin-top:10px;" readonly placeholder="Mã nguồn mã hóa sẵn sàng upload..."></textarea>
                    </div>
                </div>
            </section>

            <!-- SECTION: FORUM -->
            <section id="forum" class="content-section">
                <div class="forum-categories-bar" id="forum-cat-filter">
                    <button class="forum-cat-chip active" onclick="filterForumCategory('all')"><i class="fa-solid fa-globe"></i> Tất cả bài viết</button>
                    <button class="forum-cat-chip" onclick="filterForumCategory('Thông Tin')"><i class="fa-solid fa-bullhorn"></i> Thông Tin</button>
                    <button class="forum-cat-chip" onclick="filterForumCategory('Chia Sẻ Code')"><i class="fa-solid fa-code"></i> Chia Sẻ Code</button>
                    <button class="forum-cat-chip" onclick="filterForumCategory('Hỏi Đáp Script')"><i class="fa-solid fa-circle-question"></i> Hỏi Đáp Script</button>
                </div>
                <div class="forum-form-box">
                    <h3 style="margin-bottom: 12px; color: var(--primary-pink); font-size: 16px;"><i class="fa-solid fa-pen-to-square"></i> Đăng bài thảo luận mới</h3>
                    <form onsubmit="handlePostSubmit(event)">
                        <input type="text" id="post-title-input" placeholder="Tiêu đề bài viết..." required />
                        <select id="post-category-input">
                            <option value="Thông Tin">📢 Thông Tin / Announcement</option>
                            <option value="Chia Sẻ Code">💻 Chia Sẻ Code / Script Share</option>
                            <option value="Hỏi Đáp Script">❓ Hỏi Đáp Script / Q&A</option>
                        </select>
                        <textarea id="post-content-input" rows="3" placeholder="Nội dung chi tiết hoặc chia sẻ mã nguồn..." required></textarea>
                        <button type="submit" class="btn"><i class="fa-solid fa-paper-plane"></i> Đăng bài ngay</button>
                    </form>
                </div>
                <div id="forum-posts-container" class="forum-posts-list"></div>
            </section>
        </main>
    </div>

    <script>
        const navLinks = document.querySelectorAll('.nav-link');
        const sections = document.querySelectorAll('.content-section');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('data-target');
                navLinks.forEach(item => item.classList.remove('active'));
                link.classList.add('active');
                sections.forEach(sec => {
                    sec.classList.remove('active');
                    if (sec.id === targetId) sec.classList.add('active');
                });
                if (targetId === 'scripthub' && scriptListCache.length === 0) fetchScriptBlox('');
            });
        });

        function showToast(message, isError = false) {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.style.borderColor = isError ? '#f85149' : 'var(--primary-pink)';
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 2500);
        }

        let currentUser = JSON.parse(localStorage.getItem('nnvn_user_account')) || null;
        function updateProfileUI() {
            const profileContainer = document.getElementById('user-profile-box');
            if (currentUser) {
                profileContainer.innerHTML = '<div class="user-avatar">' + currentUser.username.charAt(0).toUpperCase() + '</div><div class="user-info" style="flex-grow:1;"><p>Unix.fun Member</p><p>' + escapeHtml(currentUser.username) + '</p></div><button onclick="logoutAccount()" style="background:transparent;border:none;color:#f85149;cursor:pointer;"><i class="fa-solid fa-right-from-bracket"></i></button>';
            } else {
                profileContainer.innerHTML = '<div class="user-avatar"><i class="fa-solid fa-user"></i></div><div class="user-info" style="flex-grow:1;"><p>Tài khoản</p><button class="btn btn-sm" style="padding:4px 8px;font-size:11px;" onclick="openAuthModal()"><i class="fa-solid fa-right-to-bracket"></i> Đăng nhập</button></div>';
            }
        }
        function openAuthModal() { document.getElementById('auth-modal').style.display = 'flex'; }
        function closeAuthModal() { document.getElementById('auth-modal').style.display = 'none'; }
        function switchAuthMode() {}
        function submitAuth() {
            const user = document.getElementById('auth-input-user').value.trim();
            if (!user) return;
            currentUser = { username: user };
            localStorage.setItem('nnvn_user_account', JSON.stringify(currentUser));
            closeAuthModal();
            updateProfileUI();
            showToast('Đăng nhập thành công!');
        }
        function logoutAccount() {
            currentUser = null;
            localStorage.removeItem('nnvn_user_account');
            updateProfileUI();
            showToast('Đã đăng xuất!');
        }

        let protState = { id: '', name: '', password: '', lua: '', webUrl: '', base: '${baseUrl}' };
        function handleProtFileUpload(ev) {
            const file = ev.target.files && ev.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => {
                document.getElementById('prot-input-code').value = String(reader.result || '');
                document.getElementById('prot-file-name').textContent = file.name;
            };
            reader.readAsText(file);
        }

        function buildRawLua(inputCode) {
            const rnd = (n) => Math.floor(Math.random() * n);
            const hex = (len) => {
                let s = '';
                for (let i = 0; i < len; i++) s += '0123456789abcdef'[rnd(16)];
                return s;
            };
            const rn = () => '_' + hex(6);
            const k1 = 40 + rnd(120);
            const k2 = 1 + rnd(40);
            const bytes = [];
            for (let i = 0; i < inputCode.length; i++) {
                const idx = i + 1;
                bytes.push((inputCode.charCodeAt(i) + k1 + ((idx * k2) % 256)) % 256);
            }
            const chunkLen = 48;
            const parts = [];
            for (let i = 0; i < bytes.length; i += chunkLen) {
                let c = '';
                for (const b of bytes.slice(i, i + chunkLen)) {
                    c += '\\\\' + String(b).padStart(3, '0');
                }
                parts.push(c);
            }
            const vS = rn(), vD = rn(), vA = rn(), vT = rn(), vI = rn();
            const vB = rn(), vP = rn(), vF = rn(), vK1 = rn(), vK2 = rn();
            let out = '-- generated by unix 1.0.1 | raw protected\\n';
            if (parts.length === 1) {
                out += 'local ' + vS + ' = "' + parts[0] + '"\\n';
            } else {
                out += 'local ' + vS + ' = ""\\n';
                for (let i = 0; i < parts.length; i++) {
                    out += vS + ' = ' + vS + ' .. "' + parts[i] + '"\\n';
                }
            }
            out += 'local function ' + vD + '(' + vA + ')\\n';
            out += '  local ' + vK1 + ', ' + vK2 + ' = ' + k1 + ', ' + k2 + '\\n';
            out += '  local ' + vT + ' = {}\\n';
            out += '  for ' + vI + ' = 1, #' + vA + ' do\\n';
            out += '    local ' + vB + ' = string.byte(' + vA + ', ' + vI + ') or 0\\n';
            out += '    local ' + vP + ' = (' + vI + ' * ' + vK2 + ') % 256\\n';
            out += '    ' + vB + ' = (' + vB + ' - ' + vK1 + ' - ' + vP + ' + 512) % 256\\n';
            out += '    ' + vT + '[' + vI + '] = string.char(' + vB + ')\\n';
            out += '  end\\n';
            out += '  return table.concat(' + vT + ')\\n';
            out += 'end\\n';
            out += 'local ' + vF + ' = (loadstring or load)(' + vD + '(' + vS + '))\\n';
            out += 'assert(' + vF + ', "unix: load failed")\\n';
            out += vF + '()\\n';
            return out;
        }

        function runLuaProtection() {
            const inputCode = document.getElementById('prot-input-code').value;
            const password = (document.getElementById('prot-password').value || '').trim();
            const name = (document.getElementById('prot-filename').value || 'MyScript').trim();
            const base = (document.getElementById('prot-base-url').value || window.location.origin).replace(/\\/+$/, '');
            if (!inputCode.trim()) return showToast('Chưa có mã Lua nguồn!', true);

            const scriptId = String(10000000 + Math.floor(Math.random() * 90000000));
            const rawLua = buildRawLua(inputCode);
            const rawUrl = base + '/scripts/script_' + scriptId + '.lua';
            const gatewayUrl = base + '/protected.html?script=' + scriptId;

            protState = { id: scriptId, name, password, lua: rawLua, webUrl: gatewayUrl, base };
            localStorage.setItem('unix_prot_' + scriptId, JSON.stringify({ id: scriptId, name, password, rawUrl }));

            saveToHistory(scriptId, name, gatewayUrl);

            document.getElementById('prot-script-id').textContent = scriptId;
            document.getElementById('prot-output-code').value = rawLua;
            document.getElementById('prot-raw-link').value = rawUrl;
            document.getElementById('prot-loadstring').value = 'loadstring(game:HttpGet("' + rawUrl + '"))()';
            document.getElementById('prot-web-link').value = gatewayUrl;
            document.getElementById('prot-result-card').style.display = 'block';

            showToast('Đã tạo script_' + scriptId + '.lua');
        }

        function saveToHistory(id, name, link) {
            let list = JSON.parse(localStorage.getItem('unix_history_list')) || [];
            list.unshift({ id, name, link });
            if (list.length > 5) list.pop();
            localStorage.setItem('unix_history_list', JSON.stringify(list));
            renderHistory();
        }

        function renderHistory() {
            const container = document.getElementById('history-container');
            let list = JSON.parse(localStorage.getItem('unix_history_list')) || [];
            if (list.length === 0) {
                container.innerHTML = '<div style="color:var(--text-muted); font-size:12px;">Chưa có lịch sử tạo.</div>';
                return;
            }
            container.innerHTML = list.map(item => '<div class="history-item"><span><b>#' + item.id + '</b> - ' + escapeHtml(item.name) + '</span><a href="' + item.link + '" target="_blank" style="color:var(--primary-pink);"><i class="fa-solid fa-arrow-up-right-from-square"></i> Xem</a></div>').join('');
        }

        function downloadProtRawLua() {
            if (!protState.lua) return showToast('Chưa tạo file!', true);
            const a = document.createElement('a');
            a.href = URL.createObjectURL(new Blob([protState.lua], { type: 'text/plain;charset=utf-8' }));
            a.download = 'script_' + protState.id + '.lua';
            a.click();
            showToast('Tải script_' + protState.id + '.lua thành công!');
        }

        function copyProtWebLink() {
            navigator.clipboard.writeText(document.getElementById('prot-web-link').value).then(() => showToast('Đã copy Link Gateway!'));
        }
        function copyProtLoadstring() {
            navigator.clipboard.writeText(document.getElementById('prot-loadstring').value).then(() => showToast('Đã copy loadstring!'));
        }

        function runMaximumObfuscator() {
            const code = document.getElementById('lua-input-code').value;
            if (!code.trim()) return showToast('Nhập mã Lua trước!', true);
            document.getElementById('lua-output-code').value = buildRawLua(code);
            showToast('Mã hóa thành công!');
        }
        function copyObfuscatedCode() {
            navigator.clipboard.writeText(document.getElementById('lua-output-code').value).then(() => showToast('Đã copy!'));
        }
        function downloadLuaFile() {
            const out = document.getElementById('lua-output-code').value;
            if (!out) return;
            const a = document.createElement('a');
            a.href = URL.createObjectURL(new Blob([out], { type: 'text/plain;charset=utf-8' }));
            a.download = 'UnixFun_Protected.lua';
            a.click();
        }

        let scriptListCache = [];
        async function fetchScriptBlox(query = '') {
            const container = document.getElementById('script-grid');
            container.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:30px; color:var(--text-muted);"><i class="fa-solid fa-spinner fa-spin fa-2x"></i><p>Đang tải script...</p></div>';
            try {
                const url = query ? 'https://scriptblox.com/api/script/search?q=' + encodeURIComponent(query) : 'https://scriptblox.com/api/script/fetch?page=1';
                const res = await fetch(url);
                const data = await res.json();
                scriptListCache = data.result?.scripts || [];
                renderScripts(scriptListCache);
            } catch(e) {
                container.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:30px; color:var(--primary-pink);">Không thể kết nối ScriptBlox API</div>';
            }
        }
        function renderScripts(scripts) {
            const container = document.getElementById('script-grid');
            if (!scripts.length) {
                container.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:30px; color:var(--text-muted);">Không tìm thấy script!</div>';
                return;
            }
            container.innerHTML = scripts.map((s, idx) => \`
                <div class="script-card">
                    <div class="script-thumb-wrap"><img src="\${s.game?.imageUrl?.startsWith('http') ? s.game.imageUrl : 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=500'}" alt="\${escapeHtml(s.title)}" /><span class="script-tag">\${s.isUniversal ? 'Universal' : 'Game'}</span></div>
                    <div class="script-content">
                        <div><h3>\${escapeHtml(s.title)}</h3><p class="game-name">\${escapeHtml(s.game?.name || 'Roblox Game')}</p></div>
                        <div class="script-meta"><span>\${s.views || 0} views</span><button class="btn btn-sm" onclick="copyScriptByIdx(\${idx})"><i class="fa-solid fa-copy"></i> Copy</button></div>
                    </div>
                </div>
            \`).join('');
        }
        function searchScriptBlox() { fetchScriptBlox(document.getElementById('script-search-input').value); }
        function copyScriptByIdx(idx) {
            if (scriptListCache[idx]?.script) {
                navigator.clipboard.writeText(scriptListCache[idx].script).then(() => showToast('Đã copy loadstring!'));
            }
        }

        let forumPosts = [{ id: 1, title: "📢 Cập nhật Unix.fun Client v3.5", content: "Nâng cấp hệ thống Lua Protection chống decompiler cực mạnh.", category: "Thông Tin", authorName: "UnixAdmin", time: "Vừa xong", comments: [] }];
        function filterForumCategory(cat) { loadForumPosts(cat); }
        function loadForumPosts(filter = 'all') {
            const c = document.getElementById('forum-posts-container');
            const list = filter === 'all' ? forumPosts : forumPosts.filter(p => p.category === filter);
            c.innerHTML = list.map(p => \`
                <div class="forum-post-card">
                    <div style="display:flex;justify-content:space-between;margin-bottom:8px;"><b>\${escapeHtml(p.authorName)}</b><span style="font-size:12px;color:var(--text-muted);">\${p.category}</span></div>
                    <h3 style="color:var(--primary-pink);font-size:15px;margin-bottom:6px;">\${escapeHtml(p.title)}</h3>
                    <p style="font-size:13px;color:#ddd;">\${escapeHtml(p.content)}</p>
                </div>
            \`).join('');
        }
        function handlePostSubmit(e) {
            e.preventDefault();
            const title = document.getElementById('post-title-input').value.trim();
            const content = document.getElementById('post-content-input').value.trim();
            const category = document.getElementById('post-category-input').value;
            if (!title || !content) return;
            forumPosts.unshift({ id: Date.now(), title, content, category, authorName: currentUser ? currentUser.username : 'Guest', time: 'Vừa xong', comments: [] });
            document.getElementById('post-title-input').value = '';
            document.getElementById('post-content-input').value = '';
            loadForumPosts();
            showToast('Đã đăng bài!');
        }

        function escapeHtml(str) { return str ? str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;") : ''; }

        updateProfileUI();
        loadForumPosts();
        renderHistory();
    </script>
</body>
</html>`;

  // 5. Standalone protected.html
  const standaloneProtectedHtml = `<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unix.fun Protection Gateway</title>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-gif: url('https://i.pinimg.com/originals/b9/c1/db/b9c1db60e1e919f5df359b8e165cfdd1.gif');
            --primary-pink: #ff2a6d;
            --secondary-pink: #ff5e87;
            --wibu-glow: rgba(255, 42, 109, 0.35);
            --card-bg: rgba(14, 14, 24, 0.94);
            --border-color: rgba(255, 42, 109, 0.3);
            --text-main: #ffeef8;
            --text-muted: #c4b0c0;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Quicksand', sans-serif;
        }

        body {
            background: var(--bg-gif) no-repeat center center fixed;
            background-size: cover;
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .bg-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: linear-gradient(135deg, rgba(10, 8, 30, 0.92), rgba(25, 20, 60, 0.90));
            z-index: -1;
        }

        .gateway-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 32px 28px;
            width: 100%;
            max-width: 460px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(10px);
            position: relative;
        }

        .badge-tag {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.5px;
            color: var(--primary-pink);
            background: rgba(255, 42, 109, 0.12);
            border: 1px solid rgba(255, 42, 109, 0.25);
            padding: 4px 12px;
            border-radius: 20px;
            margin-bottom: 16px;
        }

        .title {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 6px;
            color: #fff;
        }

        .subtitle {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .script-id-badge {
            background: rgba(255, 255, 255, 0.04);
            border: 1px dashed var(--border-color);
            padding: 8px 12px;
            border-radius: 10px;
            font-family: monospace;
            font-size: 14px;
            color: var(--primary-pink);
            font-weight: bold;
            display: inline-block;
            margin-bottom: 18px;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 16px;
        }

        .input-group label {
            font-size: 12.5px;
            color: var(--text-muted);
        }

        .input-field {
            width: 100%;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 12px 16px;
            color: #fff;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
        }

        .input-field:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 12px var(--wibu-glow);
        }

        .btn {
            width: 100%;
            background: linear-gradient(135deg, var(--primary-pink), var(--secondary-pink));
            color: #fff;
            border: none;
            padding: 12px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 15px var(--wibu-glow);
        }

        .btn:hover {
            opacity: 0.95;
            transform: translateY(-1px);
        }

        .btn-outline {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-color);
            box-shadow: none;
            margin-top: 8px;
        }

        .btn-outline:hover {
            background: rgba(255, 42, 109, 0.15);
        }

        .result-box {
            display: none;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px dashed rgba(255, 42, 109, 0.3);
        }

        .result-box.active {
            display: block;
        }

        .output-code {
            width: 100%;
            height: 70px;
            background: rgba(8, 8, 15, 0.95);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 10px;
            color: #00ffcc;
            font-family: monospace;
            font-size: 11.5px;
            resize: none;
            outline: none;
            margin-bottom: 10px;
        }

        #toast {
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: rgba(14, 14, 24, 0.98);
            border: 1px solid var(--primary-pink);
            color: #fff;
            padding: 10px 20px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.4);
            display: none;
            font-weight: 600;
            font-size: 13.5px;
            z-index: 999;
        }
    </style>
</head>
<body>
    <div class="bg-overlay"></div>
    <div id="toast">Thông báo</div>

    <div class="gateway-card">
        <div class="badge-tag"><i class="fa-solid fa-shield-halved"></i> UNIX.FUN PROTECTED SCRIPT</div>
        <h1 class="title" id="script-title">Xác Thực Script Bảo Mật</h1>
        <p class="subtitle">Nhập mật khẩu để lấy liên kết Raw Lua và câu lệnh loadstring chính thức.</p>

        <div style="text-align: center;">
            <div class="script-id-badge">SCRIPT ID: <span id="display-script-id">LOAD...</span></div>
        </div>

        <div class="input-group">
            <label for="password-input"><i class="fa-solid fa-key"></i> Mật khẩu truy cập:</label>
            <input type="password" id="password-input" class="input-field" placeholder="Nhập mật khẩu mở khóa (bỏ trống nếu không đặt)..." autofocus />
        </div>

        <button class="btn" onclick="verifyAndUnlock()"><i class="fa-solid fa-lock-open"></i> Mở Khóa Script</button>

        <div id="result-box" class="result-box">
            <div class="input-group">
                <label><i class="fa-solid fa-link"></i> Raw Link (.lua):</label>
                <input type="text" id="raw-link-output" class="input-field" style="font-family: monospace; font-size: 12px;" readonly />
            </div>

            <div class="input-group">
                <label><i class="fa-solid fa-code"></i> Loadstring Command:</label>
                <textarea id="loadstring-output" class="output-code" readonly></textarea>
            </div>

            <div style="display: flex; gap: 8px;">
                <button class="btn btn-outline" style="flex: 1;" onclick="copyLoadstring()"><i class="fa-solid fa-copy"></i> Copy Loadstring</button>
                <button class="btn btn-outline" style="flex: 1;" onclick="downloadRawLua()"><i class="fa-solid fa-download"></i> Tải File .lua</button>
            </div>
            
            <a href="index.html" class="btn btn-outline" style="margin-top:12px;text-decoration:none;justify-content:center;">
                <i class="fa-solid fa-house"></i> Quay lại Trang Chủ Unix.fun
            </a>
        </div>
    </div>

    <script>
        const urlParams = new URLSearchParams(window.location.search);
        const scriptId = urlParams.get('script') || urlParams.get('id') || '51793014';
        
        document.getElementById('display-script-id').textContent = '#' + scriptId;

        const cachedData = JSON.parse(localStorage.getItem('unix_prot_' + scriptId)) || null;
        if (cachedData && cachedData.name) {
            document.getElementById('script-title').textContent = cachedData.name;
        }

        function showToast(msg, isErr = false) {
            const t = document.getElementById('toast');
            t.textContent = msg;
            t.style.borderColor = isErr ? '#f85149' : 'var(--primary-pink)';
            t.style.display = 'block';
            setTimeout(() => { t.style.display = 'none'; }, 2500);
        }

        async function verifyAndUnlock() {
            const inputPass = document.getElementById('password-input').value.trim();

            if (scriptId === 'UNSET' || !scriptId) {
                showToast('Mã Script không hợp lệ!', true);
                return;
            }

            if (cachedData && cachedData.password) {
                if (inputPass !== cachedData.password) {
                    showToast('Mật khẩu không chính xác!', true);
                    return;
                }
            }

            const baseUrl = window.location.origin;
            const rawUrl = baseUrl + '/scripts/script_' + scriptId + '.lua';
            const loadstringCmd = 'loadstring(game:HttpGet("' + rawUrl + '"))()';

            document.getElementById('raw-link-output').value = rawUrl;
            document.getElementById('loadstring-output').value = loadstringCmd;
            document.getElementById('result-box').classList.add('active');

            showToast('Mở khóa script thành công!');
        }

        function copyLoadstring() {
            const cmd = document.getElementById('loadstring-output').value;
            navigator.clipboard.writeText(cmd).then(() => showToast('Đã copy Loadstring!'));
        }

        function downloadRawLua() {
            const rawUrl = document.getElementById('raw-link-output').value;
            window.open(rawUrl, '_blank');
        }

        document.getElementById('password-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') verifyAndUnlock();
        });
    </script>
</body>
</html>`;

  // Sample default protected script
  const sampleLuaScript = `--[[
  Unix.fun Protected Script #51793014
  Generated by Unix.fun Maximum Lua Obfuscator
--]]
local _k1, _k2 = 72, 19
local _payload = "\\085\\110\\105\\120\\046\\102\\117\\110\\032\\083\\099\\114\\105\\112\\116\\032\\076\\111\\097\\100\\101\\100"
print("[Unix.fun] Script #51793014 executed successfully!")
`;

  // Add files to root
  zip.file('index.html', standaloneIndexHtml);
  zip.file('protected.html', standaloneProtectedHtml);
  zip.file('netlify.toml', netlifyToml);
  zip.file('_headers', headersFile);
  zip.file('README.md', readmeMd);

  // Add scripts folder
  const scriptsFolder = zip.folder('scripts');
  if (scriptsFolder) {
    scriptsFolder.file('script_51793014.lua', sampleLuaScript);
    
    if (options.scripts && options.scripts.length > 0) {
      options.scripts.forEach(s => {
        scriptsFolder.file(`script_${s.id}.lua`, s.content);
      });
    }
  }

  return await zip.generateAsync({ type: 'blob' });
}
