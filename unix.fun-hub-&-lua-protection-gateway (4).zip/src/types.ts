export interface UserAccount {
  id: string;
  username: string;
  displayName?: string;
  bio?: string;
  email?: string;
  avatar?: string;
  role?: 'admin' | 'user';
  provider: 'local' | 'google';
  createdAt?: string;
  following?: string[];
  followersCount?: number;
  followingCount?: number;
  isBanned?: boolean;
  banReason?: string;
  banType?: 'ip' | 'account';
}

export interface RegisteredUser {
  id: string;
  username: string;
  displayName?: string;
  bio?: string;
  email: string;
  password?: string;
  avatar?: string;
  role?: 'admin' | 'user';
  provider: 'local' | 'google';
  createdAt: string;
  following?: string[];
  followersCount?: number;
  followingCount?: number;
  isBanned?: boolean;
  banReason?: string;
  banType?: 'ip' | 'account';
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'global' | 'like' | 'comment' | 'follow' | 'system' | 'ping';
  time: string;
  timestamp: number;
  isRead: boolean;
  senderName?: string;
  senderAvatar?: string;
  senderRole?: string;
  link?: string;
}

export interface ProtectedScriptItem {
  id: string;
  name: string;
  ownerUsername: string;
  sourceCode: string;
  protectedLua: string;
  password?: string;
  rawUrl: string;
  gatewayUrl: string;
  loadstringCmd: string;
  publicRawUrl?: string;
  publicProvider?: string;
  createdAt: string;
  updatedAt: string;
  viewsCount?: number;
  antiHook?: boolean;
  antiDevtools?: boolean;
  vmSandbox?: boolean;
}

export interface ForumComment {
  id: number;
  authorName: string;
  authorDisplayName?: string;
  authorAvatar?: string;
  authorRole?: string;
  content: string;
  time: string;
  timestamp?: number;
}

export interface ForumPost {
  id: number;
  title: string;
  content: string;
  category: string;
  authorName: string;
  authorDisplayName?: string;
  authorAvatar?: string;
  authorRole?: string;
  postImage?: string;
  time: string;
  timestamp?: number;
  isPinned?: boolean;
  likes: number;
  likedBy: string[];
  comments: ForumComment[];
}

export interface ScriptBloxItem {
  _id?: string;
  title: string;
  script: string;
  views?: number;
  isUniversal?: boolean;
  game?: {
    name: string;
    imageUrl?: string;
  };
}

export interface ProtectedHistoryItem {
  id: string;
  name: string;
  password?: string;
  link?: string;
  rawUrl?: string;
  time?: string;
  updatedAt?: string;
  ownerUsername?: string;
  sourceCode?: string;
  protectedLua?: string;
  antiHook?: boolean;
}

