/**
 * Unix.fun Hub & Lua Protection Gateway
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DownloadSection } from './components/DownloadSection';
import { ScriptHubSection } from './components/ScriptHubSection';
import { ObfuscatorSection } from './components/ObfuscatorSection';
import { ProtectionSection } from './components/ProtectionSection';
import { ForumSection } from './components/ForumSection';
import { ProtectedGatewayView } from './components/ProtectedGatewayView';
import { AuthModal } from './components/AuthModal';
import { AdminCommandConsole } from './components/AdminCommandConsole';
import { UserProfileModal } from './components/UserProfileModal';
import { NotificationsModal } from './components/NotificationsModal';
import { BannedScreenModal } from './components/BannedScreenModal';
import { UserAccount } from './types';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('download');
  const [lang, setLang] = useState<'vi' | 'en'>('en');
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [toast, setToast] = useState<{ message: string; isError?: boolean } | null>(null);
  
  // Profile Modal State
  const [selectedProfileUsername, setSelectedProfileUsername] = useState<string | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Notifications Modal State
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState(2);

  // Ban Screen Modal State
  const [isBanModalOpen, setIsBanModalOpen] = useState(false);
  const [banModalType, setBanModalType] = useState<'ip' | 'account'>('account');
  const [banModalReason, setBanModalReason] = useState<string>('');

  // Check if loaded with ?script=... or ?id=... parameter
  const [activeGatewayScriptId, setActiveGatewayScriptId] = useState<string | null>(null);

  useEffect(() => {
    // Check URL parameters for direct gateway access
    const searchParams = new URLSearchParams(window.location.search);
    const scriptFromUrl = searchParams.get('script') || searchParams.get('id');
    if (scriptFromUrl) {
      setActiveGatewayScriptId(scriptFromUrl);
    }

    // Load saved lang
    const savedLang = localStorage.getItem('nnvn_lang') as 'vi' | 'en';
    if (savedLang === 'vi' || savedLang === 'en') {
      setLang(savedLang);
    }

    // Load saved user
    const savedUser = localStorage.getItem('nnvn_user_account');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch {
        // ignore
      }
    }

    fetchUnreadNotificationsCount();
  }, []);

  const fetchUnreadNotificationsCount = async () => {
    try {
      const username = currentUser?.username || '';
      const res = await fetch(`/api/notifications?username=${encodeURIComponent(username)}`);
      if (res.ok) {
        const data = await res.json();
        const unread = (data.notifications || []).filter((n: { isRead?: boolean }) => !n.isRead).length;
        setUnreadNotificationsCount(unread);
      }
    } catch {
      // fallback
    }
  };

  const handleOpenProfile = (username: string) => {
    setSelectedProfileUsername(username);
    setIsProfileModalOpen(true);
  };

  const handleTriggerBan = (banType: 'ip' | 'account', banReason?: string) => {
    setBanModalType(banType);
    setBanModalReason(banReason || '');
    setIsBanModalOpen(true);
  };

  const handleSetLang = (newLang: 'vi' | 'en') => {
    setLang(newLang);
    localStorage.setItem('nnvn_lang', newLang);
  };

  const showToast = (message: string, isError = false) => {
    setToast({ message, isError });
    setTimeout(() => {
      setToast(null);
    }, 2800);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('nnvn_user_account');
    showToast(lang === 'vi' ? 'Đã đăng xuất tài khoản!' : 'Logged out!');
  };

  // If in Gateway mode (URL query param or Simulator clicked)
  if (activeGatewayScriptId) {
    return (
      <div style={{ minHeight: '100vh', position: 'relative' }}>
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100vw',
            height: '100vh',
            background: 'linear-gradient(135deg, rgba(10, 8, 30, 0.94), rgba(25, 20, 60, 0.92))',
            zIndex: -1,
          }}
        />
        <ProtectedGatewayView
          scriptId={activeGatewayScriptId}
          lang={lang}
          onBackToHub={() => {
            setActiveGatewayScriptId(null);
            // clean url without full reload
            if (window.history.pushState) {
              const newUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;
              window.history.pushState({ path: newUrl }, '', newUrl);
            }
          }}
          onShowToast={showToast}
        />

        {/* Toast Notification */}
        {toast && (
          <div
            style={{
              position: 'fixed',
              bottom: '24px',
              right: '24px',
              background: 'rgba(14, 14, 24, 0.98)',
              border: '1px solid',
              borderColor: toast.isError ? '#f85149' : 'var(--primary-pink)',
              color: '#fff',
              padding: '10px 20px',
              borderRadius: '10px',
              boxShadow: '0 5px 20px rgba(0,0,0,0.4)',
              zIndex: 10000,
              fontWeight: 600,
              fontSize: '13.5px',
            }}
          >
            {toast.message}
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', width: '100%', minHeight: '100vh', position: 'relative' }}>
      {/* Background Gradient Overlay */}
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'linear-gradient(135deg, rgba(10, 8, 30, 0.94), rgba(25, 20, 60, 0.92))',
          zIndex: -1,
        }}
      />

      {/* Toast Notification */}
      {toast && (
        <div
          style={{
            position: 'fixed',
            bottom: '24px',
            right: '24px',
            background: 'rgba(14, 14, 24, 0.98)',
            border: '1px solid',
            borderColor: toast.isError ? '#f85149' : 'var(--primary-pink)',
            color: '#fff',
            padding: '10px 20px',
            borderRadius: '10px',
            boxShadow: '0 5px 20px rgba(0,0,0,0.4)',
            zIndex: 10000,
            fontWeight: 600,
            fontSize: '13.5px',
          }}
        >
          {toast.message}
        </div>
      )}

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={(user) => setCurrentUser(user)}
        onShowToast={showToast}
        lang={lang}
      />

      {/* Left Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={(tabId) => setCurrentTab(tabId)}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        onOpenProfile={handleOpenProfile}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadNotificationsCount={unreadNotificationsCount}
        lang={lang}
      />

      {/* Main Content View */}
      <main style={{ flexGrow: 1, padding: '32px', overflowY: 'auto', maxHeight: '100vh' }}>
        <Header
          currentTab={currentTab}
          lang={lang}
          onSetLang={handleSetLang}
          currentUser={currentUser}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onOpenProfile={handleOpenProfile}
          unreadCount={unreadNotificationsCount}
        />

        {currentTab === 'download' && <DownloadSection lang={lang} onShowToast={showToast} />}
        {currentTab === 'scripthub' && <ScriptHubSection lang={lang} onShowToast={showToast} />}
        {currentTab === 'obfuscator' && <ObfuscatorSection lang={lang} onShowToast={showToast} />}
        {currentTab === 'protection' && (
          <ProtectionSection
            lang={lang}
            currentUser={currentUser}
            onShowToast={showToast}
            onOpenAuth={() => setIsAuthOpen(true)}
            onOpenGatewaySimulator={(id) => setActiveGatewayScriptId(id)}
          />
        )}
        {currentTab === 'forum' && (
          <ForumSection
            lang={lang}
            currentUser={currentUser}
            onShowToast={showToast}
            onOpenAuth={() => setIsAuthOpen(true)}
            onOpenProfile={handleOpenProfile}
            onTriggerBan={handleTriggerBan}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
          />
        )}
      </main>

      {/* Super Admin Command Console HUD in Corner */}
      <AdminCommandConsole
        currentUser={currentUser}
        onShowToast={showToast}
        lang={lang}
      />

      {/* User Profile Modal */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        username={selectedProfileUsername}
        currentUser={currentUser}
        onClose={() => setIsProfileModalOpen(false)}
        onUpdateCurrentUser={(updatedUser) => {
          setCurrentUser(updatedUser);
          localStorage.setItem('nnvn_user_account', JSON.stringify(updatedUser));
        }}
        onShowToast={showToast}
        lang={lang}
      />

      {/* Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        currentUser={currentUser}
        onShowToast={showToast}
        lang={lang}
        onRefreshUnreadCount={fetchUnreadNotificationsCount}
      />

      {/* Banned Screen Modal */}
      <BannedScreenModal
        isOpen={isBanModalOpen}
        banType={banModalType}
        banReason={banModalReason}
        lang={lang}
        onClose={() => setIsBanModalOpen(false)}
      />
    </div>
  );
}
